"""Integration tests of the compiled original-core C ABI, not WASM mocks."""
import ctypes
import sys

m = ctypes.CDLL(sys.argv[1] if len(sys.argv) > 1 else '/tmp/libplenty-core27.so')
for name in ['error', 'pv', 'fen']:
    getattr(m, 'pc_' + name).restype = ctypes.c_char_p
m.pc_variant.argtypes = [ctypes.c_int, ctypes.c_int]
m.pc_position.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
m.pc_search.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int]
m.pc_search.restype = ctypes.c_char_p
m.pc_nodes.restype = ctypes.c_double
runs = 0

def position(fen, moves=''):
    assert m.pc_position(fen.encode(), moves.encode()), m.pc_error()

def search(depth=1, ms=2000, nodes=0):
    global runs
    move = m.pc_search(depth, ms, nodes)
    assert move, m.pc_error()
    runs += 1
    return move

for height in [8, 10]:
    start = 'rnabqkbcnr/pppppppppp/' + '10/' * (height-4) + 'PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1'
    if height == 10:
        start += ' t2,2'
    for flags in range(4):
        assert m.pc_variant(height, flags)
        assert not m.pc_search(1, 1000, 0)  # variant reset must require a position
        position(start)
        initial = m.pc_fen()
        assert search() != b'0000'
        assert m.pc_completed() and not m.pc_terminal() and m.pc_depth() == 1
        assert m.pc_fen() == initial  # searching doesn't play the move
        assert search(10, 1000, 1) != b'0000'
        assert not m.pc_completed() and not m.pc_pv() and m.pc_depth() == 0
        cycle = f'b1c3 b{height}c{height-2} c3b1 c{height-2}b{height}'
        position(start, cycle)
        assert search() != b'0000'  # two occurrences != draw
        position(start, cycle + ' ' + cycle)
        assert search() == b'0000' and m.pc_terminal() and m.pc_score() == 0
        position(start)
        assert search() != b'0000'  # no stale repetition
        bare = '9k/' + '10/'*(height-2) + 'K9 w - - 0 1'
        if height == 10:
            bare += ' t0,0'
        position(bare)
        assert search() != b'0000' and not m.pc_terminal()  # no automatic bare-king loss/draw
        for mate in [False, True]:
            fen = '10/'*(height-3) + '2K7/' + ('1Q8/' if mate else '2Q7/') + 'k9 b - - 100 1'
            if height == 10:
                fen += ' t0,0'
            position(fen)
            assert search() == b'0000' and m.pc_terminal() and m.pc_completed()
            assert m.pc_score() == (-30000 if mate else 0)
        position(start)
        assert not m.pc_position(start.encode(), b'a1a10')
        assert not m.pc_fen() and not m.pc_search(1, 1000, 0)
        position(start)
        for depth, ms, nodes in [(-1,1,0),(999,1,0),(1,-1,0),(1,1,-1)]:
            assert not m.pc_search(depth, ms, nodes)
            assert not m.pc_completed() and not m.pc_pv() and not m.pc_terminal()
        assert not m.pc_position(b'not a fen', b'')
        assert not m.pc_search(1, 1000, 0)
assert not m.pc_variant(9, 0)
assert not m.pc_position(b'', b'')
print(f'PASS original-core native ABI: {runs} searches, all 8 configurations; errors, limits, history, mate/stalemate')
