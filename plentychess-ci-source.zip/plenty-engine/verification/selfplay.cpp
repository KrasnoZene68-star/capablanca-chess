#include "../src/variant_position.h"
#include "../src/variant_hash.h"
#include <cassert>
#include <cctype>
#include <iostream>
#include <map>
#include <string>

using VariantPosition::Position;
using VariantMove = VariantPosition::Move;
using CapablancaPort::Board10x8;
using CapablancaPort::Board10x10;

// Test driver, deliberately separate from the PlentyChess search. Its only
// purpose is to make legal sequences and detect state or move-generation faults.
int material(const Position& p) {
    int result = 0;
    for (int s = 0; s < p.geometry.count(); ++s) {
        const char piece = p.cells[s];
        int value = 0;
        switch (std::tolower(static_cast<unsigned char>(piece))) {
        case 'p': value = 100; break;
        case 'n': value = 320; break;
        case 'b': value = 340; break;
        case 'r': value = 500; break;
        case 'q': value = 950; break;
        case 'a': value = 720; break;
        case 'c': value = 820; break;
        default: break;
        }
        result += VariantPosition::isRed(piece) ? value : -value;
    }
    return result;
}

int main() {
    int games = 0, plies = 0;
    for (int rows : {8, 10}) {
        for (int rules = 0; rules < 4; ++rules) {
            const auto g = rows == 8 ? Board10x8 : Board10x10;
            const std::string start = rows == 8 ?
                "rnabqkbcnr/pppppppppp/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1" :
                "rnabqkbcnr/pppppppppp/10/10/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1 t2,2";
            Position p = Position::fromFen(g, start, rules & 1, rules & 2);
            std::map<uint64_t, int> seen;
            int gamePlies = 0;
            for (; gamePlies < 60; ++gamePlies) {
                assert(!p.inCheck(!p.redToMove)); // last mover's king stays safe
                if (++seen[VariantHash::position(p)] >= 3) break;
                auto moves = p.legalMoves();
                if (moves.empty()) break;
                int best = -10000000;
                VariantMove chosen = moves.front();
                for (auto move : moves) {
                    Position next = p.after(move);
                    int score = material(next) * (p.redToMove ? 1 : -1);
                    if (move.special == VariantMove::Special::Triple) score += 3;
                    if (score > best) { best = score; chosen = move; }
                }
                p = p.after(chosen);
            }
            std::cout << rows << "x10 rules=" << rules << " plies=" << gamePlies << '\n';
            plies += gamePlies;
            ++games;
        }
    }
    assert(games == 8 && plies >= 80);
    std::cout << "variant selfplay smoke: " << games << " games, " << plies << " plies OK\n";
}
