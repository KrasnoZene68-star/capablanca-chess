"""Same positions and depth for both binaries; informational timings, no speed promise."""
import json
import pathlib
import subprocess
import sys
import statistics
games=json.loads(pathlib.Path(sys.argv[3]).read_text())
worker=pathlib.Path(__file__).with_name('eval_worker.py')
processes=[subprocess.Popen([sys.executable,str(worker),p],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True) for p in sys.argv[1:3]]
results=[]
try:
    for game in games[::2]:
        for ply in [0,20]:
            q={'height':game['height'],'flags':game['flags'],'fen':game['records'][ply]['fen'],'ms':2000,'depth':2}
            pair=[]
            for p in processes:
                p.stdin.write(json.dumps(q)+'\n');p.stdin.flush()
                r=json.loads(p.stdout.readline());assert 'error' not in r,r
                assert r['completed'] and r['depth']==2,r
                pair.append(r)
            results.append({'position':q,'baseline':pair[0],'candidate':pair[1]})
finally:
    for p in processes:p.stdin.close();p.wait(timeout=10)
pathlib.Path(sys.argv[4]).write_text(json.dumps(results,indent=2))
print(json.dumps({'positions':len(results),'baselineMedianMs':statistics.median(r['baseline']['elapsed']*1000 for r in results),
 'candidateMedianMs':statistics.median(r['candidate']['elapsed']*1000 for r in results),
 'baselineNodes':sum(r['baseline']['nodes'] for r in results),'candidateNodes':sum(r['candidate']['nodes'] for r in results)}))
