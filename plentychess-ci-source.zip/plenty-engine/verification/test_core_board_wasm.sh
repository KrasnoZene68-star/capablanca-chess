#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
test_dir="$(mktemp -d "${TMPDIR:-/tmp}/plenty-core28-board.XXXXXX")"
"${EMXX:-em++}" -std=c++17 -DCAPABLANCA_CORE -O2 -fexceptions \
 -sDISABLE_EXCEPTION_CATCHING=0 -sTOTAL_STACK=8388608 -sALLOW_MEMORY_GROWTH=1 \
 -sENVIRONMENT=node -sSINGLE_FILE=1 verification/test_core_board.cpp src/board.cpp \
 -o "$test_dir/board.cjs"
node "$test_dir/board.cjs"
