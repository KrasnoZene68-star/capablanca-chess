"""Create a separate 5.12.2 experimental preview from unchanged 5.12.1 files.
Usage: python3 prepare_game_preview.py BASE_GAME NEW_OUTPUT_DIRECTORY
No deployment. Exact-match guards reject an incompatible game version.
"""
import pathlib
import shutil
import sys

base, out = map(pathlib.Path, sys.argv[1:])
text = (base/'index.html').read_text()
assert 'appVersion:"5.12.1"' in text, 'Expected game 5.12.1'
assert text.rstrip().endswith('</html>'), 'Incomplete base HTML; restore the full archived game first'
def replace(old, new, count=1):
    global text
    assert text.count(old) == count, f'Unexpected match count: {old[:80]}'
    text=text.replace(old,new)

here=pathlib.Path(__file__).resolve().parent
replace('<script src="./stockfish.js?v=5.10.0"', '<script src="./plenty-core.client.js"></script>\n<script src="./stockfish.js?v=5.10.0"')
replace('(()=>{\n"use strict";', '(()=>{\n"use strict";\n'+(here/'game_plenty_adapter.js').read_text())
for field in ['engineSelect', 'mobileEngineSelect']:
    old=f'<select id="{field}"><option value="stockfish" selected>Fairy-Stockfish</option><option value="reckless">Reckless · адаптований</option>'
    replace(old,old+'<option value="plenty">PlentyChess · експериментальний</option>')
replace("function selectedEngine(){return engineSelect.value==='reckless'?'reckless':'stockfish'}", "function selectedEngine(){return ['reckless','plenty'].includes(engineSelect.value)?engineSelect.value:'stockfish'}")
replace("function initSelectedEngine(){return activeEngine==='reckless'?initReckless():initFairy()}", "function initSelectedEngine(){return activeEngine==='plenty'?Promise.resolve(true):activeEngine==='reckless'?initReckless():initFairy()}")
replace("(selectedEngine()==='reckless'?", "(selectedEngine()==='plenty'?'PlentyChess: експериментальний. Рівні ще не відкалібровані.':selectedEngine()==='reckless'?")
replace('if(activeEngine==="reckless"){', '''if(activeEngine==="plenty"){
  label=plentyLastSearchOk===false?'PlentyChess: резервний ШІ · '+plentyFailureReason:
   'PlentyChess: '+(plentyLastSearchOk?'АКТИВНИЙ':'очікує першого ходу')+' · експериментальний';
  cls=plentyLastSearchOk===false?'fallback':plentyLastSearchOk?'active':'loading';
  for(const id of ['strengthHint','mobileStrengthHint'])document.getElementById(id).textContent='Для PlentyChess номери 1–48 задають бюджет пошуку. Сила та рейтинг ще не відкалібровані.';
 }else if(activeEngine==="reckless"){''')
replace(' cancelCameraGesture();\n activeEngine=selectedEngine();', ' cancelCameraGesture();\n discardPlenty();plentyLastSearchOk=null;plentyFailureReason="";\n activeEngine=selectedEngine();')
replace('function showResult(kind){', 'function showResult(kind){\n discardPlenty();')
replace('request.engine==="reckless"?recklessBestMove(request):fairyBestMove(request)', 'request.engine==="plenty"?plentyBestMove(request):request.engine==="reckless"?recklessBestMove(request):fairyBestMove(request)')
replace('   if(m){\n    if(shouldEngineResign(request)){', '   if(request.plentyTerminal){checkGameEnd();return;}\n   if(m){\n    if(shouldEngineResign(request)){')
replace('appVersion:"5.12.1"', 'appVersion:"5.12.2-plenty-preview"')
replace(":activeEngine==='reckless'?'Reckless Capablanca 1.0':'5.10.0'", ":activeEngine==='plenty'?'PlentyChess original core stage28 experimental':activeEngine==='reckless'?'Reckless Capablanca 1.0':'5.10.0'")
replace("activeEngine==='reckless'?`capablanca-10x${ROWS}-${variant()}`:fairyVariant()", "activeEngine!=='stockfish'?`capablanca-10x${ROWS}-${variant()}`:fairyVariant()")
replace("activeEngine==='reckless'?{ready:recklessReady", "activeEngine==='plenty'?{ready:plentyLastSearchOk===true,lastSearchOk:plentyLastSearchOk,reason:plentyFailureReason}:activeEngine==='reckless'?{ready:recklessReady")
replace('<p class="strengthHint">Fairy-Stockfish · GPLv3', '<p class="strengthHint">PlentyChess · GPLv3 · <a style="color:inherit" href="./plentychess-source-stage28.zip" download>Вихідний код PlentyChess</a> · Fairy-Stockfish · GPLv3')
assert not out.exists(), 'Refusing to overwrite preview'
shutil.copytree(base,out)
(out/'index.html').write_text(text)
for name in ['plenty-core.client.js','plenty-core.worker.js','game_plenty_adapter.js']:
    shutil.copy2(here/name,out/name)
shutil.copytree(here/'core-dist',out/'core-dist')
print(out)
