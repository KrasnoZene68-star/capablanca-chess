const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const script=fs.readFileSync(path.join(__dirname,'plenty-variant.worker.js'),'utf8');
const output=[],calls=[];
let currentScore=138,failVariant=false;
const fake={ccall(name,returnType,args=[],values=[]){
 calls.push({name,args,values});
 switch(name){
 case 'cp_set_variant': return failVariant?0:1;
 case 'cp_set_position': return 1;
 case 'cp_search': return 'e7d8';
 case 'cp_score': return currentScore;
 case 'cp_completed': return 1;
 case 'cp_depth': return 6;
 case 'cp_nodes': return 4270;
 case 'cp_error': return failVariant?'unsupported variant':'';
 default: throw Error(name);
 }
}};
const context={self:{postMessage:m=>output.push(m)},performance:{now:()=>1000},
 importScripts(file){assert.equal(file,'./plenty-variant.js')},CapablancaVariant:async()=>fake};
vm.runInNewContext(script,context,{filename:'plenty-variant.worker.js'});
const send=async payload=>{await context.self.onmessage({data:payload});return output.at(-1)};
(async()=>{
 assert.equal((await send({id:1,type:'init'})).engine,'plenty-variant-prototype-0.1');
 const fen='rnabqkbcnr/pppppppppp/10/10/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1 t2,2';
 const position=`position fen ${fen} moves a2a5 a9a6`;
 const payload={id:2,type:'search',variant:'capablanca10_both',fen,position,depth:6,time:200};
 const normal=await send(payload);
 assert.equal(normal.id,2);assert.equal(normal.move,'e7d8');
 assert.equal(normal.analysis.score.value,138);assert.equal(normal.analysis.completed,true);
 assert.equal(calls.find(x=>x.name==='cp_set_position').values[0],position);
 assert.deepEqual(Array.from(calls.find(x=>x.name==='cp_search').values),[6,200]);
 currentScore=-29995;
 const mated=await send({...payload,id:3});
 assert.equal(mated.analysis.score.unit,'mate');assert.equal(mated.analysis.score.value,-3);
 failVariant=true;
 const bad=await send({...payload,id:4,variant:'no_such_variant'});
 assert.equal(bad.error,'unsupported variant');
 assert.equal(output.length,4);
 console.log('Browser worker protocol mock: init, history, limits, mate score, error OK');
})().catch(e=>{console.error(e);process.exitCode=1});
