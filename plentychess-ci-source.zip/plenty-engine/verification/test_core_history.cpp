#include "../src/history.h"
#include "../src/evaluation.h"
#include <cassert>
#include <iostream>
#include <memory>
#include <stdexcept>

int main() {
    SharedHistory shared(1);
    auto h = std::make_unique<History>(0,&shared);
    h->initHistory();
    Board b{}; b.setVariant(10,true,true);
    SearchStack stack[8]{};
    auto ss = stack + 6;
    for (auto& e : stack) { e.movedPiece=NONE; e.move=Move::none(); }
    assert(h->getCorrectionValue(&b,ss) == 0);
    h->updateCorrectionHistory(&b,ss,100);
    assert(h->getCorrectionValue(&b,ss) > 0);
    assert(h->correctStaticEval(65535,1000,0) == h->correctStaticEval(100,1000,0));
    assert(h->correctStaticEval(0,28000,2147483647) == EVAL_TBWIN_IN_MAX_PLY-1);

    size_t checks = 0;
    // Exercise the full future coordinate range and all eight piece indices.
    for (Color side : {WHITE,BLACK}) for (Piece piece = PAWN; piece < TOTAL; ++piece) {
        for (int target = 0; target < 100; ++target) {
            auto entry = h->continuationEntry(true,true,side,piece,Square(target));
            assert(entry >= &h->continuationHistory[0][0] &&
                   entry <= &h->continuationHistory[CONTINUATION_CONTEXTS-1][0]);
            std::fill(entry,entry+CONTINUATION_STRIDE,0);
            (ss-1)->movedPiece = CHANCELLOR;
            (ss-1)->contHist = entry;
            Move m = Move::makeNormal(Square((target+1)%100),Square(target));
            h->updateContinuationHistory(ss,side,piece,m,100);
            const int index = 2*BOARD_CAPACITY*piece+2*target+side;
            assert(entry[index] == 100 && h->getContinuationHistory(ss,side,piece,m) == 200);
            h->setCounterMove(m,Move::makePromotion(89,99,CHANCELLOR));
            assert(h->getCounterMove(m).promotionPiece() == CHANCELLOR);
            ++checks;
        }
    }
    // Normal methods must address high ranks, promotions, compound pieces and emergency moves.
    for (const std::string fen : {
        "9k/8C1/10/10/10/10/10/10/10/K9 w - - 0 1 t0,0",
        "9k/8A1/10/10/10/10/10/10/10/K9 w - - 0 1 t0,0",
        "9k/P9/10/10/10/10/10/10/10/K9 w - - 0 1 t0,0",
        "k9/9c/10/10/10/10/10/10/8Q1/K9 b - - 0 1 t0,0"}) {
        b.parseFen(fen,false);
        for (Move m : b.legalMoves()) {
            if (b.isCapture(m)) {
                auto before = *h->getCaptureHistory(&b,m);
                h->updateSingleCaptureHistory(&b,m,200);
                assert(*h->getCaptureHistory(&b,m) > before);
            } else {
                auto before = h->getQuietHistory(m,b.stm,&b);
                h->updateQuietHistory(m,b.stm,&b,200);
                assert(h->getQuietHistory(m,b.stm,&b) > before);
                auto pawnBefore = h->getPawnHistory(&b,m);
                h->updatePawnHistory(&b,m,200);
                assert(h->getPawnHistory(&b,m) > pawnBefore);
            }
            ++checks;
        }
    }
    // Repeated lifecycle reset must leave no stale statistics.
    (ss-1)->movedPiece=NONE;
    for (int n=0;n<4;++n) { h->initHistory(); assert(h->getCorrectionValue(&b,ss)==0); }
    bool rejected=false;
    try { SharedHistory unsupported(2); } catch(const std::invalid_argument&) { rejected=true; }
    assert(rejected);
    ArrayVec<Move,2> bounded;
    bounded.add(Move::none()); bounded.add(Move::none());
    bounded.addIf(Move::none(),false);
    rejected=false;
    try { bounded.add(Move::none()); } catch(const std::length_error&) { rejected=true; }
    assert(rejected);
    std::cout << "native History: " << checks << " index/update checks, correction/clock/reset/lifecycle/capacity OK\n";
}
