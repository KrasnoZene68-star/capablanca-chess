#include "../src/evaluation.h"
#include "../src/variant_position.h"
#include <cassert>
#include <iostream>
#include <random>
#include <string>

using Ref = VariantPosition::Position;
using RefMove = VariantPosition::Move;
int value(char p) {
    size_t i = std::string("pnbrqkac").find(char(std::tolower(p)));
    return i == std::string::npos ? 0 : PIECE_VALUES[i];
}
std::string label(RefMove m) {
    std::ostringstream s; s << Square(m.from) << Square(m.to);
    if (m.promotion) s << char(std::tolower(m.promotion));
    return s.str();
}
int captured(const Ref& p, RefMove m) {
    int gain = m.special == RefMove::Special::EnPassant ? 100 : value(p.cells[m.to]);
    if (m.special == RefMove::Special::Escape) gain = -gain;
    if (m.promotion) gain += value(m.promotion) - 100;
    return gain;
}
int referenceReply(const Ref& p, int target) {
    if (std::tolower(p.cells[target]) == 'k') return 0;
    auto all = p.legalMoves();
    RefMove chosen{};
    int cost = 100000, origin = 100;
    bool found = false;
    for (const auto m : all) {
        if (m.to != target || m.special == RefMove::Special::Escape ||
            m.special == RefMove::Special::CastleLeft || m.special == RefMove::Special::CastleRight) continue;
        if (m.promotion && std::tolower(m.promotion) != 'q') continue;
        int nextCost = std::tolower(p.cells[m.from]) == 'k' ? 30000 : value(p.cells[m.from]);
        if (nextCost < cost || (nextCost == cost && m.from < origin)) {
            chosen = m; cost = nextCost; origin = m.from; found = true;
        }
    }
    return found ? std::max(0, captured(p,chosen) - referenceReply(p.after(chosen),target)) : 0;
}
void fixture(const std::string& fen, const std::string& move, int expected, bool knight=false, bool escape=false) {
    Board b{}; b.setVariant(10,knight,escape); b.parseFen(fen,false);
    Move m = stringToMove(move.c_str(),&b);
    if (!m) { std::cerr << "illegal SEE fixture: " << fen << " move " << move << '\n'; std::abort(); }
    int score = staticExchangeValue(&b,m);
    if (score != expected) { std::cerr << move << " expected " << expected << " got " << score << '\n'; std::abort(); }
    if (!m.isSpecial()) {
        assert(SEE(&b,m,expected) && !SEE(&b,m,expected+1));
    } else assert(SEE(&b,m,30000));
}
int main() {
    fixture("9k/10/10/10/10/10/10/4q5/4R5/K9 w - - 0 1 t0,0","e2e3",1000);
    fixture("9k/10/10/10/10/5p4/4p5/10/4Q5/K9 w - - 0 1 t0,0","e2e4",-900);
    fixture("9k/10/10/10/10/10/4a5/10/4R5/K9 w - - 0 1 t0,0","e2e4",725);
    fixture("9k/10/10/10/10/10/4c5/10/4R5/K9 w - - 0 1 t0,0","e2e4",835);
    // A knight component of an archbishop recaptures on e4.
    fixture("9k/10/10/10/5a4/10/4p5/10/4Q5/1K8 w - - 0 1 t0,0","e2e4",-900);
    // Same for a chancellor.
    fixture("9k/10/10/10/5c4/10/4p5/10/4Q5/K9 w - - 0 1 t0,0","e2e4",-900);
    // Rook component discovered after removing the first recapturing rook.
    fixture("9k/10/10/10/4c5/4r5/4p5/3P6/4Q5/K9 w - - 0 1 t0,0","e2e4",-470);
    // Pinned knight on f6 cannot move off the f-file to recapture e4.
    fixture("5k4/10/10/10/5n4/10/4p5/10/4Q5/K4R4 w - - 0 1 t0,0","e2e4",100);
    fixture("9k/P9/10/10/10/10/10/10/10/K9 w - - 0 1 t0,0","a9a10c",735);
    fixture("9k/10/10/4Pp4/10/10/10/10/10/K9 w - f8 0 1 t0,0","e7f8",100);
    fixture("9k/10/10/10/10/10/10/10/10/R4K3R w KQ - 0 1 t0,0","f1i1",0);

    size_t checked = 0;
    std::mt19937 random(25835);
    for (int height : {8,10}) for (int flags = 0; flags < 4; ++flags) {
        Board b{}; b.setVariant(height, flags & 1, flags & 2);
        for (int ply = 0; ply < 32; ++ply) {
            Ref p = Ref::fromFen({10,height}, b.fen(), flags & 1, flags & 2);
            auto moves = b.legalMoves();
            auto refMoves = p.legalMoves();
            for (Move m : moves) {
                if (m.isCastling()) continue;
                RefMove rm{}; bool found = false;
                for (auto candidate : refMoves) if (label(candidate) == m.toString(false)) { rm=candidate; found=true; break; }
                assert(found);
                int expected = captured(p,rm) - referenceReply(p.after(rm),rm.to);
                int actual = staticExchangeValue(&b,m);
                if (actual != expected) {
                    std::cerr << "SEE mismatch " << b.fen() << ' ' << m.toString(false) << ' ' << actual << '/' << expected << '\n'; std::abort();
                }
                ++checked;
            }
            if (moves.empty()) break;
            b.makeMove(moves[random() % moves.size()]);
        }
    }
    std::cout << "native SEE: 11 targeted fixtures and " << checked << " reference-LVA comparisons OK\n";
}
