#include "../src/board.h"
#include "../src/variant_position.h"
#include <algorithm>
#include <cassert>
#include <iostream>
#include <map>
#include <random>
#include <type_traits>

using Reference = VariantPosition::Position;
using RefMove = VariantPosition::Move;
static_assert(std::is_trivially_copyable<Board>::value, "upstream search copies Board by value");
static_assert(NO_SQUARE == 100 && Piece::TOTAL == 8 && sizeof(Move) == 4);
static size_t positions = 0, transitions = 0;

std::string label(const RefMove& m) {
    std::ostringstream out;
    out << Square(m.from) << Square(m.to);
    if (m.promotion) out << char(std::tolower(m.promotion));
    return out.str();
}
std::map<std::string, RefMove> refMoves(const Reference& p) {
    std::map<std::string, RefMove> result;
    for (const auto m : p.legalMoves()) assert(result.emplace(label(m), m).second);
    return result;
}
std::map<std::string, Move> coreMoves(const Board& b) {
    std::map<std::string, Move> result;
    for (Move m : b.legalMoves()) assert(result.emplace(m.toString(false), m).second);
    return result;
}
void equalState(Board b, const Reference& p) {
    assert(b.validateBoard() == 0);
    assert(b.geometry.height == p.geometry.height);
    assert((b.stm == WHITE) == p.redToMove);
    assert(b.kingKnight == p.kingKnight && b.emergencyEscape == p.emergencyEscape);
    assert(b.rule50_ply == p.halfmoveClock);
    assert(b.tripleRemaining[0] == p.tripleRemaining[0] && b.tripleRemaining[1] == p.tripleRemaining[1]);
    for (int i = 0; i < 4; ++i) assert(bool(b.castling & (1 << i)) == p.castle[i ^ 1]);
    Bitboard ep = 0;
    for (uint8_t s : p.enPassantTargets) ep |= bitboard(Square(s));
    assert(b.enpassantTarget == ep && b.enpassantCaptured == p.enPassantCaptured);
    const std::string symbols = "pnbrqkac";
    for (int s = 0; s < b.geometry.count(); ++s) {
        char actual = b.pieces[s] == NONE ? '.' : symbols[b.pieces[s]];
        if (b.byColor[WHITE] & bitboard(Square(s))) actual = char(std::toupper(actual));
        assert(actual == p.cells[s]);
    }
    assert(bool(b.checkers) == p.inCheck(p.redToMove));
    for (int s = 0; s < b.geometry.count(); ++s)
        assert(b.isSquareThreatened(Square(s)) == p.attacked(s, !p.redToMove));
    Board round = b;
    round.parseFen(b.fen(), false);
    assert(round.hashes.hash == b.hashes.hash && round.rule50Hash() == b.rule50Hash());
}
void compare(Board& b, const Reference& p) {
    ++positions;
    equalState(b, p);
    auto reference = refMoves(p);
    auto native = coreMoves(b);
    if (reference.size() != native.size()) {
        std::cerr << "move count mismatch " << b.fen() << ' ' << native.size() << '/' << reference.size() << '\n';
        for (auto [s,m] : reference) if (!native.count(s)) std::cerr << "missing " << s << '\n';
        for (auto [s,m] : native) if (!reference.count(s)) std::cerr << "extra " << s << '\n';
        std::abort();
    }
    const std::string before = b.fen();
    const Hash beforeHash = b.hashes.hash;
    for (const auto& [name, m] : native) {
        assert(reference.count(name));
        Board child = b;
        auto predicted = b.hashAfter(m);
        child.doMove(m, predicted.first, nullptr);
        assert(child.rule50Hash() == predicted.second);
        equalState(child, p.after(reference.at(name)));
        assert(b.givesCheck(m) == bool(child.checkers));
        assert(b.isPseudoLegal(m));
        ++transitions;
    }
    assert(b.fen() == before && b.hashes.hash == beforeHash);
}
void fixture(int height, const std::string& fen, bool knight = false, bool escape = false) {
    Board b{};
    b.setVariant(height, knight, escape);
    b.parseFen(fen, false);
    auto p = Reference::fromFen({10, height}, fen, knight, escape);
    compare(b, p);
}
Board load(int height, const std::string& fen, bool knight = false, bool escape = false) {
    Board b{}; b.setVariant(height, knight, escape); b.parseFen(fen, false); return b;
}
int main() {
    fixture(8, "r4k3r/10/10/10/10/10/10/R4K3R w KQkq - 0 1");
    fixture(10, "r4k3r/10/10/10/10/10/10/10/10/R4K3R b KQkq - 0 1 t2,2");
    fixture(8, "9k/5p4/10/4P5/10/10/10/K9 b - - 0 1");
    fixture(10, "9k/5p4/10/10/4P5/10/10/10/10/K9 b - - 0 1 t2,2");
    fixture(10, "9k/10/10/4P5/3p6/10/10/10/10/K9 w - d7d8 0 1 t2,1");
    fixture(10, "9k/10/10/10/10/3P6/4p5/10/10/K9 b - d3d4 0 1 t1,2");
    fixture(10, "9k/P9/10/10/10/10/10/10/9p/K9 w - - 0 1 t0,0");
    fixture(10, "9k/P9/10/10/10/10/10/10/9p/K9 b - - 0 1 t0,0");
    fixture(10, "4k5/10/10/4A5/10/3C6/10/10/10/4K5 w - - 99 40 t0,0", true, true);
    fixture(10, "10/p9/2p6p/1k1p4p1/10/10/6c3/7K2/10/9q w - - 8 82 t0,0", true, true);
    // Full-board emergency fixture, with both kings present and no normal evasion.
    const std::string trapped = "PPPPPPPPPk/PPPPPPPPPP/PPPPPPPPPP/PPPPPPPPPP/PPPPPPPPPP/PPPPPPnPPP/PPPPPRPRPP/PPPPPKPPPP w - - 99 1";
    fixture(8, trapped, false, true);
    Board escape = load(8, trapped, false, true);
    assert(!escape.legalMoves().empty());
    for (Move m : escape.legalMoves()) { assert(m.isEmergency()); Board next = escape; next.makeMove(m); assert(next.rule50_ply == 0); }

    std::mt19937 rng(240027);
    for (int height : {8,10}) for (int flags = 0; flags < 4; ++flags) {
        Board b{}; b.setVariant(height, flags & 1, flags & 2);
        Reference p = Reference::fromFen({10,height}, b.fen(), flags & 1, flags & 2);
        for (int ply = 0; ply < 96; ++ply) {
            compare(b, p);
            auto native = coreMoves(b);
            if (native.empty()) break;
            auto chosen = std::next(native.begin(), rng() % native.size());
            RefMove ref = refMoves(p).at(chosen->first);
            b.makeMove(chosen->second); p = p.after(ref);
        }
    }
    // Repetition key excludes clocks, includes rules/budget, and normalizes pinned EP.
    const std::string prefix = "9k/10/10/K3Pp3r/10/10/10/10/10/10 w - ";
    Board plain = load(10, prefix + "- 0 1 t2,2");
    Board pinned = load(10, prefix + "f8 0 1 t2,2");
    assert(plain.hashes.hash == pinned.hashes.hash);
    for (Move m : pinned.legalMoves()) assert(!m.isEnpassant());
    Board clocked = load(10, prefix + "- 99 1 t2,2");
    assert(plain.hashes.hash == clocked.hashes.hash && plain.rule50Hash() != clocked.rule50Hash());
    Board budget = load(10, prefix + "- 0 1 t1,2");
    assert(plain.hashes.hash != budget.hashes.hash);
    Board rules = load(10, prefix + "- 0 1 t2,2", true, true);
    assert(plain.hashes.hash != rules.hashes.hash);
    Board ep = load(8, "9k/10/10/4Pp4/10/10/10/K9 w - f6 0 1");
    Board noEp = load(8, "9k/10/10/4Pp4/10/10/10/K9 w - - 0 1");
    assert(ep.hashes.hash != noEp.hashes.hash);
    ep.doNullMove();
    assert(!ep.enpassantTarget && ep.enpassantCaptured == NO_SQUARE && ep.nullmove_ply == 0 && ep.validateBoard() == 0);
    Board overflow = load(10, prefix + "- 65535 4294967295 t2,2");
    overflow.doNullMove(); assert(overflow.rule50_ply == 65535);
    assert(stringToSquare("j10") == 99 && stringToSquare("k10") == NO_SQUARE);
    assert(Move::makePromotion(89,99,CHANCELLOR).toString(false) == "j9j10c");
    assert(Move::makeCastling(95,99).toString(false) == "f10i10");
    Board castles = load(10, "r4k3r/10/10/10/10/10/10/10/10/R4K3R b KQkq - 0 1 t2,2");
    Move castle = stringToMove("f10i10", &castles);
    assert(castle && castle.isCastling());
    castles.makeMove(castle);
    assert(castles.ply == 2 && castles.pieces[98] == KING && castles.pieces[97] == ROOK);
    Board promotion = load(10, "9k/P9/10/10/10/10/10/10/10/K9 w - - 0 1 t0,0");
    int promotions = 0;
    MoveList tactical;
    generateMoves(&promotion, tactical, true);
    for (Move m : tactical) if (m.isPromotion()) ++promotions;
    assert(promotions == 6);
    for (int from = 0; from < 100; ++from) for (int to = 0; to < 100; ++to) {
        for (Piece p : {KNIGHT, BISHOP, ROOK, QUEEN, ARCHBISHOP, CHANCELLOR}) {
            Move m = Move::makePromotion(Square(from), Square(to), p);
            assert(m.origin() == from && m.target() == to && m.promotionPiece() == p);
        }
        Move e = Move::makeEmergency(Square(from), Square(to));
        assert(e.origin() == from && e.target() == to && e.isEmergency());
    }
    for (const std::string bad : {"9k/10/10/10/10/10/10/K9 x - - 0 1",
         "9k/10/10/10/10/10/10/K9 w - - 0 1 t9,2", "10/10/10/10/10/10/10/K9 w - - 0 1"}) {
        const auto before = ep.fen();
        bool rejected = false;
        try { ep.parseFen(bad, false); } catch (const std::invalid_argument&) { rejected = true; }
        assert(rejected && ep.fen() == before);
    }
    std::cout << "native Board: " << positions << " positions, " << transitions << " successor states matched; hash/null/codec/parser checks OK\n";
}
