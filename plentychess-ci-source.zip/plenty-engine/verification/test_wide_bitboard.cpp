#include "../src/bitboard.h"
#include <cassert>
#include <iostream>

int main() {
    for (int s = 0; s < 100; ++s) {
        Bitboard bb = bitboard(static_cast<Square>(s));
        assert(lsb(bb) == s && msb(bb) == s);
        assert(BB::popcount(bb) == 1);
        assert(popLSB(&bb) == s && bb == 0);
    }
    Bitboard bb = bitboard(Square(0)) | bitboard(Square(63)) |
                  bitboard(Square(64)) | bitboard(Square(79)) | bitboard(Square(99));
    assert(BB::popcount(bb) == 5);
    assert(msb(bb) == 99);
    for (int expected : {0, 63, 64, 79, 99}) {
        assert(popLSB(&bb) == expected);
    }
    assert(bb == 0);
    std::cout << "wide bitboard 0..99: OK\n";
}
