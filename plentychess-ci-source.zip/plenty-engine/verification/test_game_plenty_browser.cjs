const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]);
const server=http.createServer((req,res)=>{
 res.setHeader('Cross-Origin-Opener-Policy','same-origin');res.setHeader('Cross-Origin-Embedder-Policy','require-corp');
 const name=new URL(req.url,'http://localhost').pathname;
 if(name==='/coi-serviceworker.js'){res.setHeader('Content-Type','application/javascript');res.end('// Headers provide isolation in this test');return;}
 const file=path.resolve(root,'.'+(name==='/'?'/index.html':name));
 if(!file.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
 fs.readFile(file,(err,data)=>{if(err){res.writeHead(404);res.end();return;}res.setHeader('Content-Type',file.endsWith('.html')?'text/html':file.endsWith('.wasm')?'application/wasm':'application/javascript');
  // Test-only access to lexical game state. Never written into delivered files.
  if(file.endsWith('.html'))data=data.toString().replace('reset();\n})();','reset();\nwindow.__testRun=code=>eval(code);\n})();');
  res.end(data);});
});
(async()=>{
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));let browser;
 try{
  browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH,headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});
  const page=await browser.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:'+server.address().port,{waitUntil:'networkidle'});
  let plies=0;
  for(const height of [8,10])for(const rule of ['classic','kingKnight','escape','both']){
   await page.evaluate(code=>__testRun(code),`(()=>{const height=${height},rule=${JSON.stringify(rule)};
    engineSelect.value=mobileEngineSelect.value='plenty';modeEl.value='ai';humanSideEl.value='g';
    boardSizeEl.value=String(height);variantEl.value=rule;strengthEl.value='1';reset();
   })()`);
   await page.waitForFunction(()=>__testRun('history.length')===1,null,{timeout:20000});
   const first=await page.evaluate(()=>__testRun('gameReport()'));
   assert.equal(first.engine,'plenty');assert.match(first.moves[0].engine.name,/PlentyChess/);
   assert.equal(first.moves[0].engine.analysis.score,undefined);
   assert.equal(first.engineStatus.lastSearchOk,true);
   await page.evaluate(()=>__testRun('commitMove(allLegalMoves(state,turn,epSquare)[0])'));
   await page.waitForFunction(()=>__testRun('history.length')===3,null,{timeout:20000});
   const next=await page.evaluate(()=>__testRun('gameReport()'));
   assert.match(next.moves[2].engine.name,/PlentyChess/);assert.equal(next.moves[2].beforeFen,next.moves[1].afterFen);
   plies+=3;
  }
  // Reset while an old worker is computing; stale result cannot enter the new game.
  await page.evaluate(()=>__testRun(`(()=>{
   strengthEl.value='48';humanSideEl.value='g';reset();void aiTurn();
   humanSideEl.value='r';reset();
  })()`));
  await page.waitForTimeout(500);
  assert.equal(await page.evaluate(()=>__testRun('history.length')),0);
  assert.equal(await page.evaluate(()=>__testRun('activeEngine')),'plenty');
  for(const engine of ['stockfish','reckless']){
   await page.evaluate(engine=>__testRun(`engineSelect.value=${JSON.stringify(engine)};strengthEl.value='1';humanSideEl.value='g';boardSizeEl.value='8';variantEl.value='classic';reset();`),engine);
   await page.waitForFunction(()=>__testRun('history.length')===1,null,{timeout:30000});
   const report=await page.evaluate(()=>__testRun('gameReport()'));
   assert.equal(report.engine,engine);
   assert.equal(report.moves[0].engine.name,engine==='stockfish'?'Fairy-Stockfish':'Reckless');
  }
  assert.deepEqual(errors,[]);
  console.log(`PASS REAL game preview + Plenty WASM: ${plies} plies, all 8 configurations, recorded history, reset cancellation; Fairy and Reckless still play`);
 }finally{if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));}
})().catch(e=>{console.error(e);process.exitCode=1;});
