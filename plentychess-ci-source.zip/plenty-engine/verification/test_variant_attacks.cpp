#include "../src/variant_attacks.h"
#include "../src/bitboard.h"
#include <cassert>
#include <iostream>

using namespace CapablancaPort;
using namespace VariantAttacks;

int main() {
    for (const Geometry g : {Board10x8, Board10x10}) {
        const int a1 = g.square(0, 0), j1 = g.square(9, 0);
        const int e5 = g.square(4, 4);
        assert(BB::popcount(knight(g, a1)) == 2);
        assert(BB::popcount(king(g, a1)) == 3);
        assert(BB::popcount(king(g, a1, true)) == 5);
        assert(BB::popcount(rook(g, a1, 0)) == g.width + g.height - 2);
        assert(BB::popcount(bishop(g, a1, 0)) == g.height - 1);
        assert(BB::popcount(pawn(g, a1, true)) == 1);
        assert(BB::popcount(pawn(g, j1, true)) == 1);
        const Bitboard block = bitboard(Square(g.square(0, 2)));
        auto ray = rook(g, a1, block);
        assert(ray & block);
        assert(!(ray & bitboard(Square(g.square(0, 3)))));
        assert(chancellor(g, e5, 0) == (rook(g, e5, 0) | knight(g, e5)));
        assert(archbishop(g, e5, 0) == (bishop(g, e5, 0) | knight(g, e5)));
        for (int square = 0; square < g.count(); ++square) {
            assert(!(knight(g, square) & bitboard(Square(square))));
            assert(!(king(g, square, true) & bitboard(Square(square))));
            assert(!(rook(g, square, 0) & bitboard(Square(square))));
            assert(!(bishop(g, square, 0) & bitboard(Square(square))));
        }
    }
    std::cout << "variant geometric attacks: OK\n";
}
