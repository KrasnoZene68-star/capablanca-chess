#!/bin/sh
set -eu
if ! command -v em++ >/dev/null 2>&1; then
  echo 'Emscripten (em++) is required to build the browser prototype.' >&2
  exit 1
fi
cd "$(dirname "$0")"
em++ -std=c++17 -O2 variant_web.cpp -o plenty-variant.js \
  -sMODULARIZE=1 -sEXPORT_NAME=CapablancaVariant -sENVIRONMENT=worker,node \
  -sALLOW_MEMORY_GROWTH=1 \
  '-sEXPORTED_FUNCTIONS=["_cp_error","_cp_set_variant","_cp_set_position","_cp_search","_cp_depth","_cp_score","_cp_completed","_cp_nodes"]' \
  '-sEXPORTED_RUNTIME_METHODS=["ccall"]'
echo 'Built plenty-variant.js and plenty-variant.wasm; browser execution is not validated here.'
