// Differential perft against the actual v5.12.0 JavaScript rules.
const fs = require('fs'), vm = require('vm'), cp = require('child_process'), path = require('path');
const source = fs.readFileSync(path.join(__dirname, 'compare_existing_game.cjs'), 'utf8');
// Reuse the tested FEN bridge and fixed cases without running the 250-case loop.
const bridge = source.slice(source.indexOf('function parseFen('), source.indexOf('let seed ='));
const scope = {console};
vm.createContext(scope);
vm.runInContext(bridge, scope);
const rules = fs.readFileSync(path.join(__dirname, 'game_rules_v5_12_0.js'), 'utf8');
const run = process.env.VARIANT_PERFT_BINARY || path.join(__dirname, 'variant_perft');
let total = 0;
for (const [caseIndex, [rows, variantName, fen]] of vm.runInContext('cases', scope).entries()) {
  const {s, color, ep} = scope.parseFen(rows, fen);
  const ctx = {ROWS: rows, variant: () => variantName, epSquare: ep, s, color, ep};
  vm.createContext(ctx);
  vm.runInContext(rules + `
function perft(s,color,ep,depth) {
 if (!depth) return 1;
 let total = 0;
 for(const m of allLegalMoves(s,color,ep)) {
   // Current UI emits a pseudo capture of a king in some constructed states.
   if (s[m.tr][m.tc]?.t === 'K') continue;
   const next=applyMove(s,m,ep,true);
   total += perft(next.s,enemy(color),next.ep,depth-1);
 }
 return total;
}`, ctx);
  for (const depth of caseIndex < 8 ? [1, 2, 3] : [1, 2]) {
    const js = vm.runInContext(`perft(s,color,ep,${depth})`, ctx);
    const cpp = Number(cp.execFileSync(run, [String(rows), variantName, String(depth), fen], {encoding:'utf8'}));
    if (js !== cpp) {
      console.error({rows,variantName,fen,depth,js,cpp});
      process.exitCode = 1;
    }
    total++;
  }
}
if (!process.exitCode) console.log(`${total} perft comparisons at depths 1–3 matched`);
