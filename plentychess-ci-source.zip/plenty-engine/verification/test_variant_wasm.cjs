// Execute only after Emscripten builds plenty-variant.js/.wasm.
const assert=require('node:assert/strict');
const createEngine=require('./plenty-variant.js');
(async()=>{
 const engine=await createEngine();
 const call=(name,kind,args=[],values=[])=>engine.ccall('cp_'+name,kind,args,values);
 assert.equal(call('set_variant','number',['string'],['capablanca10_both']),1);
 const start='rnabqkbcnr/pppppppppp/10/10/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1 t2,2';
 assert.equal(call('set_position','number',['string'],[`position fen ${start} moves a2a5 a9a6`]),1,call('error','string'));
 const move=call('search','string',['number','number'],[1,1000]);
 assert.match(move,/^[a-j](?:10|[1-9])[a-j](?:10|[1-9])[qrbnac]?$/);
 assert.equal(call('completed','number'),1);
 console.log('WASM Node smoke test OK:',move);
})().catch(e=>{console.error(e);process.exitCode=1});
