// Transport MOCK only, not a browser execution test.
const assert=require('node:assert/strict');
const Client=require('./plenty-core.client.js');
const workers=[];
class MockWorker {
  constructor(){workers.push(this);}
  postMessage(request){this.request=request;}
  terminate(){this.dead=true;}
  reply(extra={}){this.onmessage({data:{id:this.request.id,type:'result',...extra}});}
}
(async()=>{
  const c=new Client('test',MockWorker);
  const p1=c.search({});const rejected=assert.rejects(p1,/Superseded/);
  const old=workers[0];const p2=c.search({});await rejected;assert.ok(old.dead);
  old.reply();assert.ok(c.pending); // late message from dead worker ignored
  workers[1].reply({move:'a2a3'});assert.equal((await p2).move,'a2a3');
  const p3=c.search({});assert.equal(workers.length,2);
  const cancelled=assert.rejects(p3,/cancelled/);c.cancel();await cancelled;
  const p4=c.search({},5);await assert.rejects(p4,/timed out/);assert.ok(workers[2].dead);
  const p5=c.search({});const errored=assert.rejects(p5,/bad position/);
  workers[3].reply({type:'error',error:'bad position'});await errored;
  const p6=c.search({});workers[4].reply();await p6;c.cancel();
  console.log('PASS client transport MOCK: supersede, stale replies, reuse, cancel, timeout, error recovery');
})().catch(e=>{console.error(e);process.exitCode=1;});
