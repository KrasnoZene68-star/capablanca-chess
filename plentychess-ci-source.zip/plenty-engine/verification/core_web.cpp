// Separate ABI for the ORIGINAL search.cpp CAPABLANCA_CORE build.
// One instance per dedicated worker. Not a thread-safe public C API.
#include "../src/thread.h"
#include <memory>
#include <sstream>
#include <stdexcept>

namespace {
Board board{};
bool configured=false, positioned=false;
std::vector<Hash> past;
std::unique_ptr<Worker> worker;
CoreSearchResult result;
std::string error, best, pv, fen;
void clearResult() { result={}; best.clear(); pv.clear(); error.clear(); }
}
extern "C" {
const char* pc_evaluator() {
#if defined(CAPABLANCA_POSITIONAL_EVAL) && !defined(CAPABLANCA_BASELINE_EVAL)
    return "handcrafted-tapered-v1";
#else
    return "material-center-v1";
#endif
}
const char* pc_error() { return error.c_str(); }
int pc_variant(int height,int flags) {
    clearResult(); positioned=false; configured=false; past.clear();
    try {
        if((height!=8 && height!=10) || flags<0 || flags>3) throw std::invalid_argument("Invalid variant");
        Board next{};next.setVariant(height,flags&1,flags&2);
        board=next;configured=true;return 1;
    } catch(const std::exception& e) {error=e.what();return 0;}
}
// Explicit base FEN plus legal coordinate moves, NOT a guessed
// repetition counter. Failure invalidates search until a valid position arrives.
int pc_position(const char* base,const char* moves) {
    clearResult();positioned=false;
    try {
        if(!configured || !base || !moves) throw std::invalid_argument("Missing variant or position");
        Board next=board;
        // startpos is deliberately unsupported: callers send the exact initial FEN.
        next.parseFen(base,false);
        std::vector<Hash> history;
        std::istringstream input(moves);std::string token;
        while(input>>token) {
            if(history.size()>=10000) throw std::invalid_argument("Move history too long");
            Move m=stringToMove(token.c_str(),&next);
            if(!m || !next.isLegal(m)) throw std::invalid_argument("Illegal move: "+token);
            history.push_back(next.hashes.hash); next.makeMove(m);
        }
        board=next;past=std::move(history);positioned=true;return 1;
    } catch(const std::exception& e) {error=e.what();return 0;}
}
const char* pc_search(int depth,int milliseconds,int nodes) {
    clearResult();
    try {
        if(!positioned) throw std::invalid_argument("Set a valid position first");
        if(depth<0 || depth>=MAX_PLY || milliseconds<0 || milliseconds>86400000 || nodes<0)
            throw std::invalid_argument("Invalid search limits");
        if(!worker) worker=std::make_unique<Worker>();
        SearchParameters limits;limits.depth=depth;limits.movetime=milliseconds;
        limits.nodes=nodes;limits.infinite=false;
        result=worker->run(board,limits,past);
        best=result.move ? result.move.toString(false) : "0000";
        for(Move m:result.pv) {if(!pv.empty())pv+=' ';pv+=m.toString(false);}
        return best.c_str();
    } catch(const std::exception& e) {clearResult();error=e.what();return "";}
}
int pc_depth() {return result.depth;}
int pc_score() {return result.score;}
int pc_completed() {return result.completed;}
int pc_terminal() {return result.terminal;}
double pc_nodes() {return static_cast<double>(result.nodes);}
const char* pc_pv() {return pv.c_str();}
const char* pc_fen() {fen=positioned?board.fen():"";return fen.c_str();}
}
