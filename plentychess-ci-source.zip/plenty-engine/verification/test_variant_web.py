"""Native ABI smoke tests; WASM compilation/browser execution are separate."""
from ctypes import CDLL, c_char_p, c_double, c_int
from pathlib import Path

lib = CDLL(str(Path(__file__).with_name('libvariant_web.so')))
lib.cp_set_variant.argtypes = [c_char_p]
lib.cp_set_variant.restype = c_int
lib.cp_set_position.argtypes = [c_char_p]
lib.cp_set_position.restype = c_int
lib.cp_search.argtypes = [c_int, c_int]
lib.cp_search.restype = c_char_p
lib.cp_error.restype = c_char_p
lib.cp_score.restype = c_int
lib.cp_depth.restype = c_int
lib.cp_completed.restype = c_int
lib.cp_nodes.restype = c_double

start10 = b'rnabqkbcnr/pppppppppp/10/10/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1 t2,2'
assert not lib.cp_set_variant(b'unsupported')
for board in (b'capablanca', b'capablanca10'):
    for suffix in (b'', b'_kingknight', b'_escape', b'_both'):
        assert lib.cp_set_variant(board + suffix), lib.cp_error()
assert lib.cp_set_variant(b'capablanca10_both'), lib.cp_error()
assert lib.cp_set_position(b'position fen ' + start10 + b' moves a2a5 a9a6'), lib.cp_error()
move = lib.cp_search(2, 1000)
assert move != b'0000' and lib.cp_completed() and lib.cp_depth() >= 1, (move, lib.cp_error())
assert lib.cp_nodes() > 0

mate = b'10/3p1n4/1p8/9P/7kPK/7P2/10/8q1 b - - 0 72'
assert lib.cp_set_variant(b'capablanca_both')
assert lib.cp_set_position(mate)
assert lib.cp_search(2, 1000).startswith(b'i1')
assert lib.cp_score() >= 29996
assert lib.cp_set_position(b'position fen ' + mate + b' moves i1j1')
assert lib.cp_search(2, 1000) == b'0000'
assert lib.cp_score() == -30000
print('C ABI: 10x10 move history, 10x8 mate and terminal state OK')
