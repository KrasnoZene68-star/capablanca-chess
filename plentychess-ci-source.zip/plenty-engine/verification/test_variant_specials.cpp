#include "../src/variant_position.h"
#include <cassert>
#include <iostream>

using namespace CapablancaPort;
using namespace VariantPosition;

int main() {
    const auto castles = Position::fromFen(Board10x8,
        "9k/10/10/10/10/10/10/R4K3R w KQ - 0 1");
    int castleCount = 0;
    for (const auto m : castles.legalMoves()) {
        if (m.special == VariantPosition::Move::Special::CastleLeft || m.special == VariantPosition::Move::Special::CastleRight) {
            ++castleCount;
            const auto after = castles.after(m);
            assert(!after.castle[0] && !after.castle[1]);
            assert(after.cells[Board10x8.square(m.special == VariantPosition::Move::Special::CastleLeft ? 3 : 7, 0)] == 'R');
        }
    }
    assert(castleCount == 2);

    const auto doubleStart = Position::fromFen(Board10x8,
        "9k/5p4/10/4P5/10/10/10/K9 b - - 0 1");
    int doubleCount = 0;
    for (const auto m : doubleStart.legalMoves()) {
        if (m.from != Board10x8.square(5, 6) || m.special != VariantPosition::Move::Special::Double) continue;
        ++doubleCount;
        const auto after = doubleStart.after(m);
        bool epFound = false;
        for (const auto reply : after.legalMoves()) {
            if (reply.special != VariantPosition::Move::Special::EnPassant) continue;
            epFound = true;
            const auto captured = after.after(reply);
            assert(captured.cells[Board10x8.square(5, 4)] == '.');
            assert(captured.cells[Board10x8.square(5, 5)] == 'P');
        }
        assert(epFound);
    }
    assert(doubleCount == 1);

    const auto tripleStart = Position::fromFen(Board10x10,
        "9k/5p4/10/10/4P5/10/10/10/10/K9 b - - 0 1 t2,2");
    int tripleCount = 0;
    for (const auto m : tripleStart.legalMoves()) {
        if (m.from != Board10x10.square(5, 8) || m.special != VariantPosition::Move::Special::Triple) continue;
        ++tripleCount;
        const auto after = tripleStart.after(m);
        assert(after.tripleRemaining[1] == 1 && after.enPassantTargets.size() == 2);
        bool epFound = false;
        for (const auto reply : after.legalMoves()) {
            if (reply.special != VariantPosition::Move::Special::EnPassant) continue;
            epFound = true;
            const auto captured = after.after(reply);
            assert(captured.cells[Board10x10.square(5, 5)] == '.');
            assert(captured.cells[Board10x10.square(5, 6)] == 'P');
        }
        assert(epFound);
    }
    assert(tripleCount == 1);
    auto exhausted = tripleStart;
    exhausted.tripleRemaining[1] = 0;
    for (const auto m : exhausted.legalMoves())
        assert(m.special != VariantPosition::Move::Special::Triple);
    Position trapped(Board10x8);
    trapped.cells.fill('P');
    trapped.cells[Board10x8.square(5, 0)] = 'K';
    trapped.cells[Board10x8.square(6, 2)] = 'n';
    trapped.cells[Board10x8.square(5, 1)] = 'R';
    trapped.cells[Board10x8.square(7, 1)] = 'R';
    trapped.emergencyEscape = true;
    assert(trapped.inCheck(true));
    assert(trapped.regularLegalMoves().empty());
    const auto escapes = trapped.legalMoves();
    assert(!escapes.empty());
    for (const auto m : escapes) {
        assert(m.special == VariantPosition::Move::Special::Escape);
        assert(!trapped.after(m).inCheck(true));
        auto clocked = trapped;
        clocked.halfmoveClock = 99;
        assert(clocked.after(m).halfmoveClock == 0); // emergency replacement takes own piece
    }
    std::cout << "castling, double and triple en passant: OK\n";
}
