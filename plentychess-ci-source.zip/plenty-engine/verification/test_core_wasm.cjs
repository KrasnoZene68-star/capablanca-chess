// Run ONLY after build_core_web.sh wasm. No mock/fallback implementation.
const assert = require('node:assert/strict');
const factory = require('./core-dist/plenty-core.js');
(async () => {
  const m = await factory({wasmBinary:require('node:fs').readFileSync(__dirname+'/core-dist/plenty-core.wasm')});
  const call = (n,r,t=[],a=[])=>m.ccall('pc_'+n,r,t,a);
  const evaluator=call('evaluator','string');
  assert.equal(evaluator,process.env.EXPECTED_EVALUATOR || 'material-center-v1');
  let runs=0;
  for(const height of [8,10]) for(let flags=0;flags<4;flags++) {
    assert.equal(call('variant','number',['number','number'],[height,flags]),1);
    const start='rnabqkbcnr/pppppppppp/'+'10/'.repeat(height-4)+'PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1'+(height===10?' t2,2':'');
    for(const repetitions of [0,1,2]) {
      const cycle=`b1c3 b${height}c${height-2} c3b1 c${height-2}b${height} `;
      assert.equal(call('position','number',['string','string'],[start,cycle.repeat(repetitions)]),1);
      const move=call('search','string',['number','number','number'],[1,10000,0]);
      assert.ok(move,call('error','string'));
      assert.equal(move==='0000',repetitions===2);
      assert.equal(!!call('terminal','number'),repetitions===2);
      runs++;
    }
  }
  assert.equal(call('variant','number',['number','number'],[8,2]),1);
  const escape='PPPPPPPPPk/PPPPPPPPPP/PPPPPPPPPP/PPPPPPPPPP/PPPPPPPPPP/PPPPPPnPPP/PPPPPRPRPP/PPPPPKPPPP w - - 99 1';
  assert.equal(call('position','number',['string','string'],[escape,'']),1);
  const escaped=call('search','string',['number','number','number'],[2,10000,0]);
  assert.ok(escaped&&escaped!=='0000',call('error','string'));runs++;
  assert.equal(call('position','number',['string','string'],['bad fen','']),0);
  assert.equal(call('search','string',['number','number','number'],[1,1000,0]),'');
  assert.equal(call('completed','number'),0);
  assert.equal(call('pv','string'),'');
  assert.equal(call('position','number',['string','string'],[escape,'']),1);
  assert.equal(call('search','string',['number','number','number'],[2,10000,0]),escaped);runs++;
  console.log(`PASS REAL WASM original core: ${runs} searches; emergency, exception recovery; heap ${m.HEAPU8.buffer.byteLength} bytes`);
})().catch(e=>{console.error(e);process.exitCode=1;});
