#include "../src/variant_position.h"
#include <cstdint>
#include <iostream>
#include <stdexcept>

uint64_t perft(const VariantPosition::Position& p, int depth) {
    if (depth == 0) return 1;
    uint64_t total = 0;
    for (const auto move : p.legalMoves()) {
        // The current game's JavaScript move generator makes one promotion
        // choice (queen) during search; the UI asks for a choice separately.
        if (move.promotion && std::tolower(move.promotion) != 'q') continue;
        total += perft(p.after(move), depth - 1);
    }
    return total;
}

int main(int argc, char** argv) {
    if (argc != 5) return 2;
    try {
        const CapablancaPort::Geometry g{10, std::stoi(argv[1])};
        const std::string v = argv[2];
        auto p = VariantPosition::Position::fromFen(g, argv[4],
            v == "kingKnight" || v == "both", v == "escape" || v == "both");
        std::cout << perft(p, std::stoi(argv[3])) << '\n';
    } catch (const std::exception& ex) {
        std::cerr << ex.what() << '\n';
        return 1;
    }
}
