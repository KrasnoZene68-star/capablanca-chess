// Extracted unchanged from v5.12.0 game move rules for differential tests.
const ORTH=[[1,0],[-1,0],[0,1],[0,-1]];
const DIAG=[[1,1],[1,-1],[-1,1],[-1,-1]];
const KN=[[2,1],[2,-1],[-2,1],[-2,-1],[1,2],[1,-2],[-1,2],[-1,-2]];
function enemy(c){return c==="r"?"g":"r"}

function inside(r,c){return r>=0&&r<ROWS&&c>=0&&c<10}

function tripleBudget(s){return s.tripleRemaining||{r:ROWS===10?2:0,g:ROWS===10?2:0}}

function cloneState(s){const ns=s.map(row=>row.map(p=>p?{...p}:null));ns.tripleRemaining={...tripleBudget(s)};ns.halfmoveClock=s.halfmoveClock||0;ns.fullmoveNumber=s.fullmoveNumber||1;return ns}

function findKing(s,color){
 for(let r=0;r<ROWS;r++)for(let c=0;c<10;c++)if(s[r][c]&&s[r][c].c===color&&s[r][c].t==="K")return[r,c];
 return null;
}

function attacksSquare(s,color,tr,tc){
 for(let r=0;r<ROWS;r++)for(let c=0;c<10;c++){
  const p=s[r][c]; if(!p||p.c!==color)continue;
  if(p.t==="P"){
   const d=color==="r"?-1:1;
   if((r+d===tr)&&(c-1===tc||c+1===tc))return true;
   continue;
  }
  if(p.t==="K"){
   for(const [dr,dc] of ORTH.concat(DIAG))if(r+dr===tr&&c+dc===tc)return true;
   if(["kingKnight","both"].includes(variant()))for(const [dr,dc] of KN)if(r+dr===tr&&c+dc===tc)return true;
   continue;
  }
  const ray=(dirs)=>{
   for(const [dr,dc] of dirs){
    let rr=r+dr,cc=c+dc;
    while(inside(rr,cc)){
     if(rr===tr&&cc===tc)return true;
     if(s[rr][cc])break;
     rr+=dr;cc+=dc;
    }
   }
   return false;
  };
  if(["R","Q","C"].includes(p.t)&&ray(ORTH))return true;
  if(["B","Q","A"].includes(p.t)&&ray(DIAG))return true;
  if(["N","A","C"].includes(p.t))for(const [dr,dc] of KN)if(r+dr===tr&&c+dc===tc)return true;
 }
 return false;
}

function inCheck(s,color){
 const k=findKing(s,color);
 return !k || attacksSquare(s,enemy(color),k[0],k[1]);
}

function pseudoMoves(s,r,c,includeCastle=true,ep=epSquare){
 const p=s[r][c], out=[]; if(!p)return out;
 const color=p.c;
 const push=(rr,cc,special=null)=>{if(inside(rr,cc)&&(!s[rr][cc]||s[rr][cc].c!==color))out.push({r:rr,c:cc,special})};
 const slide=(dirs)=>{
  for(const [dr,dc] of dirs){
   let rr=r+dr,cc=c+dc;
   while(inside(rr,cc)){
    if(!s[rr][cc])out.push({r:rr,c:cc});
    else{if(s[rr][cc].c!==color)out.push({r:rr,c:cc});break}
    rr+=dr;cc+=dc;
   }
  }
 };

 if(p.t==="P"){
  const d=color==="r"?-1:1, start=color==="r"?ROWS-2:1;
  if(inside(r+d,c)&&!s[r+d][c]){
   out.push({r:r+d,c});
   if(r===start&&!s[r+2*d][c]){
    out.push({r:r+2*d,c,special:"double"});
    if(ROWS===10&&tripleBudget(s)[color]>0&&!s[r+3*d][c])out.push({r:r+3*d,c,special:"triple"});
   }
  }
  for(const dc of [-1,1]){
   const rr=r+d,cc=c+dc;
   if(inside(rr,cc)&&s[rr][cc]&&s[rr][cc].c!==color)out.push({r:rr,c:cc});
   if(ep&&inside(rr,cc)&&(ep.targets||[ep]).some(t=>t.r===rr&&t.c===cc)&&!s[rr][cc]&&s[ep.capR]?.[cc]?.t==="P"&&s[ep.capR][cc].c!==color)out.push({r:rr,c:cc,special:"ep"});
  }
 }
 if(["R","Q","C"].includes(p.t))slide(ORTH);
 if(["B","Q","A"].includes(p.t))slide(DIAG);
 if(["N","A","C"].includes(p.t))for(const [dr,dc] of KN)push(r+dr,c+dc);
 if(p.t==="K"){
  for(const [dr,dc] of ORTH.concat(DIAG))push(r+dr,c+dc);
  if(["kingKnight","both"].includes(variant()))for(const [dr,dc] of KN)push(r+dr,c+dc);
  if(includeCastle&&!p.m&&!inCheck(s,color)){
   const home=color==="r"?ROWS-1:0;
   if(r===home&&c===5){
    // long: K f->c, R a->d
    const rookL=s[home][0];
    if(rookL&&rookL.c===color&&rookL.t==="R"&&!rookL.m&&[1,2,3,4].every(x=>!s[home][x])){
     if([4,3,2].every(x=>!attacksSquare(s,enemy(color),home,x)))out.push({r:home,c:2,special:"castleL"});
    }
    // short: K f->i, R j->h
    const rookR=s[home][9];
    if(rookR&&rookR.c===color&&rookR.t==="R"&&!rookR.m&&[6,7,8].every(x=>!s[home][x])){
     if([6,7,8].every(x=>!attacksSquare(s,enemy(color),home,x)))out.push({r:home,c:8,special:"castleR"});
    }
   }
  }
 }
 return out;
}

function applyMove(s,m,ep,forSearch=false){
 const ns=cloneState(s);
 const p=ns[m.fr][m.fc];
 ns.halfmoveClock=p.t==="P"||s[m.tr][m.tc]||m.special==="ep"?0:(s.halfmoveClock||0)+1;
 ns.fullmoveNumber=(s.fullmoveNumber||1)+(p.c==="g"?1:0);
 let newEp=null;
 if(m.special==="ep"){
  const capR=ep?.capR??(p.c==="r"?m.tr+1:m.tr-1);
  ns[capR][m.tc]=null;
 }
 ns[m.tr][m.tc]=p; ns[m.fr][m.fc]=null; p.m=true;
 if(m.special==="castleL"){
  const rook=ns[m.tr][0]; ns[m.tr][3]=rook; ns[m.tr][0]=null; rook.m=true;
 }
 if(m.special==="castleR"){
  const rook=ns[m.tr][9]; ns[m.tr][7]=rook; ns[m.tr][9]=null; rook.m=true;
 }
 if(m.special==="double")newEp={r:(m.fr+m.tr)/2,c:m.fc,capR:m.tr};
 if(m.special==="triple"){
  ns.tripleRemaining[p.c]--;
  const d=p.c==="r"?-1:1;
  newEp={r:m.fr+d,c:m.fc,capR:m.tr,targets:[{r:m.fr+d,c:m.fc},{r:m.fr+2*d,c:m.fc}]};
 }
 if(p.t==="P"&&(m.tr===0||m.tr===ROWS-1)&&forSearch)p.t=m.promote||"Q";
 return {s:ns,ep:newEp};
}

function normalLegalMoves(s,color,ep=epSquare){
 const all=[];
 for(let r=0;r<ROWS;r++)for(let c=0;c<10;c++){
  const p=s[r][c]; if(!p||p.c!==color)continue;
  for(const pm of pseudoMoves(s,r,c,true,ep)){
   const m={fr:r,fc:c,tr:pm.r,tc:pm.c,special:pm.special||null};
   const res=applyMove(s,m,ep,true);
   if(!inCheck(res.s,color))all.push(m);
  }
 }
 return all;
}

function emergencyMoves(s,color,ep=epSquare){
 if(!["escape","both"].includes(variant()))return[];
 const normal=normalLegalMoves(s,color,ep);
 if(normal.length!==0||!inCheck(s,color))return[];
 const k=findKing(s,color); if(!k)return[];
 const [kr,kc]=k,out=[];
 for(const [dr,dc] of ORTH.concat(DIAG)){
  const rr=kr+dr,cc=kc+dc;
  if(!inside(rr,cc))continue;
  const own=s[rr][cc];
  if(!own||own.c!==color||own.t==="K")continue;
  if(attacksSquare(s,enemy(color),rr,cc))continue;
  const ns=cloneState(s);
  ns[rr][cc]=ns[kr][kc]; ns[kr][kc]=null;
  if(!inCheck(ns,color))out.push({fr:kr,fc:kc,tr:rr,tc:cc,special:"escape"});
 }
 return out;
}

function allLegalMoves(s,color,ep=epSquare){
 const n=normalLegalMoves(s,color,ep);
 if(n.length)return n;
 return emergencyMoves(s,color,ep);
}
