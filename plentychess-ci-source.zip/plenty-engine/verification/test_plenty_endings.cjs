const assert=require('node:assert/strict');
const open=require('./game_browser_harness.cjs');
(async()=>{
 const h=await open(process.argv[2]);
 async function position(fen,rule){
  await h.run(`(()=>{
   const fen=${JSON.stringify(fen)};modeEl.value='two';variantEl.value=${JSON.stringify(rule)};
   boardSizeEl.value=String(fen.split(' ')[0].split('/').length);engineSelect.value='plenty';reset();
   const f=fen.split(' ');
   state=f[0].split('/').map(row=>row.match(/[0-9]+|[a-z]/gi).flatMap(t=>/^[0-9]+$/.test(t)?Array(Number(t)).fill(null):[{t:t.toUpperCase(),c:t===t.toUpperCase()?'r':'g',m:true}]));
   const b=(f[6]||'t0,0').slice(1).split(',').map(Number);state.tripleRemaining={r:b[0],g:b[1]};
   state.halfmoveClock=Number(f[4]);state.fullmoveNumber=Number(f[5]);turn=f[1]==='w'?'r':'g';epSquare=null;
   humanSideEl.value=enemy(turn);strengthEl.value='3';modeEl.value='ai';render();
  })()`);
 }
 try{
  for(const height of [8,10])for(const rule of ['classic','kingKnight','escape','both']){
   for(const mate of [false,true]){
    const fen='10/'.repeat(height-3)+'2K7/'+(mate?'1Q8/':'2Q7/')+'k9 b - - 100 1'+(height===10?' t0,0':'');
    await position(fen,rule);await h.run('aiTurn()');
    assert.equal(await h.run('endKind'),mate?'mate':'stalemate');
    assert.equal(await h.run('history.length'),0);
   }
   const bare='9k/'+'10/'.repeat(height-2)+'K9 w - - 0 1'+(height===10?' t0,0':'');
   await position(bare,rule);await h.run('aiTurn()');
   const report=await h.run('gameReport()');
   assert.equal(report.result,'*');assert.equal(report.moves.length,1);
   assert.equal(report.moves[0].engine.name,'PlentyChess experimental');
  }
  await position('PPPPPPPPPk/PPPPPPPPPP/PPPPPPPPPP/PPPPPPPPPP/PPPPPPPPPP/PPPPPPnPPP/PPPPPRPRPP/PPPPPKPPPP w - - 99 1','escape');
  await h.run('aiTurn()');
  const escape=await h.run('gameReport()');
  assert.equal(escape.moves.length,1);assert.match(escape.moves[0].uci,/^f1/);
  assert.equal(escape.moves[0].engine.name,'PlentyChess experimental');
  assert.equal(Number(escape.currentFen.split(' ')[4]),0);
  await position('9k/P9/10/10/10/10/10/10/10/K9 w - - 0 1 t0,0','classic');
  await h.run('aiTurn()');
  const promoted=await h.run('gameReport()');
  assert.match(promoted.moves[0].uci,/^a9a10[qrbnac]$/);
  assert.equal(promoted.moves[0].engine.name,'PlentyChess experimental');
  assert.equal(await h.run('pendingPromotion'),null);
  assert.deepEqual(h.errors,[]);
  console.log('PASS REAL game endings: 16 mate/stalemate cases, 8 bare-king non-loss cases, emergency clock reset, promotion on rank 10');
 }finally{await h.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
