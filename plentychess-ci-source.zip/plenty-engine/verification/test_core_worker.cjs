// Transport-only test with a MOCK ABI. This does not validate WASM or Safari.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const responses = [];
let loads = 0;
const ctx = vm.createContext({
  importScripts(path) { assert.equal(path, 'core-dist/plenty-core.js'); loads++; },
  async PlentyCore() {
    await new Promise(resolve => setTimeout(resolve, 10));
    return {ccall(name) {return ({pc_variant:1, pc_position:1, pc_search:'a2a3',
      pc_completed:0, pc_terminal:0, pc_depth:0, pc_score:999, pc_nodes:1,
      pc_pv:'', pc_fen:'test-fen',pc_evaluator:'handcrafted-tapered-v1'})[name];}};
  },
  postMessage(value) { responses.push(value); }, onmessage:null,
});
vm.runInContext(fs.readFileSync(__dirname + '/plenty-core.worker.js', 'utf8'), ctx);
const request = {type:'search', height:10, flags:3, fen:'test-fen'};
ctx.onmessage({data:{...request,id:1}});
ctx.onmessage({data:{...request,id:2,nodes:2147483648}});
ctx.onmessage({data:{...request,id:3}});
(async () => {
  await vm.runInContext('queue', ctx);
  assert.equal(loads,1);
  assert.deepEqual(responses.map(r=>r.id),[1,2,3]);
  assert.equal(responses[0].score,null);
  assert.equal(responses[0].evaluator,'handcrafted-tapered-v1');
  assert.equal(responses[0].completed,false);
  assert.equal(responses[1].type,'error');
  assert.equal(responses[2].type,'result');
  console.log('PASS worker transport MOCK: queue, IDs, input bounds, null unconfirmed score, recovery');
})().catch(e=>{console.error(e);process.exitCode=1;});
