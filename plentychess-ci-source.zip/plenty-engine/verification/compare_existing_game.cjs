// Differential check against the unmodified v5.12.0 JavaScript move rules.
// Run from the workspace root:
// node plenty_work/PlentyChess-capablanca-stage10/verification/compare_existing_game.cjs
const fs = require('fs');
const vm = require('vm');
const cp = require('child_process');
const path = require('path');

const binary = path.join(__dirname, 'variant_cli');
const rules = fs.readFileSync(path.join(__dirname, 'game_rules_v5_12_0.js'), 'utf8');

function parseFen(rows, fen) {
  const parts = fen.split(' '), s = Array.from({length: rows}, () => Array(10).fill(null));
  parts[0].split('/').forEach((rank, r) => {
    let c = 0;
    for (let i = 0; i < rank.length; i++) {
      if (/\d/.test(rank[i])) {
        let number = rank[i];
        while (i + 1 < rank.length && /\d/.test(rank[i + 1])) number += rank[++i];
        c += Number(number);
      } else {
        const color = rank[i] === rank[i].toUpperCase() ? 'r' : 'g';
        const t = rank[i].toUpperCase();
        let moved = true;
        if (t === 'K') moved = !(color === 'r' ? /[KQ]/.test(parts[2]) : /[kq]/.test(parts[2]));
        if (t === 'R' && (c === 0 || c === 9) && (r === 0 || r === rows - 1)) {
          const key = color === 'r' ? (c === 0 ? 'Q' : 'K') : (c === 0 ? 'q' : 'k');
          moved = !parts[2].includes(key);
        }
        s[r][c++] = {c: color, t, m: moved};
      }
    }
    if (c !== 10) throw Error('Bad rank');
  });
  const budget = parts.find(p => /^t\d,\d$/.test(p));
  s.tripleRemaining = budget ? {r: Number(budget[1]), g: Number(budget[3])} : {r: 2, g: 2};
  const epNames = parts[3] === '-' ? [] : parts[3].match(/[a-j](?:10|[1-9])/g) || [];
  const targets = epNames.map(e => ({c: e.charCodeAt(0) - 97, r: rows - Number(e.slice(1))}));
  const capR = targets.length ? (parts[1] === 'w' ? Math.max(...targets.map(t=>t.r))+1 : Math.min(...targets.map(t=>t.r))-1) : -1;
  return {s, color: parts[1] === 'w' ? 'r' : 'g', ep: targets.length ? {...targets[0],targets,capR} : null};
}

const cases = [
  [8, 'normal', 'rnabqkbcnr/pppppppppp/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1'],
  [10, 'both', 'rnabqkbcnr/pppppppppp/10/10/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1 t2,2'],
  [8, 'normal', '9k/10/10/10/10/10/10/R4K3R w KQ - 0 1'],
  [8, 'normal', '9k/5p4/10/4P5/10/10/10/K9 b - - 0 1'],
  [8, 'normal', '9k/10/10/4Pp4/10/10/10/K9 w - f6 0 1'],
  [10, 'both', '9k/5p4/10/10/4P5/10/10/10/10/K9 b - - 0 1 t2,2'],
  [10, 'both', '9k/10/10/10/4Pp4/10/10/10/10/K9 w - f8f7 0 1 t2,1'],
  [8, 'kingKnight', '9k/10/10/10/4K5/10/10/10 w - - 0 1'],
  [8, 'normal', '5r3k/10/10/10/10/10/5R4/5K4 w - - 0 1']
];

let seed = 0x2a8f3cd1;
const rnd = n => { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; return (seed >>> 0) % n; };
for (let i = 0; i < 240; i++) {
  const rows = i % 2 ? 8 : 10;
  const variantName = ['normal', 'kingKnight', 'escape', 'both'][i % 4];
  const board = Array.from({length: rows}, () => Array(10).fill('.'));
  board[rows - 1][0] = 'K'; board[0][9] = 'k';
  const choices = 'PNBRQACpnbrqac';
  for (let j = 0; j < 12; j++) {
    const r = rnd(rows), c = rnd(10);
    if (board[r][c] !== '.') continue;
    const p = choices[rnd(choices.length)];
    if (p.toLowerCase() === 'p' && (r === 0 || r === rows - 1)) continue;
    board[r][c] = p;
  }
  const placement = board.map(rank => {
    let out = '', blank = 0;
    for (const p of rank) {
      if (p === '.') blank++;
      else { if (blank) out += blank; blank = 0; out += p; }
    }
    return out + (blank || '');
  }).join('/');
  cases.push([rows, variantName, `${placement} ${i % 3 ? 'w' : 'b'} - - 0 1${rows === 10 ? ' t2,2' : ''}`]);
}
const trapped = Array.from({length: 8}, () => Array(10).fill('P'));
trapped[7][5] = 'K'; trapped[5][6] = 'n'; trapped[6][5] = 'R'; trapped[6][7] = 'R';
trapped[0][9] = 'k';
cases.push([8, 'escape', trapped.map(row => row.join('')).join('/') + ' w - - 0 1']);

let total = 0;
for (const [rows, variantName, fen] of cases) {
  const {s, color, ep} = parseFen(rows, fen);
  const context = {ROWS: rows, variant: () => variantName, epSquare: ep};
  vm.createContext(context);
  vm.runInContext(rules, context);
  context.s = s; context.color = color; context.ep = ep;
  const jsMoves = vm.runInContext('allLegalMoves(s,color,ep)', context);
  // The UI currently emits a pseudo move onto the enemy king; a legal chess
  // move never captures a king. Keep that known UI issue out of this parity set.
  const js = new Set(jsMoves.filter(m => s[m.tr][m.tc]?.t !== 'K').map(m => String.fromCharCode(97+m.fc)+(rows-m.fr)+
    String.fromCharCode(97+m.tc)+(rows-m.tr)+':'+(m.special || '')));
  const cpp = new Set(cp.execFileSync(binary, [String(rows), variantName, fen], {encoding:'utf8'})
    .trim().split('\n').filter(Boolean));
  const missing = [...js].filter(m => !cpp.has(m));
  const extra = [...cpp].filter(m => !js.has(m));
  if (missing.length || extra.length) {
    console.error({rows, variantName, fen, missing, extra});
    process.exitCode = 1;
  }
  total++;
}
if (!process.exitCode) console.log(`Differential regular/special positions: ${total} matched`);
