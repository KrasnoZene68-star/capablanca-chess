#include "../src/variant_search.h"
#include <cassert>
#include <iostream>

int main() {
    using namespace CapablancaPort;
    using VariantPosition::Position;
    VariantSearch::Searcher search;
    const auto beforeMate = Position::fromFen(Board10x8,
        "10/3p1n4/1p8/9P/7kPK/7P2/10/8q1 b - - 0 72", true, true);
    auto winning = search.go(beforeMate, 2, 1500);
    assert(winning.completed);
    assert(winning.best.from == Board10x8.square(8, 0)); // i1
    assert(winning.score >= VariantSearch::MATE - 4);

    const auto mated = beforeMate.after(winning.best);
    assert(mated.inCheck(true) && mated.legalMoves().empty());
    const auto ended = search.go(mated, 2, 1500);
    assert(ended.completed && ended.score == -VariantSearch::MATE);

    // Terminal checkmate outranks the 50-move draw, as in the browser game.
    auto matedWithClock = mated;
    matedWithClock.halfmoveClock = 100;
    assert(search.go(matedWithClock, 2, 1500).score == -VariantSearch::MATE);

    const auto start = Position::fromFen(Board10x8,
        "rnabqkbcnr/pppppppppp/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1");
    const auto opening = search.go(start, 2, 1500);
    assert(opening.completed && opening.depth >= 1);
    bool legal = false;
    for (auto m : start.legalMoves())
        if (VariantSearch::sameMove(m, opening.best)) legal = true;
    assert(legal);
    auto fifty = start;
    fifty.halfmoveClock = 100;
    const auto drawn = search.go(fifty, 3, 1500);
    assert(drawn.completed && drawn.score == 0 && drawn.depth == 0);
    assert(fifty.halfmoveClock == 100);
    bool testedPawn = false;
    for (auto m : fifty.legalMoves()) {
        if (fifty.cells[m.from] == 'P') {
            assert(fifty.after(m).halfmoveClock == 0);
            testedPawn = true;
            break;
        }
    }
    assert(testedPawn);
    const uint64_t key = VariantHash::position(start);
    const auto repeated = search.go(start, 3, 1500, {key, key});
    assert(repeated.completed && repeated.score == 0 && repeated.depth == 0);
    // The same position seen once before is not yet an automatic draw.
    const auto twice = search.go(start, 1, 1500, {key});
    assert(twice.completed && twice.depth == 1);
    std::cout << "variant search: mate, termination, legal opening, "
              << opening.nodes << " nodes OK\n";
}
