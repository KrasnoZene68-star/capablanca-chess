// Real Chromium + dedicated Web Worker + compiled original-core WASM.
// PLAYWRIGHT_MODULE and CHROMIUM_PATH are supplied by the local environment.
const {chromium}=require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict');
const root=__dirname;
const server=http.createServer((req,res)=>{
  const name=new URL(req.url,'http://localhost').pathname;
  if(name==='/'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><script src="plenty-core.client.js"></script>');return;}
  const file=path.resolve(root,'.'+name);
  if(!file.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
  fs.readFile(file,(err,data)=>{
    if(err){res.writeHead(404);res.end();return;}
    res.setHeader('Content-Type',file.endsWith('.wasm')?'application/wasm':'application/javascript');res.end(data);
  });
});
(async()=>{
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  let browser;
  try{
    browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH,headless:true,args:['--no-sandbox']});
    const page=await browser.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
    const errors=[];page.on('pageerror',e=>errors.push(e.message));
    await page.goto('http://127.0.0.1:'+server.address().port);
    const report=await page.evaluate(async(expectedEvaluator)=>{
      const check=(ok,msg)=>{if(!ok)throw new Error(msg);};
      const client=new PlentyCoreClient();let runs=0;const timings=[];
      async function search(request){const r=await client.search(request);runs++;return r;}
      try{
        for(const height of [8,10])for(let flags=0;flags<4;flags++){
          const fen='rnabqkbcnr/pppppppppp/'+'10/'.repeat(height-4)+'PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1'+(height===10?' t2,2':'');
          const base={height,flags,fen,depth:2,milliseconds:10000};
          const opening=await search(base);
          check(opening.evaluator===expectedEvaluator,'Evaluator metadata mismatch');
          check(opening.completed&&opening.depth===2&&!opening.terminal&&opening.move!=='0000','Opening');
          const tiny=await search({...base,nodes:1});
          check(!tiny.completed&&tiny.score===null&&tiny.pv===''&&tiny.move!=='0000','Interrupted evaluation');
          const cycle=`b1c3 b${height}c${height-2} c3b1 c${height-2}b${height} `;
          for(const repeat of [1,2]){
            const r=await search({...base,moves:cycle.repeat(repeat)});
            check(r.terminal===(repeat===2),'Repetition');
            if(repeat===2)check(r.move==='0000'&&r.score===0,'Terminal draw');
          }
          for(const mate of [false,true]){
            const end='10/'.repeat(height-3)+'2K7/'+(mate?'1Q8/':'2Q7/')+'k9 b - - 100 1'+(height===10?' t0,0':'');
            const r=await search({...base,fen:end});
            check(r.terminal&&r.move==='0000'&&r.score===(mate?-30000:0),'Mate before fifty');
          }
          const begin=performance.now();
          const timed=await search({...base,depth:12,milliseconds:30});
          const elapsed=performance.now()-begin;timings.push(Math.round(elapsed));
          check(timed.move!=='0000'&&elapsed<3000,'Deadline');
          let failed=false;
          try{await search({...base,moves:'a1a10'});}catch(e){failed=true;}
          check(failed,'Illegal move rejected');
          check((await search(base)).completed,'Recovery');
        }
        const base={height:10,flags:3,fen:'rnabqkbcnr/pppppppppp/10/10/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1 t2,2',depth:20,milliseconds:10000};
        const cancelled=client.search(base).then(()=>false,()=>true);
        await new Promise(resolve=>setTimeout(resolve,30));client.cancel();
        check(await cancelled,'Cancellation');
        check((await search({...base,depth:1})).completed,'Recreate after cancellation');
        return {runs,timings,cancelled:true,crossOriginIsolated};
      }finally{client.cancel();}
    },process.env.EXPECTED_EVALUATOR || 'material-center-v1');
    assert.deepEqual(errors,[]);
    console.log('PASS REAL browser WASM',JSON.stringify(report));
  }finally{if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));}
})().catch(e=>{console.error(e);process.exitCode=1;});
