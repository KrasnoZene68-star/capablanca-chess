#include "../src/variant_search.h"
#include <algorithm>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using VariantPosition::Position;
using VMove = VariantPosition::Move;

std::string coordinate(CapablancaPort::Geometry g, uint8_t square) {
    return std::string(1, char('a' + g.file(square))) + std::to_string(g.rank(square) + 1);
}
std::string notation(CapablancaPort::Geometry g, VMove move) {
    std::string s = coordinate(g, move.from) + coordinate(g, move.to);
    if (move.promotion) s += char(std::tolower(static_cast<unsigned char>(move.promotion)));
    return s;
}

int main() {
    int rows = 8;
    bool kingKnight = false, escape = false;
    std::string line;
    VariantSearch::Searcher search;
    std::vector<uint64_t> prior;
    Position pos = Position::fromFen(CapablancaPort::Board10x8,
        "rnabqkbcnr/pppppppppp/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1");
    while (std::getline(std::cin, line)) {
        try {
            if (line == "uci") {
                std::cout << "id name Capablanca variant search (PlentyChess fork prototype)\n"
                          << "id author PlentyChess upstream / Capablanca adaptation\n"
                          << "option name UCI_Variant type combo default capablanca var capablanca"
                          << " var capablanca_kingknight var capablanca_escape var capablanca_both"
                          << " var capablanca10 var capablanca10_kingknight"
                          << " var capablanca10_escape var capablanca10_both\nuciok\n";
            } else if (line == "isready") std::cout << "readyok\n";
            else if (line == "quit") break;
            else if (line == "ucinewgame") { search = VariantSearch::Searcher{}; prior.clear(); }
            else if (line.rfind("setoption name UCI_Variant value ", 0) == 0) {
                const std::string v = line.substr(33);
                if (v.rfind("capablanca", 0) != 0) throw std::invalid_argument("variant unknown");
                rows = v.rfind("capablanca10", 0) == 0 ? 10 : 8;
                kingKnight = v.find("kingknight") != std::string::npos || v.find("both") != std::string::npos;
                escape = v.find("escape") != std::string::npos || v.find("both") != std::string::npos;
                prior.clear();
            } else if (line.rfind("position fen ", 0) == 0) {
                const std::string body = line.substr(13);
                const auto sep = body.find(" moves ");
                const auto fen = body.substr(0, sep);
                const auto g = CapablancaPort::Geometry{10, rows};
                pos = Position::fromFen(g, fen, kingKnight, escape);
                prior.clear();
                if (sep != std::string::npos) {
                    std::istringstream moves(body.substr(sep + 7));
                    std::string uci;
                    while (moves >> uci) {
                        auto legal = pos.legalMoves();
                        auto found = std::find_if(legal.begin(), legal.end(), [&](VMove m) {
                            return notation(g, m) == uci;
                        });
                        if (found == legal.end()) throw std::invalid_argument("illegal history move: " + uci);
                        prior.push_back(VariantHash::position(pos));
                        pos = pos.after(*found);
                    }
                }
            } else if (line.rfind("go", 0) == 0) {
                int depth = 5, ms = 1000;
                std::istringstream params(line);
                std::string token;
                while (params >> token) {
                    if (token == "depth") params >> depth;
                    if (token == "movetime") params >> ms;
                }
                depth = std::clamp(depth, 1, 32);
                ms = std::clamp(ms, 1, 60000);
                const auto result = search.go(pos, depth, ms, prior);
                if (result.completed) {
                    const int score = result.score;
                    if (std::abs(score) >= VariantSearch::MATE - 256) {
                        const int plies = VariantSearch::MATE - std::abs(score);
                        std::cout << "info depth " << result.depth << " score mate "
                                  << (score < 0 ? -(plies + 1) / 2 : (plies + 1) / 2)
                                  << " nodes " << result.nodes << '\n';
                    } else std::cout << "info depth " << result.depth << " score cp " << score
                                   << " nodes " << result.nodes << '\n';
                }
                std::cout << "bestmove " << (pos.legalMoves().empty() ? "0000" : notation(pos.geometry, result.best)) << '\n';
            }
        } catch (const std::exception& e) {
            std::cout << "info string " << e.what() << '\n';
        }
        std::cout.flush();
    }
}
