#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
eval_dir="$(mktemp -d "${TMPDIR:-/tmp}/plenty-eval30.XXXXXX")"
flags=(-std=c++17 -DCAPABLANCA_CORE -DCAPABLANCA_POSITIONAL_EVAL -O2 -Wall -Wextra -Werror)
if [[ "${SANITIZE:-0}" == 1 ]]; then flags+=(-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer); fi
"${CXX:-g++}" "${flags[@]}" verification/test_core_eval.cpp src/board.cpp src/evaluation.cpp -o "$eval_dir/test"
"$eval_dir/test"
