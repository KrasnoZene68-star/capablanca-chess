#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
core_build_dir="$(mktemp -d "${TMPDIR:-/tmp}/plenty-core25.XXXXXX")"
cxx="${CXX:-g++}"
flags=(-std=c++17 -DCAPABLANCA_CORE -Wall -Wextra -Werror -O2)
if [[ "${SANITIZE:-0}" == 1 ]]; then
    flags=(-std=c++17 -DCAPABLANCA_CORE -Wall -Wextra -Werror -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer)
fi
for test in test_core_history test_core_see test_core_picker; do
    "$cxx" "${flags[@]}" "verification/$test.cpp" src/board.cpp src/move.cpp src/history.cpp src/evaluation.cpp -o "$core_build_dir/$test"
    "$core_build_dir/$test"
done
echo "PASS. Temporary component executables: $core_build_dir"
