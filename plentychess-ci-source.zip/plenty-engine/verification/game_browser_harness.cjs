const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const fs=require('node:fs'),path=require('node:path'),http=require('node:http');
module.exports=async function open(root){
 root=path.resolve(root);const faults={wasm:false,delay:0},errors=[];
 const server=http.createServer((req,res)=>{
  res.setHeader('Cross-Origin-Opener-Policy','same-origin');res.setHeader('Cross-Origin-Embedder-Policy','require-corp');
  const name=new URL(req.url,'http://localhost').pathname;
  if(name==='/coi-serviceworker.js'){res.setHeader('Content-Type','application/javascript');res.end('// Test isolation headers');return;}
  const file=path.resolve(root,'.'+(name==='/'?'/index.html':name));
  if(!file.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
  const send=()=>{
   if(name.endsWith('/plenty-core.wasm')&&faults.wasm){res.writeHead(404);res.end('Deliberate test failure');return;}
   fs.readFile(file,(err,data)=>{
    if(err){res.writeHead(404);res.end();return;}
    res.setHeader('Content-Type',file.endsWith('.html')?'text/html':file.endsWith('.wasm')?'application/wasm':'application/javascript');
    if(file.endsWith('.html'))data=data.toString().replace('reset();\n})();','reset();\nwindow.__testRun=code=>eval(code);\n})();');
    res.end(data);
   });
  };
  if(name.endsWith('/plenty-core.wasm')&&faults.delay)setTimeout(send,faults.delay);else send();
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 let browser;
 try{
  browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH,headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});
  const page=await browser.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:'+server.address().port,{waitUntil:'networkidle'});
  return {page,faults,errors,run:code=>page.evaluate(code=>__testRun(code),code),
   wait:(code,timeout=30000)=>page.waitForFunction(code=>__testRun(code),code,{timeout}),
   close:async()=>{await browser.close();await new Promise(resolve=>server.close(resolve));}};
 }catch(e){if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));throw e;}
};
