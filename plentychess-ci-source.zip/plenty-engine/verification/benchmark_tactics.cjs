// Small diagnostic suite, not an Elo/playing-strength measurement.
const cp=require('node:child_process'),path=require('node:path');
const {cases}=require('./tactical_positions.cjs');
const binary=path.join(__dirname,'variant_uci');
let tested=0,passed=0;
for(const rows of [8,10]){
 const variant=rows===8?'capablanca':'capablanca10_both';
 for(const item of cases(rows)){
  const result=cp.spawnSync(binary,{input:`setoption name UCI_Variant value ${variant}\nposition fen ${item.fen}\ngo depth 6 movetime 250\nquit\n`,encoding:'utf8',timeout:3000});
  if(result.error||result.status!==0)throw result.error||new Error(result.stderr);
  const best=result.stdout.match(/bestmove (\S+)/)?.[1];
  const good=item.good?item.good.includes(best):item.bad?!item.bad.includes(best):!item.illegal.includes(best);
  if(good)passed++;
  tested++;
  console.log(`${good?'OK  ':'MISS'} ${rows} ${item.name}: ${best||'none'} ${item.good?'(wanted '+item.good.join('/')+')':''}`);
 }
}
console.log(`Tactical diagnostic: ${passed}/${tested} expected-move checks at 250ms (not a rating)`);
