#include "../src/thread.h"
#include <iostream>
#include <memory>
int main(int argc,char** argv) {
    if(argc!=6) { std::cerr<<"height flags(0..3) depth movetime_ms FEN\n"; return 2; }
    try {
        Board b{}; int flags=std::stoi(argv[2]);
        b.setVariant(std::stoi(argv[1]),flags&1,flags&2); b.parseFen(argv[5],false);
        SearchParameters limits; limits.depth=std::stoi(argv[3]); limits.movetime=std::stoull(argv[4]); limits.infinite=false;
        auto worker=std::make_unique<Worker>();
        auto result=worker->run(b,limits);
        std::cout<<"depth "<<result.depth<<" score "<<formatEval(result.score)<<" nodes "<<result.nodes
                 <<" completed "<<result.completed<<" terminal "<<result.terminal<<" bestmove "<<result.move.toString(false)<<" pv";
        for(Move m:result.pv) std::cout<<' '<<m.toString(false);
        std::cout<<'\n';
    }catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
