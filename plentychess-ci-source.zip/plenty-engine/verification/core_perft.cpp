#include "../src/board.h"
#include <iostream>
#include <stdexcept>

uint64_t count(Board b, int depth, bool queenOnly) {
    if (!depth) return 1;
    uint64_t nodes = 0;
    for (Move m : b.legalMoves()) {
        if (queenOnly && m.isPromotion() && m.promotionPiece() != QUEEN) continue;
        Board child = b;
        child.doMove(m, 0, nullptr);
        nodes += count(child, depth - 1, queenOnly);
    }
    return nodes;
}
int main(int argc, char** argv) {
    if (argc != 5 && argc != 6) return 2;
    try {
        Board b{};
        std::string flags = argv[2];
        b.setVariant(std::stoi(argv[1]), flags == "kingKnight" || flags == "both", flags == "escape" || flags == "both");
        b.parseFen(argv[4], false);
        const int depth = std::stoi(argv[3]);
        if (depth < 0 || depth > 6) throw std::invalid_argument("perft depth must be 0..6");
        std::cout << count(b, depth, argc == 5) << '\n';
    } catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
