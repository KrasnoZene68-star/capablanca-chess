// Prototype-only browser worker. Requires plenty-variant.js/wasm built from
// variant_web.cpp. Do not expose as the original PlentyChess 8.0.0 engine.
importScripts('./plenty-variant.js');
const ready=CapablancaVariant();
self.onmessage=async event=>{
 const {id,type,variant,position,fen,depth,time}=event.data||{};
 try{
  const engine=await ready;
  const call=(name,kind,args=[],values=[])=>engine.ccall('cp_'+name,kind,args,values);
  if(type==='init'){
   self.postMessage({id,engine:'plenty-variant-prototype-0.1'});return;
  }
  if(type!=='search')throw new Error('unsupported worker request');
  if(!call('set_variant','number',['string'],[variant]))throw new Error(call('error','string'));
  if(!call('set_position','number',['string'],[position||`position fen ${fen}`]))
   throw new Error(call('error','string'));
  const started=performance.now();
  const move=call('search','string',['number','number'],[depth||5,time||1000]);
  const error=call('error','string');
  if(error)throw new Error(error);
  const value=call('score','number'),completed=Boolean(call('completed','number'));
  let score={unit:'cp',value,perspective:'side-to-move'};
  if(Math.abs(value)>=29744){
   const plies=30000-Math.abs(value);
   score={unit:'mate',value:Math.sign(value)*Math.ceil(plies/2),perspective:'side-to-move'};
  }
  self.postMessage({id,move,analysis:{engine:'PlentyChess fork prototype',evaluation:'classical',
   depth:call('depth','number'),nodes:call('nodes','number'),timeMs:Math.round(performance.now()-started),
   score,completed}});
 }catch(error){self.postMessage({id,error:String(error?.message||error)});}
};
