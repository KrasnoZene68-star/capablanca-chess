"""One native library per process; prevents C++ symbol interposition in A/B tests."""
import ctypes
import json
import sys
import time
m=ctypes.CDLL(sys.argv[1])
for name in ['error','fen','pv','evaluator']:
    getattr(m,'pc_'+name).restype=ctypes.c_char_p
m.pc_variant.argtypes=[ctypes.c_int,ctypes.c_int]
m.pc_position.argtypes=[ctypes.c_char_p,ctypes.c_char_p]
m.pc_search.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_int]
m.pc_search.restype=ctypes.c_char_p
m.pc_nodes.restype=ctypes.c_double
for line in sys.stdin:
    try:
        q=json.loads(line)
        assert m.pc_variant(q['height'],q['flags']),m.pc_error()
        assert m.pc_position(q['fen'].encode(),q.get('moves','').encode()),m.pc_error()
        begin=time.monotonic()
        move=m.pc_search(q.get('depth',0),q.get('ms',30),0)
        assert move,m.pc_error()
        result={'move':move.decode(),'score':m.pc_score(),'depth':m.pc_depth(),'completed':bool(m.pc_completed()),
                'terminal':bool(m.pc_terminal()),'nodes':int(m.pc_nodes()),'elapsed':time.monotonic()-begin,'fen':m.pc_fen().decode(),'evaluator':m.pc_evaluator().decode()}
    except Exception as e:
        result={'error':str(e)}
    print(json.dumps(result),flush=True)
