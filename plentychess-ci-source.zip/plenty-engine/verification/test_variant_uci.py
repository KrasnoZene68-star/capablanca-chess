"""Protocol smoke test and game-history replay for the experimental adapter."""
import subprocess
from pathlib import Path

binary = Path(__file__).with_name('variant_uci')
initial10 = 'rnabqkbcnr/pppppppppp/10/10/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1 t2,2'
mate8 = '10/3p1n4/1p8/9P/7kPK/7P2/10/8q1 b - - 0 72'
commands = '\n'.join([
    'uci', 'isready',
    'setoption name UCI_Variant value capablanca10_both',
    f'position fen {initial10} moves a2a5 a9a6',
    'go depth 1 movetime 1000',
    'setoption name UCI_Variant value capablanca_both',
    f'position fen {mate8}',
    'go depth 2 movetime 1500', 'quit', '',
])
r = subprocess.run([str(binary)], input=commands, text=True, capture_output=True, timeout=12)
assert r.returncode == 0, r.stderr
lines = r.stdout.splitlines()
assert 'uciok' in lines and 'readyok' in lines, lines
assert all(not line.startswith('info string') for line in lines), lines
best = [line.split()[1] for line in lines if line.startswith('bestmove ')]
assert len(best) == 2 and best[0] != '0000' and best[1].startswith('i1'), best
assert any('score mate 1' in line for line in lines), lines
print('UCI handshake, 10x10 history replay, 10x8 mate: OK')
