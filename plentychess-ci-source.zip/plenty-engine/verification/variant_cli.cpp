#include "../src/variant_position.h"
#include <algorithm>
#include <iostream>
#include <set>

int main(int argc, char** argv) {
    if (argc != 4) return 2;
    const int rows = std::stoi(argv[1]);
    CapablancaPort::Geometry g{10, rows};
    const std::string variant = argv[2];
    const auto position = VariantPosition::Position::fromFen(
        g, argv[3], variant == "kingKnight" || variant == "both",
        variant == "escape" || variant == "both");
    std::set<std::string> moves;
    for (const auto m : position.legalMoves()) {
        const std::string from = std::string(1, char('a' + g.file(m.from))) + std::to_string(g.rank(m.from) + 1);
        const std::string to = std::string(1, char('a' + g.file(m.to))) + std::to_string(g.rank(m.to) + 1);
        std::string special;
        switch (m.special) {
        case VariantPosition::Move::Special::Double: special = "double"; break;
        case VariantPosition::Move::Special::Triple: special = "triple"; break;
        case VariantPosition::Move::Special::EnPassant: special = "ep"; break;
        case VariantPosition::Move::Special::CastleLeft: special = "castleL"; break;
        case VariantPosition::Move::Special::CastleRight: special = "castleR"; break;
        case VariantPosition::Move::Special::Escape: special = "escape"; break;
        default: special = "";
        }
        // The current game's legal move generator records one destination for
        // each promotion, then prompts for the chosen piece. Ignore choice here.
        moves.insert(from + to + ":" + special);
    }
    for (const auto& move : moves) std::cout << move << '\n';
}
