#include "../src/variant_position.h"
#include <cassert>
#include <iostream>

using namespace CapablancaPort;
using VariantPosition::Position;

int main() {
    const auto start8 = Position::fromFen(Board10x8,
        "rnabqkbcnr/pppppppppp/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1");
    assert(!start8.inCheck(true) && !start8.inCheck(false));
    const auto opening = start8.regularLegalMoves();
    assert(opening.size() == 28); // 20 pawn advances + 4 knight + 4 A/C leaps.
    const auto start10 = Position::fromFen(Board10x10,
        "rnabqkbcnr/pppppppppp/10/10/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1");
    assert(start10.regularLegalMoves().size() == 38); // each pawn can propose the first triple start

    const auto check = Position::fromFen(Board10x8,
        "5r3k/10/10/10/10/10/5R4/5K4 w - - 0 1");
    assert(!check.inCheck(true));
    for (const auto m : check.regularLegalMoves())
        assert(!check.after(m).inCheck(true));
    // A pinned rook may move along its file but may not expose the king.
    const int f2 = Board10x8.square(5, 1);
    for (const auto m : check.regularLegalMoves())
        assert(m.from != f2 || Board10x8.file(m.to) == 5);

    const auto kingKnight = Position::fromFen(Board10x8,
        "9k/10/10/10/4K5/10/10/10 w - - 0 1", true);
    assert(kingKnight.regularLegalMoves().size() == 16);
    std::cout << "variant regular legal moves: OK\n";
}
