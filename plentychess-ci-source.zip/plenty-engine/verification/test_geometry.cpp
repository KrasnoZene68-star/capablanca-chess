#include "../src/capablanca_geometry.h"
#include <cassert>
#include <iostream>

using namespace CapablancaPort;

int main() {
    for (const Geometry g : {Board10x8, Board10x10}) {
        for (int s = 0; s < g.count(); ++s) {
            assert(g.square(g.file(s), g.rank(s)) == s);
            Squares occupied;
            occupied.add(s);
            assert(occupied.contains(s));
            assert((occupied & Squares{}).low == 0);
            for (int t = 0; t < g.count(); ++t) {
                for (int k = 0; k <= int(MoveKind::Emergency); ++k) {
                    auto move = Move::make(s, t, MoveKind(k), Promotion::Chancellor);
                    assert(move.from() == s && move.to() == t);
                    assert(move.kind() == MoveKind(k));
                    assert(move.promotion() == Promotion::Chancellor);
                }
            }
        }
    }
    Squares edge;
    edge.add(63); edge.add(64); edge.add(79); edge.add(99);
    assert(edge.contains(63) && edge.contains(64));
    assert(edge.contains(79) && edge.contains(99));
    assert(!edge.contains(62) && !edge.contains(98));
    std::cout << "geometry and move encoding: OK\n";
}
