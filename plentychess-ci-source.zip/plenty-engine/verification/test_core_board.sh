#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
core_build_dir="$(mktemp -d "${TMPDIR:-/tmp}/plenty-core24.XXXXXX")"
cxx="${CXX:-g++}"
flags=(-std=c++17 -Wall -Wextra -Werror -O2)
if [[ "${SANITIZE:-0}" == 1 ]]; then
    flags=(-std=c++17 -Wall -Wextra -Werror -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer)
fi
"$cxx" "${flags[@]}" -DCAPABLANCA_CORE verification/test_core_board.cpp src/board.cpp -o "$core_build_dir/test_core_board"
"$core_build_dir/test_core_board"
"$cxx" -std=c++17 -O2 -DCAPABLANCA_CORE verification/core_perft.cpp src/board.cpp -o "$core_build_dir/core_perft"
VARIANT_PERFT_BINARY="$core_build_dir/core_perft" node verification/compare_perft.cjs
VARIANT_PERFT_BINARY="$core_build_dir/core_perft" node verification/compare_reachable_games.cjs
for test in test_geometry test_variant_attacks test_variant_position test_variant_specials test_variant_hash test_variant_search test_move_encoding test_wide_bitboard; do
    "$cxx" -std=c++17 -O2 "verification/$test.cpp" -o "$core_build_dir/$test"
    "$core_build_dir/$test"
done
echo "PASS. Temporary test executables: $core_build_dir"
