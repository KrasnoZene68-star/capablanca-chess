"""Small deterministic native A/B check, not an Elo or statistical strength test."""
import json
import pathlib
import subprocess
import sys

worker=pathlib.Path(__file__).with_name('eval_worker.py')
processes=[subprocess.Popen([sys.executable,str(worker),lib],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True) for lib in sys.argv[1:3]]
games=[]
def search(which,q):
    p=processes[which];p.stdin.write(json.dumps(q)+'\n');p.stdin.flush()
    r=json.loads(p.stdout.readline())
    assert 'error' not in r,r
    return r
try:
    for height in [8,10]:
        fen='rnabqkbcnr/pppppppppp/'+'10/'*(height-4)+'PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1'+(' t2,2' if height==10 else '')
        for flags in range(4):
            for candidate_side in [0,1]:
                moves=[];records=[];result='*'
                for ply in range(120):
                    engine=int(ply%2==candidate_side)
                    reply=search(engine,{'height':height,'flags':flags,'fen':fen,'moves':' '.join(moves),'ms':30})
                    records.append(dict(engine=engine,**reply))
                    if reply['terminal']:
                        result='1/2-1/2' if reply['score']==0 else ('0-1' if ply%2==0 else '1-0')
                        break
                    assert reply['move']!='0000'
                    moves.append(reply['move'])
                # The last move must also be checked by both parsers, even at cap.
                for engine in [0,1]:
                    search(engine,{'height':height,'flags':flags,'fen':fen,'moves':' '.join(moves),'ms':1})
                game={'height':height,'flags':flags,'candidateSide':candidate_side,'moves':moves,'records':records,'result':result}
                games.append(game)
                print(json.dumps({k:v for k,v in game.items() if k not in ['moves','records']},ensure_ascii=False),len(moves),flush=True)
finally:
    for p in processes:
        p.stdin.close();p.wait(timeout=10)
    if len(sys.argv)>3:pathlib.Path(sys.argv[3]).write_text(json.dumps(games,indent=2))
summary={'games':len(games),'plies':sum(len(g['moves']) for g in games),'candidateWins':0,'baselineWins':0,'draws':0,'capped':0}
for g in games:
    if g['result']=='*':summary['capped']+=1
    elif g['result']=='1/2-1/2':summary['draws']+=1
    elif (g['result']=='1-0')==(g['candidateSide']==0):summary['candidateWins']+=1
    else:summary['baselineWins']+=1
print(json.dumps(summary),flush=True)
