#include "../src/variant_hash.h"
#include <cassert>
#include <iostream>

using namespace CapablancaPort;
using namespace VariantPosition;

int main() {
    const auto plain = Position::fromFen(Board10x8,
        "9k/10/10/4Pp4/10/10/10/K9 w - - 0 1");
    const auto withEp = Position::fromFen(Board10x8,
        "9k/10/10/4Pp4/10/10/10/K9 w - f6 0 1");
    const auto withInvalidEp = Position::fromFen(Board10x8,
        "9k/10/10/4Pp4/10/10/10/K9 w - a6 0 1");
    assert(VariantHash::position(plain) != VariantHash::position(withEp));
    assert(VariantHash::position(plain) == VariantHash::position(withInvalidEp));

    auto changed = plain;
    changed.redToMove = false;
    assert(VariantHash::position(plain) != VariantHash::position(changed));
    changed = plain; changed.cells[Board10x8.square(4, 4)] = '.';
    assert(VariantHash::position(plain) != VariantHash::position(changed));
    changed = plain; changed.castle[0] = true;
    assert(VariantHash::position(plain) != VariantHash::position(changed));
    changed = plain; changed.kingKnight = true;
    assert(VariantHash::position(plain) != VariantHash::position(changed));
    changed = plain; changed.emergencyEscape = true;
    assert(VariantHash::position(plain) != VariantHash::position(changed));

    const auto ten = Position::fromFen(Board10x10,
        "9k/5p4/10/10/4P5/10/10/10/10/K9 b - - 0 1 t2,2");
    changed = ten; changed.tripleRemaining[1] = 1;
    assert(VariantHash::position(ten) != VariantHash::position(changed));
    std::cout << "variant state hash: OK\n";
}
