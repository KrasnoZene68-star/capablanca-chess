#include "../src/types.h"
#include <cassert>
#include <iostream>

int main() {
    for (int from = 0; from < 100; ++from) {
        for (int to = 0; to < 100; ++to) {
            if (from == 0 && to == 0) continue; // reserved null move
            const auto normal = Move::makeNormal(from, to);
            assert(normal.origin() == from && normal.target() == to);
            assert(normal.type() == MoveType::NORMAL);
            for (Piece p : {Piece::KNIGHT, Piece::BISHOP, Piece::ROOK, Piece::QUEEN}) {
                const auto promo = Move::makePromotion(from, to, p);
                assert(promo.origin() == from && promo.target() == to);
                assert(promo.isPromotion() && promo.promotionPiece() == p);
            }
            const auto ep = Move::makeEnpassant(from, to);
            const auto castle = Move::makeCastling(from, to);
            assert(ep.origin() == from && ep.target() == to && ep.isEnpassant());
            assert(castle.origin() == from && castle.target() == to && castle.isCastling());
        }
    }
    assert(!Move::none());
    std::cout << "all 100-square extended move encodings: OK\n";
}
