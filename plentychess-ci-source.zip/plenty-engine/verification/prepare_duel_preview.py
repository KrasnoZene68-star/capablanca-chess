"""Exact, non-destructive 5.12.2 -> 5.12.3 experimental game upgrade."""
import pathlib
import shutil
import sys
base,out=map(pathlib.Path,sys.argv[1:])
text=(base/'index.html').read_text()
assert 'appVersion:"5.12.2-plenty-preview"' in text and text.rstrip().endswith('</html>')
assert not out.exists(), 'Refusing to overwrite an existing directory'
def replace(old,new,count=1):
    global text
    assert text.count(old)==count, f'Unexpected match count: {old[:100]}'
    text=text.replace(old,new)

for prefix in ['', 'mobile']:
    red=prefix+'DuelRedEngine' if prefix else 'duelRedEngine'
    green=prefix+'DuelGreenEngine' if prefix else 'duelGreenEngine'
    old=f'<select id="{red}"><option value="stockfish" selected>Fairy-Stockfish</option><option value="reckless">Reckless · адаптований</option></select>'
    replace(old,old.replace('</select>','<option value="plenty">PlentyChess · експериментальний</option></select>'))
    oldhint='<p class="strengthHint">Зеленими автоматично грає інший рушій. Зміна кольорів починає нову партію.</p></div>'
    new=f'''<p class="strengthHint">Рушії обираються незалежно. Зміна починає нову партію.</p></div>
<div class="settingsField duelOnly"><label for="{green}">Зелені грають за</label>
<select id="{green}"><option value="stockfish">Fairy-Stockfish</option><option value="reckless" selected>Reckless · адаптований</option><option value="plenty">PlentyChess · експериментальний</option></select>
<p class="strengthHint">PlentyChess ще без NNUE. Його рівні — бюджети пошуку, не рейтинг сили.</p></div>'''
    assert oldhint in text
    text=text.replace(oldhint,new,1)
replace("const mobileDuelRedEngine=document.getElementById('mobileDuelRedEngine');", "const mobileDuelRedEngine=document.getElementById('mobileDuelRedEngine');\nconst duelGreenEngineEl=document.getElementById('duelGreenEngine');\nconst mobileDuelGreenEngine=document.getElementById('mobileDuelGreenEngine');")
replace("function engineLabel(engine){return engine==='stockfish'?'Fairy-Stockfish':'Reckless'}", """function engineLabel(engine){return {stockfish:'Fairy-Stockfish',reckless:'Reckless',plenty:'PlentyChess experimental'}[engine]||'Невідомий рушій'}
function validEngine(value){return ['stockfish','reckless','plenty'].includes(value)?value:'stockfish'}
function engineBuildLabel(value){return {stockfish:'Fairy-Stockfish 5.10.0',reckless:'Reckless Capablanca 1.0',plenty:'PlentyChess original core stage29 experimental'}[value]}
function engineStatusFor(value){return value==='plenty'?{ready:plentyLastSearchOk===true,lastSearchOk:plentyLastSearchOk,reason:plentyFailureReason}:value==='reckless'?{ready:recklessReady,lastSearchOk:recklessLastSearchOk,reason:recklessFailureReason}:{ready:fairyReady,lastSearchOk:fairyLastSearchOk,reason:fairyFailureReason}}
function initEngine(value){return value==='plenty'?Promise.resolve(true):value==='reckless'?initReckless():initFairy()}
function initDuelEngines(){for(const engine of new Set(Object.values(duelEngines)))void initEngine(engine)}""")
replace("duelEngines={r:duelRedEngineEl.value==='reckless'?'reckless':'stockfish',g:duelRedEngineEl.value==='reckless'?'stockfish':'reckless'};", "duelEngines={r:validEngine(duelRedEngineEl.value),g:validEngine(duelGreenEngineEl.value)};")
replace("if(modeEl.value==='engines'){void initFairy();void initReckless()}", "if(modeEl.value==='engines')initDuelEngines();")
replace("duelRunning=false;duelEpoch++;duelPauseReason=reason;aiTurnRequest=null;", "duelRunning=false;duelEpoch++;duelPauseReason=reason;aiTurnRequest=null;\n discardPlenty();")
replace("duelRunning=true;duelStarted=true;duelPauseReason='';", "if(gameOver)return; // startClock/clockTick may have ended the game immediately.\n duelRunning=true;duelStarted=true;duelPauseReason='';")
replace("function syncDuelEngine(value){\n duelRedEngineEl.value=mobileDuelRedEngine.value=value;", "function syncDuelEngine(side,value){\n for(const el of side==='r'?[duelRedEngineEl,mobileDuelRedEngine]:[duelGreenEngineEl,mobileDuelGreenEngine])el.value=validEngine(value);")
replace("syncDuelEngine(duelRedEngineEl.value)", "syncDuelEngine('r',duelRedEngineEl.value)")
replace("syncDuelEngine(mobileDuelRedEngine.value)", "syncDuelEngine('r',mobileDuelRedEngine.value)")
replace("duelRedLevel.addEventListener('change'", "duelGreenEngineEl.addEventListener('change',()=>syncDuelEngine('g',duelGreenEngineEl.value));\nmobileDuelGreenEngine.addEventListener('change',()=>syncDuelEngine('g',mobileDuelGreenEngine.value));\nduelRedLevel.addEventListener('change'")
replace("const trouble=!duelRunning&&(duelPauseReason||fairyLastSearchOk===false&&fairyFailureReason||recklessLastSearchOk===false&&recklessFailureReason);\n  const ready=fairyReady&&recklessReady;", "const statuses=Object.values(duelEngines).map(engineStatusFor);\n  const trouble=!duelRunning&&(duelPauseReason||statuses.find(s=>s.lastSearchOk===false)?.reason);\n  const ready=statuses.every(s=>s.ready);")
replace("ready?'ГОТОВІ':'ЗАВАНТАЖЕННЯ'", "ready?'ГОТОВІ':'ОЧІКУВАННЯ ЗАПУСКУ'")
replace("engineBuild:modeEl.value==='engines'?'Fairy-Stockfish 5.10.0 + Reckless Capablanca 1.0':activeEngine==='plenty'?'PlentyChess original core stage28 experimental':activeEngine==='reckless'?'Reckless Capablanca 1.0':'5.10.0'", "engineBuild:modeEl.value==='engines'?Object.values(duelEngines).map(engineBuildLabel).join(' + '):engineBuildLabel(activeEngine)")
replace("engineStatus:modeEl.value==='engines'?{stockfish:{ready:fairyReady,lastSearchOk:fairyLastSearchOk,reason:fairyFailureReason},reckless:{ready:recklessReady,lastSearchOk:recklessLastSearchOk,reason:recklessFailureReason}}", "engineStatus:modeEl.value==='engines'?Object.fromEntries([...new Set(Object.values(duelEngines))].map(e=>[e,engineStatusFor(e)]))")
replace('if(request.plentyTerminal){checkGameEnd();return;}', "if(request.plentyTerminal){if(!checkGameEnd()&&modeEl.value==='engines')pauseDuel(plentyFailureReason);return;}")
replace('appVersion:"5.12.2-plenty-preview"','appVersion:"5.12.3-plenty-duel-preview"')
replace('plentychess-source-stage28.zip','plentychess-source-stage29.zip')
replace('plenty-core.worker.js?v=28','plenty-core.worker.js?v=29')
shutil.copytree(base,out)
(out/'index.html').write_text(text)
print(out)
