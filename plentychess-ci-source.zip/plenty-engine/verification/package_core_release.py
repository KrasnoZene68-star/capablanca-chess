"""Package only newly built and successfully tested core outputs (CI step)."""
from pathlib import Path
import hashlib, json, os, shutil
root=Path(__file__).resolve().parents[1]
repo=root.parent
out=repo/'release'
out.mkdir(exist_ok=False)
shutil.copytree(root/'verification/core-dist',out/'core-dist')
for name in ('plenty-core.worker.js','plenty-core.client.js'):
    shutil.copy2(root/'verification'/name,out/name)
for name in ('LICENSE','README_CAPABLANCA_STAGE31_UA.md'):
    shutil.copy2(root/name,out/name)
shutil.copy2(repo/'plentychess-ci-source.zip',out/'plentychess-ci-source.zip')
metadata={'variant':os.environ['BUILD_VARIANT'],'evaluator':os.environ['EXPECTED_EVALUATOR'],
          'repository_commit':os.environ.get('GITHUB_SHA'),'run_id':os.environ.get('GITHUB_RUN_ID'),
          'emscripten':'2.0.26','checks':['native evaluation','native original search','Node actual WASM','Chromium actual worker'],
          'not_verified':['iPhone Safari','full website integration','playing strength','dead-position material rules']}
(out/'build.json').write_text(json.dumps(metadata,indent=2)+'\n')
checks=[]
for f in sorted(out.rglob('*')):
    if f.is_file(): checks.append(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(out).as_posix())
(out/'SHA256SUMS').write_text('\n'.join(checks)+'\n')
print('Packaged',metadata['variant'],len(checks),'files')
