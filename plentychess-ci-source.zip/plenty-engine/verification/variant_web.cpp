#include "../src/variant_search.h"
#include <algorithm>
#include <cctype>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
#define CP_EXPORT EMSCRIPTEN_KEEPALIVE
#else
#define CP_EXPORT
#endif

namespace {
using VariantPosition::Position;
using VMove=VariantPosition::Move;
std::unique_ptr<Position> position;
VariantSearch::Searcher searcher;
std::vector<uint64_t> history;
std::string error, bestmove="0000";
std::string variantName;
VariantSearch::Result last;
int rows=8;
bool kingKnight=false, escape=false;

std::string notation(CapablancaPort::Geometry g, VMove move) {
    auto square=[&](int s) {
        return std::string(1,char('a'+g.file(s)))+std::to_string(g.rank(s)+1);
    };
    std::string n=square(move.from)+square(move.to);
    if(move.promotion)n+=char(std::tolower(static_cast<unsigned char>(move.promotion)));
    return n;
}
}

extern "C" {
CP_EXPORT const char* cp_error() { return error.c_str(); }

CP_EXPORT int cp_set_variant(const char* name) {
    try {
        if(!name)throw std::invalid_argument("variant is null");
        const std::string v(name);
        const bool ten=v.rfind("capablanca10",0)==0;
        const bool eight=v.rfind("capablanca",0)==0&&!ten;
        const std::string suffix=v.substr(ten?12:10);
        if((!ten&&!eight)||
           (suffix!=""&&suffix!="_kingknight"&&suffix!="_escape"&&suffix!="_both"))
            throw std::invalid_argument("unsupported variant");
        if(v==variantName){error.clear();return 1;}
        variantName=v;
        rows=ten?10:8;
        kingKnight=suffix=="_kingknight"||suffix=="_both";
        escape=suffix=="_escape"||suffix=="_both";
        searcher=VariantSearch::Searcher{};
        position.reset();history.clear();error.clear();return 1;
    }catch(const std::exception& e){error=e.what();return 0;}
}

CP_EXPORT int cp_set_position(const char* command) {
    try {
        if(!command)throw std::invalid_argument("position is null");
        std::string body(command);
        if(body.rfind("position fen ",0)==0)body=body.substr(13);
        const auto split=body.find(" moves ");
        const auto g=CapablancaPort::Geometry{10,rows};
        Position next=Position::fromFen(g,body.substr(0,split),kingKnight,escape);
        std::vector<uint64_t> prior;
        if(split!=std::string::npos){
            std::istringstream moves(body.substr(split+7));
            std::string uci;
            while(moves>>uci){
                auto legal=next.legalMoves();
                auto it=std::find_if(legal.begin(),legal.end(),[&](VMove m){return notation(g,m)==uci;});
                if(it==legal.end())throw std::invalid_argument("illegal history move: "+uci);
                prior.push_back(VariantHash::position(next));
                next=next.after(*it);
            }
        }
        position=std::make_unique<Position>(std::move(next));
        history=std::move(prior);
        error.clear();return 1;
    }catch(const std::exception& e){error=e.what();return 0;}
}

CP_EXPORT const char* cp_search(int depth,int milliseconds) {
    bestmove="0000";
    try {
        if(!position)throw std::invalid_argument("set position before search");
        last=searcher.go(*position,std::clamp(depth,1,32),std::clamp(milliseconds,1,60000),history);
        if(!position->legalMoves().empty())bestmove=notation(position->geometry,last.best);
        error.clear();return bestmove.c_str();
    }catch(const std::exception& e){error=e.what();return bestmove.c_str();}
}

CP_EXPORT int cp_depth(){return last.depth;}
CP_EXPORT int cp_score(){return last.score;}
CP_EXPORT int cp_completed(){return last.completed?1:0;}
CP_EXPORT double cp_nodes(){return double(last.nodes);}
}
