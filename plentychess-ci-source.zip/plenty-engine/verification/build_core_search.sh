#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
output="${1:-/tmp/plenty-core26-cli}"
eval_flags=()
if [[ "${POSITIONAL_EVAL:-0}" == 1 ]]; then eval_flags+=(-DCAPABLANCA_POSITIONAL_EVAL); fi
"${CXX:-g++}" -std=c++17 -DCAPABLANCA_CORE "${eval_flags[@]}" -O2 -pthread \
 verification/core_search_cli.cpp src/board.cpp src/move.cpp src/history.cpp \
 src/evaluation.cpp src/search.cpp src/tt.cpp src/time.cpp src/core_worker.cpp -o "$output"
echo "$output"
