#include "../src/board.h"
#include "../src/history.h"
#include "../src/evaluation.h"
#include <algorithm>
#include <cassert>
#include <iostream>
#include <memory>
#include <random>
#include <set>

static size_t positions = 0, enumerations = 0, returned = 0;
static_assert(sizeof(MoveGen) < 512, "movepickers must not embed 4096-move arrays per ply");

struct Harness {
    SharedHistory shared{1};
    std::unique_ptr<History> history{std::make_unique<History>(0, &shared)};
    SearchStack stack[8]{};
    SearchStack* ss = stack + 6;
    Harness() {
        history->initHistory();
        for (auto& entry : stack) { entry.movedPiece = NONE; entry.killer = Move::none(); entry.move = Move::none(); }
        ss->ply = 1;
        (ss - 1)->move = Move::makeNormal(98, 99);
    }
};
std::set<Move> drain(MoveGen& picker) {
    std::set<Move> result;
    for (;;) {
        Move m = picker.nextMove();
        if (!m) break;
        bool inserted = result.insert(m).second;
        assert(inserted && "picker returned a duplicate");
        assert(result.size() <= MAX_MOVES);
        ++returned;
    }
    assert(!picker.nextMove());
    ++enumerations;
    return result;
}
void compare(Board& b, Harness& h) {
    ++positions;
    auto legal = b.legalMoves();
    std::set<Move> expected(legal.begin(), legal.end()), tactical;
    Move quiet = Move::none(), otherQuiet = Move::none(), capture = Move::none();
    for (Move m : legal) {
        if (b.isCapture(m)) { tactical.insert(m); capture = m; }
        else { otherQuiet = quiet; quiet = m; }
    }
    const std::string before = b.fen();
    for (int scenario = 0; scenario < 5; ++scenario) {
        Move tt = scenario == 0 ? Move::none() : scenario == 1 ? quiet : scenario == 2 ? capture :
                  scenario == 3 ? Move::makeNormal(99, 99) : quiet;
        h.ss->killer = scenario == 2 ? capture : quiet;
        h.history->setCounterMove((h.ss - 1)->move, scenario == 4 ? quiet : otherQuiet);
        MoveGen main(&b, h.history.get(), h.ss, tt, Depth(600));
        assert(drain(main) == expected);

        MoveGen qsearch(&b, h.history.get(), h.ss, tt, true, Depth(0));
        auto q = drain(qsearch);
        if (b.checkers) assert(q == expected); // captures-only request cannot discard check evasions
        else {
            for (Move m : q) assert(tactical.count(m));
            for (Move m : tactical) if (m.isSpecial()) assert(q.count(m)); // all promotions/EP/escape
        }

        MoveGen probcut(&b, h.history.get(), h.ss, tt, 200, Depth(300));
        std::set<Move> passing;
        for (Move m : tactical) if (SEE(&b, m, 200)) passing.insert(m);
        assert(drain(probcut) == passing);
    }
    // Explicit stage-order checks: TT first, each remaining move exactly once.
    if (!legal.empty()) {
        Move tt = legal.front();
        MoveGen ordered(&b, h.history.get(), h.ss, tt, Depth(300));
        assert(ordered.nextMove() == tt);
        auto rest = drain(ordered);
        auto without = expected; without.erase(tt);
        assert(rest == without);
    }
    MoveGen pruned(&b, h.history.get(), h.ss, Move::none(), Depth(100));
    pruned.skipQuietMoves();
    assert(drain(pruned) == (b.checkers ? expected : tactical));
    assert(b.fen() == before && b.validateBoard() == 0);
}
int main() {
    Harness h;
    std::mt19937 random(25927);
    for (int height : {8,10}) for (int flags = 0; flags < 4; ++flags) {
        Board b{}; b.setVariant(height, flags & 1, flags & 2);
        for (int ply = 0; ply < 48; ++ply) {
            compare(b,h);
            auto moves = b.legalMoves();
            if (moves.empty()) break;
            b.makeMove(moves[random() % moves.size()]);
        }
    }
    for (const std::string fen : {
        "r4k3r/10/10/10/10/10/10/10/10/R4K3R b KQkq - 0 1 t2,2",
        "9k/P9/10/10/10/10/10/10/10/K9 w - - 0 1 t0,0",
        "9k/10/10/10/4Pp4/10/10/10/10/K9 w - f7 0 1 t1,1",
        "10/p9/2p6p/1k1p4p1/10/10/6c3/7K2/10/9q w - - 8 82 t0,0"}) {
        Board b{}; b.setVariant(10,true,true); b.parseFen(fen,false); compare(b,h);
    }
    Board escape{}; escape.setVariant(8,false,true);
    escape.parseFen("PPPPPPPPPk/PPPPPPPPPP/PPPPPPPPPP/PPPPPPPPPP/PPPPPPPPPP/PPPPPPnPPP/PPPPPRPRPP/PPPPPKPPPP w - - 99 1",false);
    compare(escape,h);
    std::cout << "original MoveGen: " << positions << " positions, " << enumerations << " enumerations, " << returned << " moves; coverage/duplicates/TT/quiet pruning/ProbCut OK\n";
    std::cout << "sizeof Board=" << sizeof(Board) << ", MoveGen=" << sizeof(MoveGen) << ", History=" << sizeof(History)
              << ", shared history=" << SharedHistory::allocatedBytes() << " bytes\n";
}
