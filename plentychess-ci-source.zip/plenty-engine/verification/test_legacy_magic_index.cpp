#include "../src/magic.h"
#include <cassert>
#include <cstdint>
#include <iostream>

int main() {
    uint64_t state = 0x9e3779b97f4a7c15ULL;
    auto next = [&]() {
        state ^= state << 13;
        state ^= state >> 7;
        state ^= state << 17;
        return state;
    };
    for (int i = 0; i < 100000; ++i) {
        const uint64_t occ = next(), mask = next(), magic = next();
        const int shift = 52 + (i % 12);
        MagicEntry entry;
        entry.mask = mask;
        entry.magic = magic;
        entry.shift = shift;
        const size_t original = ((occ & mask) * magic) >> shift;
        const Bitboard wideOcc = Bitboard(occ) | (Bitboard(next()) << 64);
        assert(magicIndex(entry, wideOcc) == original);
    }
    std::cout << "8x8 64-bit magic index parity: OK\n";
}
