#include "../src/thread.h"
#include "../src/tt.h"
#include <cassert>
#include <chrono>
#include <future>
#include <iostream>
#include <memory>
#include <random>

Board position(int height,int flags,const std::string& fen) {
    Board b{}; b.setVariant(height,flags&1,flags&2); b.parseFen(fen,false); return b;
}
std::string corner(int height,bool mate) {
    std::string fen;
    for(int r=0;r<height-3;++r)fen+="10/";
    fen+="2K7/"; fen+=mate?"1Q8/":"2Q7/";fen+="k9 b - - 100 1";
    if(height==10)fen+=" t0,0";
    return fen;
}
void verifyPV(Board b,const CoreSearchResult& result) {
    if(result.move) assert(b.isLegal(result.move));
    if(!result.pv.empty()) assert(result.pv.front()==result.move);
    for(Move m:result.pv) {assert(b.isLegal(m));b.makeMove(m);assert(!b.validateBoard());}
}
int main() {
    auto worker=std::make_unique<Worker>();
    SearchParameters limits; limits.depth=2;limits.movetime=2000;limits.infinite=false;
    size_t runs=0;
    for(int height:{8,10})for(int flags=0;flags<4;++flags) {
        Board start{};start.setVariant(height,flags&1,flags&2);
        const auto before=start.fen();
        auto r=worker->run(start,limits);
        assert(r.completed && r.depth==2 && r.move && !r.terminal);
        verifyPV(start,r);assert(start.fen()==before);++runs;
        for(bool mate:{false,true}) {
            auto terminal=position(height,flags,corner(height,mate));
            assert(terminal.legalMoves().empty());
            auto end=worker->run(terminal,limits);
            assert(end.completed && end.terminal && !end.move && end.score==(mate?-EVAL_MATE:0));++runs;
        }
        auto fifty=start;fifty.rule50_ply=100;
        auto drawn=worker->run(fifty,limits);
        assert(drawn.terminal && drawn.score==0 && !drawn.move);++runs;
    }
    Board mating=position(8,3,"10/3p1n4/1p8/9P/7kPK/7P2/10/8q1 b - - 0 72");
    auto win=worker->run(mating,limits);
    assert(win.completed && win.score>=EVAL_MATE-2); verifyPV(mating,win);
    mating.makeMove(win.move);
    assert(mating.checkers && mating.legalMoves().empty());++runs;

    Board cycle{};cycle.setVariant(10,false,false);
    std::vector<Hash> past;
    for(int repeat=0;repeat<2;++repeat) {
        for(const char* s:{"b1c3","b10c8","c3b1","c8b10"}) {
            past.push_back(cycle.hashes.hash);
            Move m=stringToMove(s,&cycle);assert(m);cycle.makeMove(m);
        }
        auto r=worker->run(cycle,limits,past);++runs;
        assert(r.terminal==(repeat==1));
        if(repeat==1)assert(r.score==0 && !r.move);else verifyPV(cycle,r);
    }
    // The same board without supplied history must not inherit the previous draw.
    auto notRepeated=worker->run(cycle,limits);++runs;assert(!notRepeated.terminal && notRepeated.move);
    Board escape=position(8,2,"PPPPPPPPPk/PPPPPPPPPP/PPPPPPPPPP/PPPPPPPPPP/PPPPPPPPPP/PPPPPPnPPP/PPPPPRPRPP/PPPPPKPPPP w - - 99 1");
    auto escaped=worker->run(escape,limits);++runs;
    assert(escaped.move && escaped.move.isEmergency());verifyPV(escape,escaped);

    // Aborting an iteration must retain a legal move and no partial PV/score.
    Board opening{};opening.setVariant(10,true,true);
    SearchParameters tiny; tiny.depth=8;tiny.nodes=1;tiny.movetime=1000;
    auto interrupted=worker->run(opening,tiny);++runs;
    assert(interrupted.move && interrupted.nodes<=1 && !interrupted.completed && interrupted.pv.empty());verifyPV(opening,interrupted);
    SearchParameters timed;timed.depth=12;timed.movetime=30;
    auto begun=std::chrono::steady_clock::now();
    auto bounded=worker->run(opening,timed);++runs;verifyPV(opening,bounded);
    auto elapsed=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now()-begun).count();
    assert(elapsed<1000); // generous CI bound, not a Safari latency promise
    // Reproduce the last completed depth without a deadline. The result must
    // not contain a score or PV from the aborted, deeper iteration.
    if(bounded.completed) {
        SearchParameters exact;exact.depth=bounded.depth;
        auto same=worker->run(opening,exact);++runs;
        assert(same.completed && same.depth==bounded.depth && same.move==bounded.move && same.score==bounded.score && same.pv==bounded.pv);
    }

    // Async cancellation of an already-running native request.
    SearchParameters longRun;longRun.depth=20;longRun.movetime=10000;
    std::promise<void> ready;
    auto started=ready.get_future();
    auto future=std::async(std::launch::async,[&]{ready.set_value();return worker->run(opening,longRun);});
    started.wait();
    // Repeat the cancellation signal until run() has passed its initial reset.
    for(int i=0;i<10000 && future.wait_for(std::chrono::milliseconds(1))!=std::future_status::ready;++i)worker->requestStop();
    assert(future.wait_for(std::chrono::seconds(1))==std::future_status::ready);
    auto cancelled=future.get();verifyPV(opening,cancelled);++runs;

    std::mt19937 random(260928);
    SearchParameters shortRun;shortRun.depth=1;shortRun.movetime=100;
    for(int flags=0;flags<4;++flags) {
        Board b{};b.setVariant(10,flags&1,flags&2);
        for(int ply=0;ply<12;++ply) {
            auto r=worker->run(b,shortRun);++runs;
            if(r.terminal)break;
            verifyPV(b,r);assert(r.move);b.makeMove(r.move);
            auto replies=b.legalMoves();if(replies.empty())break;
            b.makeMove(replies[random()%replies.size()]);
        }
    }
    // Zero hash suffix must not look like an initialized empty entry.
    TT.clear();bool found=true;auto* entry=TT.probe(0,&found);assert(!found);
    Move promoted=Move::makePromotion(89,99,CHANCELLOR);
    entry->update(0,promoted,200,25,100,99,false,TT_EXACTBOUND);
    entry=TT.probe(0,&found);assert(found && entry->getMove()==promoted && entry->getValue()==100);
    TT.resize(1);assert(TT.hashfull()==0);
    bool rejected=false;try{TT.resize(0);}catch(const std::invalid_argument&){rejected=true;}assert(rejected);
    std::cout<<"original search.cpp: "<<runs<<" runs; openings, mate/stalemate, 50-move, repetition, emergency, PV, deadlines, cancellation, TT OK; 30ms request elapsed "<<elapsed<<"ms\n";
}
