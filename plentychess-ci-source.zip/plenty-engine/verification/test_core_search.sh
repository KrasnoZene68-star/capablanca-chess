#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
core_build_dir="$(mktemp -d "${TMPDIR:-/tmp}/plenty-core26.XXXXXX")"
flags=(-std=c++17 -DCAPABLANCA_CORE -O2 -pthread)
if [[ "${SANITIZE:-0}" == 1 ]]; then
 flags=(-std=c++17 -DCAPABLANCA_CORE -O1 -g -pthread -fsanitize=address,undefined -fno-omit-frame-pointer)
fi
if [[ "${POSITIONAL_EVAL:-0}" == 1 ]]; then flags+=(-DCAPABLANCA_POSITIONAL_EVAL); fi
"${CXX:-g++}" "${flags[@]}" verification/test_core_search.cpp src/board.cpp src/move.cpp \
 src/history.cpp src/evaluation.cpp src/search.cpp src/tt.cpp src/time.cpp src/core_worker.cpp -o "$core_build_dir/test_core_search"
"$core_build_dir/test_core_search"
echo "PASS. Native search executable: $core_build_dir/test_core_search"
