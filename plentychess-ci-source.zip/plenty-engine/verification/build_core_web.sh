#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
sources=(verification/core_web.cpp src/board.cpp src/move.cpp src/history.cpp src/evaluation.cpp src/search.cpp src/tt.cpp src/time.cpp src/core_worker.cpp)
eval_flags=()
if [[ "${POSITIONAL_EVAL:-0}" == 1 ]]; then eval_flags+=(-DCAPABLANCA_POSITIONAL_EVAL); fi
if [[ "${BASELINE_EVAL:-0}" == 1 ]]; then eval_flags+=(-DCAPABLANCA_BASELINE_EVAL); fi
if [[ "${1:-native}" == wasm ]]; then
  emxx="${EMXX:-em++}"
  command -v "$emxx" >/dev/null || { echo 'Emscripten em++ is required; no WASM produced.' >&2; exit 2; }
  wasm_build_dir="$(mktemp -d "${TMPDIR:-/tmp}/plenty-wasm-build.XXXXXX")"
  "$emxx" -std=c++17 -DCAPABLANCA_CORE "${eval_flags[@]}" -O2 -fexceptions "${sources[@]}" \
    -sDISABLE_EXCEPTION_CATCHING=0 -sMODULARIZE=1 -sEXPORT_NAME=PlentyCore \
    -sENVIRONMENT=worker,node -sALLOW_MEMORY_GROWTH=1 -sTOTAL_STACK=8388608 \
    -sINITIAL_MEMORY=67108864 -sMAXIMUM_MEMORY=268435456 \
    '-sEXPORTED_FUNCTIONS=["_pc_error","_pc_variant","_pc_position","_pc_search","_pc_depth","_pc_score","_pc_completed","_pc_terminal","_pc_nodes","_pc_pv","_pc_fen","_pc_evaluator"]' \
    '-sEXPORTED_RUNTIME_METHODS=["ccall"]' -o "$wasm_build_dir/plenty-core.js"
  # Do not replace working outputs when the compiler fails partway through.
  test -s "$wasm_build_dir/plenty-core.js" && test -s "$wasm_build_dir/plenty-core.wasm"
  mkdir -p verification/core-dist
  cp "$wasm_build_dir/plenty-core.js" "$wasm_build_dir/plenty-core.wasm" verification/core-dist/
else
  "${CXX:-g++}" -std=c++17 -DCAPABLANCA_CORE "${eval_flags[@]}" -O2 -pthread -fPIC -shared \
    "${sources[@]}" -o "${2:-/tmp/libplenty-core27.so}"
fi
