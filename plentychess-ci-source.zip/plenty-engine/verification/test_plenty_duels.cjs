// Real UI, real workers and all three real WASM engines; no search mocks.
const assert=require('node:assert/strict'),fs=require('node:fs');
const open=require('./game_browser_harness.cjs');
(async()=>{
 const h=await open(process.argv[2]);const reports=[];
 async function setup(height,rule,r,g,level=1,time=0){
  await h.run(`modeEl.value='engines';boardSizeEl.value='${height}';variantEl.value='${rule}';duelRedEngineEl.value='${r}';duelGreenEngineEl.value='${g}';duelRedLevel.value=duelGreenLevel.value='${level}';timeControl.value='${time}';reset();`);
 }
 try{
  await h.page.click('#settingsOpen');
  await h.page.selectOption('#mobileMode','engines');
  await h.page.selectOption('#mobileDuelRedEngine','reckless');
  await h.page.selectOption('#mobileDuelGreenEngine','plenty');
  assert.equal(await h.run("duelEngines.r+','+duelEngines.g"),'reckless,plenty');
  assert.equal(await h.run("duelRedEngineEl.value+','+duelGreenEngineEl.value"),'reckless,plenty');
  await h.page.click('#settingsDone');
  // Both selectors synchronize mobile/desktop, including same-engine matches.
  await h.run("modeEl.value='engines';syncDuelEngine('r','plenty');syncDuelEngine('g','reckless')");
  assert.equal(await h.run("mobileDuelRedEngine.value+','+mobileDuelGreenEngine.value"),'plenty,reckless');
  const cases=[];
  for(const height of [8,10])for(const [index,rule] of ['classic','kingKnight','escape','both'].entries()){
   const opponent=index%2?'reckless':'stockfish';
   cases.push({height,rule,r:index<2?'plenty':opponent,g:index<2?opponent:'plenty',plies:100});
  }
  cases.push({height:10,rule:'both',r:'plenty',g:'plenty',plies:100});
  if(process.env.CONTROLS_ONLY)cases.length=0;
  for(const c of cases){
   await setup(c.height,c.rule,c.r,c.g);
   await h.run('startDuel()');
   await h.wait(`history.length>=${c.plies}||gameOver||!duelRunning`,180000);
   const report=await h.run("pauseDuel();gameReport()");
   assert.ok(report.moves.length>=c.plies||report.result!=='*',report.duel.pausedReason);
   assert.equal(report.duel.r.engine,c.r);assert.equal(report.duel.g.engine,c.g);
   for(let i=0;i<report.moves.length;i++){
    const move=report.moves[i];const expected=(i%2?c.g:c.r);
    assert.equal(move.engine.name,{plenty:'PlentyChess experimental',stockfish:'Fairy-Stockfish',reckless:'Reckless'}[expected]);
    if(i)assert.equal(move.beforeFen,report.moves[i-1].afterFen);
    if(expected==='plenty')assert.equal(move.engine.analysis.score,undefined);
   }
   reports.push(report);
   console.log('PASS duel',JSON.stringify({height:c.height,rule:c.rule,r:c.r,g:c.g,plies:report.moves.length,result:report.result,end:report.endReason}));
  }
  // Pause an in-flight high-level Plenty calculation, resume same position.
  await setup(10,'both','plenty','reckless',48,1);
  await h.run('startDuel();pauseDuel()');
  const paused=await h.run('gameReport()');
  await h.page.waitForTimeout(400);
  assert.equal(await h.run('history.length'),0);
  assert.equal(await h.run('clock.r'),paused.clock.r);
  await h.run("duelRedLevel.value=duelGreenLevel.value='1';startDuel()");
  await h.wait('history.length>=2||gameOver||!duelRunning');
  await h.run('pauseDuel()');assert.ok(await h.run('history.length>=2'));
  // Deadline while the module is still loading: no late move may be committed.
  h.faults.delay=500;
  await setup(10,'both','plenty','reckless',48,1);
  await h.run('clock.r=10;startDuel()');
  await h.wait('gameOver');
  assert.equal(await h.run('endKind'),'timeout');
  await h.page.waitForTimeout(650);
  assert.equal(await h.run('history.length'),0);h.faults.delay=0;
  // Failed module: match pauses, never silently substitutes the local AI.
  h.faults.wasm=true;
  await setup(8,'classic','plenty','reckless');await h.run('startDuel()');
  await h.wait('!duelRunning');
  assert.equal(await h.run('history.length'),0);
  assert.ok(await h.run('duelPauseReason.length>0'));
  h.faults.wasm=false;
  await h.run('startDuel()');await h.wait('history.length>=2||!duelRunning');
  assert.ok(await h.run('history.length>=2'));await h.run('pauseDuel()');
  // Already-expired clock at start must not resurrect a finished duel.
  await setup(8,'classic','plenty','reckless',1,1);
  await h.run('clock.r=0;startDuel()');
  assert.equal(await h.run('gameOver'),true);
  assert.equal(await h.run('duelRunning'),false);
  assert.equal(await h.run('history.length'),0);
  assert.deepEqual(h.errors,[]);
  if(process.argv[3])fs.writeFileSync(process.argv[3],JSON.stringify(reports,null,2));
  console.log('PASS pause/resume, frozen clock, timeout during WASM loading, network failure and recovery; no late/fallback moves');
 }finally{await h.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
