#include "../src/evaluation.h"
#include <cassert>
#include <iostream>
#include <random>
#include <algorithm>

Board load(const std::string& fen,int flags=0){Board b{};b.setVariant(int(std::count(fen.begin(),fen.end(),'/'))+1,flags&1,flags&2);b.parseFen(fen,false);return b;}
std::string transform(const Board& b,bool swap){
    const char* letters="PNBRQKAC";std::string fen;
    for(int r=b.geometry.height-1;r>=0;--r){int empty=0;
        for(int f=0;f<10;++f){const Square s=Square((swap?b.geometry.height-1-r:r)*10+(swap?f:9-f));const Piece p=b.pieces[s];
            if(p==Piece::NONE){++empty;continue;}
            if(empty){fen+=std::to_string(empty);empty=0;}
            const bool white=bool(b.byColor[WHITE]&bitboard(s))!=swap;
            char c=letters[p];fen+=white?c:char(std::tolower(c));
        }
        if(empty)fen+=std::to_string(empty);
        if(r)fen+='/';
    }
    const bool whiteTurn=(b.stm==WHITE)!=swap;
    fen+=whiteTurn?" w - - 0 1":" b - - 0 1";
    if(b.geometry.height==10)fen+=" t0,0";
    return fen;
}
int main(){
    std::mt19937 rng(3030);int positions=0;
    for(int height:{8,10})for(int flags=0;flags<4;++flags){
        Board b{};b.setVariant(height,flags&1,flags&2);
        assert(evaluateCorePosition(b).phase==34&&evaluateCorePosition(b).total==0);
        for(int ply=0;ply<60;++ply){
            const auto before=b.fen();auto e=evaluateCorePosition(b);
            Board colors=load(transform(b,true),flags),files=load(transform(b,false),flags);
            assert(evaluateCorePosition(colors).total==-e.total);
            assert(evaluateCorePosition(files).total==e.total);
            std::array<int,2> optimism{};
            assert(evaluate(&b,nullptr,optimism)==evaluate(&colors,nullptr,optimism));
            assert(b.fen()==before);++positions;
            const auto moves=b.legalMoves();if(moves.empty())break;
            b.makeMove(moves[rng()%moves.size()]);
        }
    }
    const auto blocked=load("9k/10/4p5/4P5/10/10/10/K9 w - - 0 1");
    const auto passed=load("9k/10/8p1/4P5/10/10/10/K9 w - - 0 1");
    assert(evaluateCorePosition(passed).pawnsEG>evaluateCorePosition(blocked).pawnsEG);
    const auto rear=load("9k/10/10/10/10/P9/10/K9 w - - 0 1");
    const auto advanced=load("9k/P9/10/10/10/10/10/K9 w - - 0 1");
    assert(evaluateCorePosition(advanced).pawnsEG>evaluateCorePosition(rear).pawnsEG);
    const auto corner=load("9k/10/10/10/10/10/10/K9 w - - 0 1");
    const auto centralKing=load("9k/10/10/10/4K5/10/10/10 w - - 0 1");
    assert(evaluateCorePosition(centralKing).kingEG>evaluateCorePosition(corner).kingEG);
    const std::string pressure="k9/10/10/4r5/10/10/10/5K4 w - - 0 1";
    assert(evaluateCorePosition(load(pressure,1)).kingMG<evaluateCorePosition(load(pressure,0)).kingMG);
    for(char piece:{'N','A','C'}){
        const auto edge=load(std::string("9k/10/10/10/10/10/10/K8")+piece+" w - - 0 1");
        const auto center=load(std::string("9k/10/10/4")+piece+"5/10/10/10/K9 w - - 0 1");
        assert(evaluateCorePosition(center).activityMG>evaluateCorePosition(edge).activityMG);
    }
    std::cout<<"PASS tapered evaluator: "<<positions<<" reachable positions, color/file symmetry, no mutation; passer, king and compound mobility fixtures\n";
}
