// Deterministic game playouts and two-ply perft against the v5.12.0 rules.
const fs=require('fs'),vm=require('vm'),cp=require('child_process'),path=require('path');
const source=fs.readFileSync(path.join(__dirname,'compare_existing_game.cjs'),'utf8');
const bridge=source.slice(source.indexOf('function parseFen('),source.indexOf('let seed ='));
const boot={};vm.createContext(boot);vm.runInContext(bridge,boot);
const parseFen=boot.parseFen;
const ruleSource=fs.readFileSync(path.join(__dirname,'game_rules_v5_12_0.js'),'utf8');
const perftSource=`function perft(s,color,ep,depth){
 if(!depth)return 1;
 let total=0;
 for(const m of allLegalMoves(s,color,ep)){
  if(s[m.tr][m.tc]?.t==='K')continue;
  const next=applyMove(s,m,ep,true);
  total+=perft(next.s,enemy(color),next.ep,depth-1);
 }
 return total;
}`;
const binary=process.env.VARIANT_PERFT_BINARY||path.join(__dirname,'variant_perft');
const initial=rows=>rows===8?
 'rnabqkbcnr/pppppppppp/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1':
 'rnabqkbcnr/pppppppppp/10/10/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1 t2,2';
function toFen(s,color,ep,rows){
 const placement=s.map(rank=>{
  let out='',blanks=0;
  for(const p of rank){
   if(!p){blanks++;continue}
   if(blanks){out+=blanks;blanks=0}
   out+=p.c==='r'?p.t:p.t.toLowerCase();
  }
  return out+(blanks||'');
 }).join('/');
 let rights='';
 for(const [key,side,row,file] of [['K','r',rows-1,9],['Q','r',rows-1,0],['k','g',0,9],['q','g',0,0]]){
  if(s[row][5]?.t==='K'&&s[row][5].c===side&&!s[row][5].m&&
     s[row][file]?.t==='R'&&s[row][file].c===side&&!s[row][file].m)rights+=key;
 }
 const targets=ep?(ep.targets||[ep]):[];
 const enPassant=targets.map(t=>String.fromCharCode(97+t.c)+(rows-t.r)).join('')||'-';
 const budget=s.tripleRemaining||{r:2,g:2};
 return `${placement} ${color==='r'?'w':'b'} ${rights||'-'} ${enPassant} ${s.halfmoveClock||0} ${s.fullmoveNumber||1}${rows===10?` t${budget.r},${budget.g}`:''}`;
}
let rng=0x1bf454e9;
function random(n){rng^=rng<<13;rng^=rng>>>17;rng^=rng<<5;return (rng>>>0)%n}
let positions=0,comparisons=0;
for(const rows of [8,10])for(const variantName of ['normal','kingKnight','escape','both']){
 const {s:initialBoard,color:initialColor,ep:initialEp}=parseFen(rows,initial(rows));
 const context={ROWS:rows,variant:()=>variantName,epSquare:initialEp};
 vm.createContext(context);vm.runInContext(ruleSource+'\n'+perftSource,context);
 context.s=initialBoard;context.color=initialColor;context.ep=initialEp;
 for(let ply=0;ply<32;ply++){
  const fen=toFen(context.s,context.color,context.ep,rows);
  if(ply%4===0){
   const js=vm.runInContext('perft(s,color,ep,2)',context);
   const cpp=Number(cp.execFileSync(binary,[String(rows),variantName,'2',fen],{encoding:'utf8'}));
   if(js!==cpp){console.error('DIFFERENCE',{rows,variantName,ply,fen,js,cpp});process.exit(1)}
   positions++;comparisons++;
  }
  const moves=vm.runInContext('allLegalMoves(s,color,ep)',context)
   .filter(m=>context.s[m.tr][m.tc]?.t!=='K');
  if(!moves.length)break;
  const chosen=moves[random(moves.length)];
  context.m=chosen;
  const result=vm.runInContext('applyMove(s,m,ep,true)',context);
  context.s=result.s;context.ep=result.ep;context.color=context.color==='r'?'g':'r';
 }
}
console.log(`${positions} reachable positions / ${comparisons} depth-two perft comparisons: matched`);
