function fen(p,rows=8,side='w',ep='-',budget='2,2'){
 const board=Array.from({length:rows},()=>Array(10).fill(''));
 for(const [sq,pc]of Object.entries(p))board[rows-Number(sq.slice(1))][sq.charCodeAt(0)-97]=pc;
 return board.map(row=>{let n=0,s='';for(const p of row){if(!p)n++;else{if(n)s+=n;n=0;s+=p}}return s+(n||'')}).join('/')+` ${side} - ${ep} 0 1`+(rows===10?' t'+budget:'');
}
function mirror(f){const a=f.split(' '),rows=a[0].split('/').length;a[0]=a[0].split('/').reverse().map(r=>r.replace(/[a-z]/gi,c=>c===c.toUpperCase()?c.toLowerCase():c.toUpperCase())).join('/');a[1]=a[1]==='w'?'b':'w';a[3]=a[3].replace(/([a-j])(10|[1-9])/g,(_,c,r)=>c+(rows+1-Number(r)));if(a[6])a[6]='t'+a[6].slice(1).split(',').reverse().join(',');return a.join(' ')}
function cases(rows){let k={[(rows===10?'i':'j')+rows]:'k'};return [
 {name:'capture checking bishop with rook',fen:fen({...k,b1:'K',e2:'R',e4:'b',j7:'r'},rows),good:['e2e4']},
 {name:'capture checking rook with bishop',fen:fen({...k,b1:'K',c3:'B',e1:'r',j7:'p'},rows),good:['c3e1']},
 {name:'capture checking pawn',fen:fen({...k,e3:'K',c3:'P',d4:'p',j7:'r',a2:'R'},rows),good:['c3d4','e3d4']},
 {name:'capture pawn threatening promotion',fen:fen({...k,j1:'K',a2:'R',d2:'p',c1:'N'},rows),good:['a2d2']},
 {name:'ordinary pawn capture',fen:fen({...k,a1:'K',c4:'P',d5:'p',a2:'R',j7:'r'},rows),good:['c4d5']},
 ...['a','c'].map(piece=>({name:'prefer '+piece+' to rook',fen:fen({...k,a1:'K',e4:'R',e6:piece,g4:'r'},rows),good:['e4e6']})),
 {name:'avoid poisoned checking bishop',fen:fen({...k,b1:'K',e2:'Q',e4:'b',e8:'r'},rows),bad:['e2e4']},
 {name:'pinned defender cannot capture checker',fen:fen({...k,a2:'K',b2:'R',b4:'n',j2:'r'},rows),illegal:['b2b4']},
 ...(rows===8?[{name:'en passant double',fen:fen({...k,a1:'K',e5:'P',d5:'p'},rows,'w','d6'),good:['e5d6']}]:[
 {name:'en passant triple near',fen:fen({...k,a1:'K',e6:'P',d6:'p'},rows,'w','d7d8','2,1'),good:['e6d7']},
 {name:'en passant triple far',fen:fen({...k,a1:'K',e7:'P',d6:'p'},rows,'w','d7d8','2,1'),good:['e7d8']}
 ])
]}
const engineName=(rule,rows)=>({classic:'capablanca',kingKnight:'capablanca_kingknight',escape:'capablanca_escape',both:'capablanca_both'})[rule].replace('capablanca',rows===10?'capablanca10':'capablanca');
module.exports={fen,mirror,cases,engineName};
