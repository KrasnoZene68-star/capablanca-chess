// Inserted inside the game's IIFE; functions run after game initialization.
let plentyClient=null,plentyLastSearchOk=null,plentyFailureReason='';
function discardPlenty(){if(plentyClient)plentyClient.cancel();plentyClient=null;}
async function plentyBestMove(request){
 if(!currentAiRequest(request)||settleClock())return null;
 try{
  if(!plentyClient)plentyClient=new PlentyCoreClient('./plenty-core.worker.js?v=28');
  const match=request.position.match(/^position fen (.+?)(?: moves (.*))?$/);
  if(!match)throw new Error('Некоректна історія позиції');
  const moveTime=clock.running?Math.max(1,Math.min(request.strength.moveTime,Math.floor(clock[turn]/20),Math.floor(clock[turn]-30))):request.strength.moveTime;
  const flags={classic:0,kingKnight:1,escape:2,both:3}[request.variant];
  const reply=await plentyClient.search({height:request.rows,flags,fen:match[1],moves:match[2]||'',
   depth:request.strength.searchDepth||0,milliseconds:moveTime},moveTime+10000);
  if(!currentAiRequest(request))return null;
  if(reply.engine!=='PlentyChess-original-core-experimental')throw new Error('Невідповідна версія PlentyChess');
  if(reply.terminal){request.plentyTerminal=true;throw new Error('Рушій визначив завершення: потрібна перевірка правил гри');}
  const move=uciToMove(reply.move);
  if(!move)throw new Error('PlentyChess повернув нелегальний хід');
  request.engineName='PlentyChess experimental';
  // Raw evaluation is deliberately excluded from the mate/cp autosurrender API.
  request.analysis={depth:reply.depth,nodes:reply.nodes,pv:reply.pv,completed:reply.completed,
   rawScore:reply.score,scorePerspective:reply.scorePerspective,evaluator:reply.evaluator||'temporary-material-center'};
  request.actualLimits={depth:request.strength.searchDepth||0,timeMs:moveTime,level:request.strength.level,calibrated:false};
  plentyLastSearchOk=true;plentyFailureReason='';updateStrengthStatus();return move;
 }catch(e){
  if(currentAiRequest(request)){plentyLastSearchOk=false;plentyFailureReason=String(e.message||e);discardPlenty();updateStrengthStatus();}
  return null;
 }
}
