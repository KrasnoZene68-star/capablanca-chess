#pragma once
// Internal settings for the single-thread native port, not a UCI implementation.
namespace UCI {
template<class T> struct CoreOption { T value; };
struct CoreOptions {
    CoreOption<int> threads{1}, multiPV{1}, moveOverhead{0};
    CoreOption<bool> datagen{false}, minimal{true}, chess960{false};
};
inline CoreOptions Options;
}
