#pragma once

#include <stdint.h>
#include <cassert>
#include <string>
#include <sstream>
#include <iostream>
#ifdef CAPABLANCA_CORE
#include <vector>
#include <stdexcept>
#endif

#if !defined(__always_inline)
#define __always_inline
#endif

// General constants and types
using Eval = int16_t;
using Square = uint8_t;
using Bitboard = unsigned __int128;
using Depth = int16_t;
using Hash = uint64_t;

constexpr int MAX_PLY = 250;
constexpr Depth MAX_DEPTH = (MAX_PLY - 1) * 100;
#ifdef CAPABLANCA_CORE
// Loose bound: at most 35 queen destinations per origin on 10x10;
// other pieces (including six-way pawn promotions) have fewer.
// The dynamic core generator does not use the upstream fixed MoveList yet.
constexpr int MAX_MOVES = 4096;
constexpr int MAX_CAPTURES = 4096;
constexpr Square NO_SQUARE = 100;
constexpr int BOARD_WIDTH = 10;
constexpr int BOARD_CAPACITY = 100;
#else
constexpr int MAX_MOVES = 218;
constexpr int MAX_CAPTURES = 74;
constexpr Square NO_SQUARE = 64;
constexpr int BOARD_WIDTH = 8;
constexpr int BOARD_CAPACITY = 64;
#endif

constexpr int fileOf(const Square square) {
    return square % BOARD_WIDTH;
}
constexpr int rankOf(const Square square) {
    return square / BOARD_WIDTH;
}

inline std::ostream& operator<<(std::ostream& os, const Square square) {
    os << char('a' + fileOf(square)) << (rankOf(square) + 1);
    return os;
}

// Color
enum Color : uint8_t {
    WHITE = 0,
    BLACK = 1
};

constexpr Color& operator++(Color& color) {
    color = static_cast<Color>(static_cast<int>(color) + 1);
    return color;
}

// Piece
enum Piece : uint8_t {
    PAWN = 0,
    KNIGHT = 1,
    BISHOP = 2,
    ROOK = 3,
    QUEEN = 4,
    KING = 5,
#ifdef CAPABLANCA_CORE
    ARCHBISHOP = 6,
    CHANCELLOR = 7,
    NONE = 8,
    TOTAL = 8
#else
    NONE = 6,
    TOTAL = 6
#endif
};

constexpr Piece& operator++(Piece& piece) {
    piece = static_cast<Piece>(static_cast<int>(piece) + 1);
    return piece;
}

inline std::ostream& operator<<(std::ostream& os, const Piece piece) {
#ifdef CAPABLANCA_CORE
    static std::string pieceChars = "pnbrqkac ";
#else
    static std::string pieceChars = "pnbrqk ";
#endif
    os << pieceChars[piece];
    return os;
}

// Move
enum MoveType : uint8_t {
    NORMAL = 0,
    PROMOTION = 1,
    ENPASSANT = 2,
    CASTLING = 3,
    EMERGENCY = 4
};

struct Move {

    Move() = default;
    
    static constexpr Move none() { return Move{0}; };
    static constexpr Move makeNormal(Square origin, Square target) {
        return Move((origin & 0x7F) | ((target & 0x7F) << 7));
    }
    static constexpr Move makePromotion(Square origin, Square target, Piece promotionPiece) {
        assert(promotionPiece >= Piece::KNIGHT);
#ifdef CAPABLANCA_CORE
        assert(promotionPiece <= Piece::CHANCELLOR && promotionPiece != Piece::KING);
#else
        assert(promotionPiece <= Piece::QUEEN);
#endif
        return Move(origin | (target << 7) | (MoveType::PROMOTION << 14) | ((promotionPiece - 1) << 17));
    }
    static constexpr Move makeEnpassant(Square origin, Square target) {
        return Move(origin | (target << 7) | (MoveType::ENPASSANT << 14));
    }
    static constexpr Move makeCastling(Square origin, Square target) {
        return Move(origin | (target << 7) | (MoveType::CASTLING << 14));
    }
    static constexpr Move makeEmergency(Square origin, Square target) {
        return Move(origin | (target << 7) | (MoveType::EMERGENCY << 14));
    }
    constexpr bool isEmergency() const { return *this && type() == MoveType::EMERGENCY; }

    constexpr Square origin() const {
        return Square(data & 0x7F);
    }
    constexpr Square target() const {
        return Square((data >> 7) & 0x7F);
    }
    constexpr MoveType type() const {
        assert(*this);
        return MoveType((data >> 14) & 0x7);
    }
    constexpr Piece promotionPiece() const {
        assert(*this);
        assert(isPromotion());
        return Piece(((data >> 17) & 0x7) + 1);
    }

    constexpr bool isSpecial() const {
        assert(*this);
        return type() != MoveType::NORMAL;
    }
    constexpr bool isPromotion() const {
        assert(*this);
        return type() == MoveType::PROMOTION;
    }
    constexpr bool isCastling() const {
        assert(*this);
        return type() == MoveType::CASTLING;
    }
    constexpr bool isEnpassant() const {
        assert(*this);
        return type() == MoveType::ENPASSANT;
    }

    constexpr operator bool() const {
        return static_cast<bool>(data);
    }

    constexpr bool operator<(const Move& other) const {
        return data < other.data;
    }
    constexpr bool operator<(Move& other) {
        return data < other.data;
    }

    constexpr bool operator==(const Move& other) const {
        return data == other.data;
    }
    constexpr bool operator==(Move& other) {
        return data == other.data;
    }
    constexpr bool operator!=(const Move& other) const {
        return data != other.data;
    }
    constexpr bool operator!=(Move& other) {
        return data != other.data;
    }

    std::string toString(bool chess960) const {
        if (!*this) return "0000";
        std::ostringstream os;

        Square from = origin(), to = target();
        if (isCastling() && !chess960) {
            int rank = rankOf(from);
            int file = from > to ? 2 : BOARD_WIDTH - 2;
            to = rank * BOARD_WIDTH + file;
        }

        os << from << to;
        if (isPromotion())
            os << promotionPiece();

        return os.str();
    }

private:

    constexpr Move(uint32_t _data) : data(_data) {
        assert(origin() < 100);
        assert(target() < 100);
    };

    uint32_t data;
};

static_assert(sizeof(Move) == 4, "Extended move encoding must fit in 32 bits");

// Helper functions
inline Square lsb(Bitboard bb) {
    assert(bb > 0);
    const uint64_t low = static_cast<uint64_t>(bb);
    return low ? __builtin_ctzll(low) : 64 + __builtin_ctzll(static_cast<uint64_t>(bb >> 64));
}
inline Square popLSB(Bitboard* bb) {
    Square l = lsb(*bb);
    *bb &= *bb - 1;
    return l;
}

inline Square msb(Bitboard bb) {
    assert(bb > 0);
    const uint64_t high = static_cast<uint64_t>(bb >> 64);
    return high ? 127 - __builtin_clzll(high) : 63 - __builtin_clzll(static_cast<uint64_t>(bb));
}
inline Square popMSB(Bitboard* bb) {
    Square l = msb(*bb);
    *bb &= *bb - 1;
    return l;
}

constexpr Bitboard bitboard(int32_t number) {
    return static_cast<Bitboard>(number);
}
constexpr Bitboard bitboard(long number) {
    return static_cast<Bitboard>(number);
}
constexpr Bitboard bitboard(uint64_t number) {
    return static_cast<Bitboard>(number);
}
constexpr Bitboard bitboard(Square square) {
    return static_cast<Bitboard>(1) << square;
}

constexpr Color flip(Color color) {
    return static_cast<Color>(1 - color);
}

// ArrayVec
#ifdef CAPABLANCA_CORE
// Avoid reserving the 4096-move worst case at every search ply. Keep the same
// upstream API and an enforced ceiling, including in release builds.
template<class T, size_t MAX>
class ArrayVec {
    std::vector<T> elements;
public:
    void add(const T& value) {
        if (elements.size() == MAX) throw std::length_error("move buffer capacity exceeded");
        elements.push_back(value);
    }
    void addIf(const T& value, bool condition) { if (condition) add(value); }
    T remove(size_t i) {
        assert(i < elements.size());
        T value = elements[i]; elements[i] = elements.back(); elements.pop_back(); return value;
    }
    T& operator[](size_t i) { assert(i < elements.size()); return elements[i]; }
    const T& operator[](size_t i) const { assert(i < elements.size()); return elements[i]; }
    int size() const { return int(elements.size()); }
    int capacity() const { return MAX; }
    auto begin() { return elements.begin(); }
    auto end() { return elements.end(); }
    auto begin() const { return elements.begin(); }
    auto end() const { return elements.end(); }
};
#else
template<class T, size_t MAX>
class ArrayVec {
public:

    ArrayVec() : _size(0) {}

    void add(const T& element) {
        assert(_size < MAX);
        elements[_size++] = element;
    }

    void addIf(const T& element, bool condition) {
        assert(_size < MAX);
        elements[_size] = element;
        _size += condition;
    }

    T remove(size_t i) {
        T removed = elements[i];
        elements[i] = elements[--_size];
        return removed;
    }

    T& operator[](size_t i) {
        assert(i < _size);
        return elements[i];
    }

    T const& operator[](size_t i) const {
        assert(i < _size);
        return elements[i];
    }

    int size() const {
        return _size;
    }

    int capacity() const {
        return MAX;
    }

    const T* begin() const { return elements; }
    const T* end() const { return elements + _size; }

private:
    T elements[MAX];
    size_t _size{};
};
#endif

// Search Stack
struct SearchStack {
    int pvLength;
    Move pv[MAX_PLY + 1];

    int ply;

    Eval staticEval;

    Move move;
    Piece movedPiece;
    bool inCheck, capture;
    int correctionValue;
    Depth reduction;
    bool inLMR, ttPv;

    Move excludedMove;
    Move killer;

    int16_t* contHist;
    int16_t* contCorrHist;
};

struct DirtyPiece {
    // Base data for a standard move
    Piece piece;
    Color pieceColor;
    Square origin, target; // target is empty in case of promotion

    // For captures - color of the piece is the opposite of pieceColor
    // In case of castling, contains the origin square of the rook
    Piece removePiece;
    Square removeSquare;

    // For promotions - color of the piece is the same as pieceColor
    // In case of castling, contains the target square of the rook
    Piece addPiece;
    Square addSquare;
};
