#pragma once

#include <stdint.h>
#include <stdbool.h>
#include <string>
#include <sstream>

#include "move.h"
#include "bitboard.h"
#include "types.h"
#ifdef CAPABLANCA_CORE
#include "capablanca_geometry.h"
#include <vector>
#endif

class NNUE;

namespace Castling {

    using CastlingDirection = size_t;
    constexpr CastlingDirection KINGSIDE = 0;
    constexpr CastlingDirection QUEENSIDE = 1;

    constexpr CastlingDirection getDirection(Square kingOrigin, Square kingTarget) {
        return (kingTarget <= kingOrigin) ? QUEENSIDE : KINGSIDE;
    }
    
    constexpr uint8_t getMask(Color side, CastlingDirection direction) {
        return 1 << (2 * side + direction);
    }

    constexpr uint8_t getMask(Color side) {
        return getMask(side, KINGSIDE) | getMask(side, QUEENSIDE);
    }

#ifndef CAPABLANCA_CORE
    constexpr uint8_t getKingSquare(Color side, CastlingDirection direction) {
        constexpr Square KING_SQUARES[] = { 6, 2, 62, 58 };
        return KING_SQUARES[2 * side + direction];
    }

    constexpr uint8_t getRookSquare(Color side, CastlingDirection direction) {
        constexpr Square ROOK_SQUARES[] = { 5, 3, 61, 59 };
        return ROOK_SQUARES[2 * side + direction];
    }
#else
    // Height must be explicit: silently assuming rank eight is unsafe.
    constexpr Square getKingSquare(Color side, CastlingDirection direction, int height) {
        return Square((side == BLACK ? height - 1 : 0) * 10 + (direction == KINGSIDE ? 8 : 2));
    }
    constexpr Square getRookSquare(Color side, CastlingDirection direction, int height) {
        return Square((side == BLACK ? height - 1 : 0) * 10 + (direction == KINGSIDE ? 7 : 3));
    }
#endif

}

struct Threats {
    Bitboard pawnThreats;
    Bitboard knightThreats;
    Bitboard bishopThreats;
    Bitboard rookThreats;
    Bitboard queenThreats;
    Bitboard kingThreats;
#ifdef CAPABLANCA_CORE
    Bitboard archbishopThreats;
    Bitboard chancellorThreats;
#endif
    Bitboard allThreats;
};

struct Hashes {
    Hash hash;
    Hash pawnHash;
    Hash nonPawnHash[2];
    Hash minorHash;
    Hash majorHash;
};

struct Board {
    Threats threats;
    Hashes hashes;

    Bitboard byPiece[Piece::TOTAL];
    Bitboard byColor[2];
    Bitboard enpassantTarget;
    Bitboard blockers[2];
    Bitboard checkers;
    Move lastMove;
    uint8_t checkerCount;
    Piece pieces[BOARD_CAPACITY];

    Color stm;

    uint8_t castling;
    Square castlingSquares[4]; // For each castling right, stores the square of the corresponding rook

#ifdef CAPABLANCA_CORE
    uint32_t ply;
    uint16_t rule50_ply;
    uint16_t nullmove_ply;
    CapablancaPort::Geometry geometry{10, 10};
    bool kingKnight = false;
    bool emergencyEscape = false;
    uint8_t tripleRemaining[2]{2, 2};
    Square enpassantCaptured = NO_SQUARE;

    void setVariant(int height, bool knightKing, bool escape);
    std::vector<Move> legalMoves() const;
    Bitboard attacksFrom(Square square, Bitboard occupied) const;
    bool kingInCheck(Color side) const;
    Hash rule50Hash() const;
    // Checked public move application; nullptr is required until NNUE is ported.
    void makeMove(Move move);

private:
    friend int staticExchangeValue(Board* board, Move move);
    std::vector<Move> regularCandidates() const;
    bool safeAfter(Move move) const;
    void applyUnchecked(Move move);
    void refreshDerived();
    void rebuildHashes();
    Hash stateHash() const;
    void put(Piece piece, Color side, Square square);
    void erase(Square square);
public:
#else
    uint8_t ply;
    uint8_t rule50_ply;
    uint8_t nullmove_ply;
#endif

    bool chess960;

    void startpos();
    void parseFen(std::string fen, bool isChess960) {
        std::istringstream iss(fen);
        parseFen(iss, isChess960);
    };
    void parseFen(std::istringstream& iss, bool isChess960);
    std::string fen();

#ifndef CAPABLANCA_CORE
    template<bool add, bool computeRays = true>
    __always_inline void updatePieceThreats(Piece piece, Color pieceColor, Square square, NNUE* nnue, Square ignore = NO_SQUARE);
#endif
    void updatePieceHash(Piece piece, Color pieceColor, uint64_t hashDelta);
    void updatePieceCastling(Piece piece, Color pieceColor, Square origin);

#ifndef CAPABLANCA_CORE
    void addPiece(Piece piece, Color pieceColor, Square square, NNUE* nnue);
    void removePiece(Piece piece, Color pieceColor, Square square, NNUE* nnue);
    void movePiece(Piece piece, Color pieceColor, Square origin, Square target, NNUE* nnue);
    void swapPiece(Piece piece, Color pieceColor, Square square, NNUE* nnue);
#endif

    void doMove(Move move, Hash newHash, NNUE* nnue);
    void doNullMove();

    void calculateThreats();
    bool isSquareThreatened(Square square);
#ifndef CAPABLANCA_CORE
    bool opponentHasGoodCapture();
#else
    bool opponentHasGoodCapture() {
        return bool(threats.allThreats & byColor[stm] & ~byPiece[KING]);
    }
#endif

    constexpr bool isCapture(Move move) {
        if (move.isCastling()) return false;
#ifdef CAPABLANCA_CORE
        // Upstream uses this as a tactical-move classifier, not only a capture flag.
        if (move.isEnpassant() || move.isPromotion() || move.isEmergency()) return true;
#else
        if (move.isEnpassant() || (move.isPromotion() && move.promotionPiece() == Piece::QUEEN)) return true;
#endif
        return pieces[move.target()] != Piece::NONE;
    }
    bool isPseudoLegal(Move move);
    bool isLegal(Move move);
    bool givesCheck(Move move);

    Square getCastlingRookSquare(Color side, Castling::CastlingDirection direction) {
        return castlingSquares[2 * side + direction];
    }

    std::pair<Hash, Hash> hashAfter(Move move);

    void updateSliderPins(Color side);

    constexpr bool hasNonPawns() {
        Bitboard nonPawns = byPiece[Piece::KNIGHT] | byPiece[Piece::BISHOP] | byPiece[Piece::ROOK] | byPiece[Piece::QUEEN];
#ifdef CAPABLANCA_CORE
        nonPawns |= byPiece[Piece::ARCHBISHOP] | byPiece[Piece::CHANCELLOR];
#endif
        return BB::popcount(byColor[stm] & nonPawns) > 0;
    }

    Bitboard attackersTo(Square square, Bitboard occupied);
    Bitboard attackersTo(Square square);

    void debugBoard();
    int validateBoard();
};

#ifndef CAPABLANCA_CORE
void debugBitboard(Bitboard bb);
#endif
