#pragma once

#include <cassert>
#include <cstdint>

// Isolated geometry and move representation for the PlentyChess port.
// This does not change or replace upstream move generation yet.
namespace CapablancaPort {

struct Geometry {
    int width;
    int height;
    constexpr int count() const { return width * height; }
    constexpr bool valid(int square) const { return square >= 0 && square < count(); }
    constexpr int file(int square) const { return square % width; }
    constexpr int rank(int square) const { return square / width; }
    constexpr int square(int fileIndex, int rankIndex) const {
        return rankIndex * width + fileIndex;
    }
};

constexpr Geometry Board10x8{10, 8};
constexpr Geometry Board10x10{10, 10};

// Two limbs avoid compiler-specific 128-bit arithmetic and cover both boards.
struct Squares {
    uint64_t low = 0;
    uint64_t high = 0;
    constexpr void add(int square) {
        assert(square >= 0 && square < 100);
        if (square < 64) low |= uint64_t{1} << square;
        else high |= uint64_t{1} << (square - 64);
    }
    constexpr bool contains(int square) const {
        assert(square >= 0 && square < 100);
        return square < 64 ? (low & (uint64_t{1} << square)) != 0
                           : (high & (uint64_t{1} << (square - 64))) != 0;
    }
    constexpr Squares operator|(Squares other) const {
        return {low | other.low, high | other.high};
    }
    constexpr Squares operator&(Squares other) const {
        return {low & other.low, high & other.high};
    }
};

enum class MoveKind : uint8_t { Normal, Promotion, EnPassant, Castling, Emergency };
enum class Promotion : uint8_t { Knight, Bishop, Rook, Queen, Archbishop, Chancellor };

// A 16-bit upstream move cannot hold square indices up to 99 plus move type.
// 7 + 7 + 3 + 3 = 20 bits; 32 bits leave room for future rule flags.
struct Move {
    uint32_t data = 0;
    static constexpr Move make(int from, int to, MoveKind kind = MoveKind::Normal,
                               Promotion promotion = Promotion::Knight) {
        assert(from >= 0 && from < 100 && to >= 0 && to < 100);
        return {uint32_t(from) | (uint32_t(to) << 7) |
                (uint32_t(kind) << 14) | (uint32_t(promotion) << 17)};
    }
    constexpr int from() const { return int(data & 0x7f); }
    constexpr int to() const { return int((data >> 7) & 0x7f); }
    constexpr MoveKind kind() const { return MoveKind((data >> 14) & 7); }
    constexpr Promotion promotion() const { return Promotion((data >> 17) & 7); }
};

} // namespace CapablancaPort
