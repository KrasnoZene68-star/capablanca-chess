#pragma once
#ifdef CAPABLANCA_CORE
#include "thread_capablanca.h"
#else

#include <thread>
#include <mutex>
#include <condition_variable>
#include <deque>
#include <functional>
#include <map>
#include <atomic>
#include <array>

#ifdef USE_NUMA
#include <sched.h>
#include <numa.h>
#endif

#include "board.h"
#include "search.h"
#include "history.h"
#include "nnue.h"
#include "tt.h"

inline bool shouldConfigureNuma(int numThreads) {
#ifdef USE_NUMA
    if (numa_available() == -1) {
        return false;
    }

    // Only bind when claiming the majority of the systems cores
    static int availableCores = std::thread::hardware_concurrency();
    if (numThreads <= availableCores / 2)
        return false;
    
    return true;
#else
    return false;
#endif
}

#ifdef USE_NUMA
inline auto getCoresPerNumaNode() {
    auto getCoresPerNode = []() {
        std::vector<std::pair<int, std::vector<int>>> coresPerNode;

        if (numa_available() == -1) {

            std::vector<int> cores;
            for (int i = 0; i < (int) std::thread::hardware_concurrency(); i++) {
                cores.push_back(i);
            }
            coresPerNode.push_back(std::make_pair(0, cores));

        } else {

            for (int node = 0; node < numa_num_configured_nodes(); ++node) {
                struct bitmask* coreMask = numa_allocate_cpumask();
                if (numa_node_to_cpus(node, coreMask) != 0) {
                    std::cerr << "info string Could not get core mask for NUMA node " << node << std::endl;
                    std::exit(1);
                }

                cpu_set_t cpuset;
                CPU_ZERO(&cpuset);

                std::vector<int> cores;
                for (int cpu = 0; cpu < (int) coreMask->size; ++cpu) {
                    if (numa_bitmask_isbitset(coreMask, cpu)) {
                        cores.push_back(cpu);
                    }
                }

                numa_free_cpumask(coreMask);
                if (cores.size()) {
                    coresPerNode.push_back(std::make_pair(node, cores));
                }
            }

        }

        std::cout << "info string NUMA Core to Node association:" << std::endl;
        unsigned int coreCount = 0;
        for (auto& [node, cores] : coresPerNode) {
            std::cout << "info string Node " << node << ": ";
            for (auto& core : cores) std::cout << core << ",";
            std::cout << std::endl;
            coreCount += cores.size();
        }
        if (coreCount != std::thread::hardware_concurrency()) {
            std::cerr << "info string Detected NUMA core count does not match hardware concurrency!" << std::endl;
            std::exit(1);
        }

        return coresPerNode;
    };

    static auto coresPerNode = getCoresPerNode();
    assert(coresPerNode.size() > 0);
    return coresPerNode;
}

inline int getNumaNodeCount() {
    return getCoresPerNumaNode().size();
}

#endif

inline int getNumaNode(int threadId, int numThreads) {
#ifdef USE_NUMA
    if (!shouldConfigureNuma(numThreads)) {
        return 0;
    }

    auto coresPerNode = getCoresPerNumaNode();
    int counter = 0;
    threadId %= std::thread::hardware_concurrency();

    for (auto& [node, cores] : coresPerNode) {
        if (threadId < counter + (int) cores.size())
            return node;
        counter += cores.size();
    }

    std::cerr << "info string This should never happen!" << std::endl;
    std::exit(1);
#else
    (void) threadId;
    return 0;
#endif
}

inline int getThreadsOnNode(int node, int numThreads) {
    int counter = 0;
    for (int idx = 0; idx < numThreads; idx++) {
        int threadNode = getNumaNode(idx, numThreads);
        if (node == threadNode)
            counter++;
    }
    return counter;
}

inline int getThreadIdxOnNode(int threadId, int numThreads) {
    int node = getNumaNode(threadId, numThreads);
    int counter = 0;
    for (int idx = 0; idx < threadId; idx++) {
        int threadNode = getNumaNode(idx, numThreads);
        if (node == threadNode)
            counter++;
    }
    return counter;
}

inline void configureThreadBinding(int threadId, int numThreads) {
#ifdef USE_NUMA
    if (!shouldConfigureNuma(numThreads))
        return;

    int numaNode = getNumaNode(threadId, numThreads);
    numa_run_on_node(numaNode);
    numa_set_preferred(numaNode);

#endif
    (void) threadId;
}

inline void configureThreadBinding(int numaNode) {
#ifdef USE_NUMA
    numa_run_on_node(numaNode);
    numa_set_preferred(numaNode);
#endif
    (void) numaNode;
}

struct RootMove {
    Eval value = -EVAL_INFINITE;
    Eval meanScore = EVAL_NONE;
    Depth depth = 0;
    int selDepth = 0;
    Move move = Move::none();
    std::vector<Move> pv;
};

class ThreadPool;

class alignas(64) Worker {

public:

    std::vector<Hash> boardHistory;

    Board rootBoard;
    
    std::mutex mutex;
    std::condition_variable cv;

    bool searching = false;
    std::atomic_bool stopped = false;
    bool exiting = false;

    SearchData searchData;
    SearchParameters searchParameters;
    History history;
    NNUE nnue;
    NNUE* evaluator() { return &nnue; }

    ThreadPool* threadPool;

    int threadId;
    bool mainThread;

    std::vector<RootMove> rootMoves;
    std::map<Move, uint64_t> rootMoveNodes;
    std::vector<Move> excludedRootMoves;
    std::vector<std::array<MoveGen, 2>> movepickers;

    std::array<int, 2> optimism;

    Worker() = delete;
    Worker(ThreadPool* threadPool, NetworkData* networkData, SharedHistory* sharedHistory, int threadId, int threadIdOnNode);

    void startSearching();
    void waitForSearchFinished();
    void idle();
    void exit();

    void ucinewgame();

    void tdatagen();

private:

    void tgenfens();

    void tsearch();
    void iterativeDeepening();
    void sortRootMoves();
    void printUCI(Worker* thread, int multiPvCount = 1);
    Worker* chooseBestThread();

    Board* doMove(Board* board, Hash newHash, Move move);
    void undoMove();
    Board* doNullMove(Board* board);
    void undoNullMove();
    bool hasUpcomingRepetition(Board* board, int ply);
    bool isDraw(Board* board, int ply);

    template <NodeType nt>
    Eval search(Board* board, SearchStack* stack, Depth depth, Eval alpha, Eval beta, bool cutNode);

    template <NodeType nodeType>
    Eval qsearch(Board* board, SearchStack* stack, Eval alpha, Eval beta);

};

static_assert(sizeof(Worker) % 64 == 0, "sizeof(Worker) must be a multiple of 64");

class ThreadPool {

public:

    std::vector<std::unique_ptr<Worker>> workers;
    std::vector<std::unique_ptr<std::thread>> threads;

    SearchParameters searchParameters;
    Board rootBoard;
    std::vector<Hash> rootBoardHistory;

    std::atomic<size_t> startedThreads;

    std::vector<NetworkData*> networkWeights;
    std::vector<SharedHistory*> sharedHistories;

    ThreadPool() : workers(0), threads(0), searchParameters{}, rootBoardHistory() {
        resize(0);
    }

    ~ThreadPool() {
        exit();
    }

    void resize(int numThreads) {
        if ((int) threads.size() == numThreads)
            return;
        
        exit();

        // Free previous allocations
#ifdef USE_NUMA
        if (shouldConfigureNuma(threads.size())) {

            for (size_t i = 0; i < networkWeights.size(); i++) {
                if (networkWeights[i] != globalNetworkData) {
                    numa_free(networkWeights[i], sizeof(NetworkData));
                }
            }
            networkWeights.clear();

            for (size_t i = 0; i < sharedHistories.size(); i++) {
                sharedHistories[i]->free();
                numa_free(sharedHistories[i], sizeof(SharedHistory));
            }
            sharedHistories.clear();

        }
#endif
        for (size_t i = 0; i < sharedHistories.size(); i++) {
            sharedHistories[i]->free();
            alignedFree(sharedHistories[i]);
        }
        sharedHistories.clear();

        // Allocate new objects
#ifdef USE_NUMA
        if (shouldConfigureNuma(numThreads)) {

            auto coresPerNode = getCoresPerNumaNode();

            networkWeights.resize(coresPerNode.size());
            for (size_t i = 0; i < networkWeights.size(); i++) {
                int nodeIdx = coresPerNode[i].first;
                NetworkData* weights = reinterpret_cast<NetworkData*>(numa_alloc_onnode(sizeof(NetworkData), nodeIdx));
                if (!weights) {
                    std::cerr << "info string Could not allocate a NetworkData object on NUMA node " << nodeIdx << std::endl;
                    std::exit(1);
                }
                std::cout << "info string Allocated a NetworkData object on NUMA node " << nodeIdx << std::endl;
                madvise(weights, sizeof(NetworkData), MADV_HUGEPAGE);
                std::memcpy(weights, globalNetworkData, sizeof(NetworkData));
                networkWeights[i] = weights;
            }

            sharedHistories.resize(coresPerNode.size());
            for (size_t i = 0; i < sharedHistories.size(); i++) {
                int nodeIdx = coresPerNode[i].first;
                SharedHistory* history = reinterpret_cast<SharedHistory*>(numa_alloc_onnode(sizeof(SharedHistory), nodeIdx));
                if (!history) {
                    std::cerr << "info string Could not allocate a SharedHistory object on NUMA node " << nodeIdx << std::endl;
                    std::exit(1);
                }
                std::cout << "info string Allocated a SharedHistory object on NUMA node " << nodeIdx << std::endl;
                madvise(history, sizeof(SharedHistory), MADV_HUGEPAGE);
                std::thread tempThread([nodeIdx, history, numThreads]() {
                    configureThreadBinding(nodeIdx);
                    *history = SharedHistory(getThreadsOnNode(nodeIdx, numThreads));
                });
                tempThread.join();
                sharedHistories[i] = history;
            }
        }
#endif

        // Standard allocation when NUMA is not used
        if (networkWeights.empty()) {
            networkWeights.resize(1);
            networkWeights[0] = globalNetworkData;
        }

        if (sharedHistories.empty()) {
            sharedHistories.resize(1);
            SharedHistory* history = reinterpret_cast<SharedHistory*>(alignedAlloc(64, sizeof(SharedHistory)));
            *history = SharedHistory(numThreads);
            sharedHistories[0] = history;
        }

        threads.clear();
        workers.clear();
        workers.resize(numThreads);

        startedThreads = 0;

        for (int i = 0; i < numThreads; i++) {
            threads.push_back(std::make_unique<std::thread>([this, numThreads, i]() {
                configureThreadBinding(i, numThreads);
                int nodeIdx = getNumaNode(i, numThreads);
                int threadIdxOnNode = getThreadIdxOnNode(i, numThreads);
                workers[i] = std::make_unique<Worker>(this, networkWeights[nodeIdx], sharedHistories[nodeIdx], i, threadIdxOnNode);
                workers[i]->idle();
            }));
        }

        while (startedThreads < (size_t) numThreads) {}
    }

    void startSearching(Board board, std::vector<Hash> boardHistory, SearchParameters parameters) {
        stopSearching();
        waitForSearchFinished();

        rootBoard = std::move(board);
        rootBoardHistory = std::move(boardHistory);
        searchParameters = std::move(parameters);

        for (auto& worker : workers) {
            worker.get()->rootMoves.clear();
            worker.get()->stopped.store(false, std::memory_order_relaxed);
            std::lock_guard<std::mutex> lock(worker.get()->mutex);
            worker.get()->searching = true;
        }

        for (auto& worker : workers) {
            worker.get()->cv.notify_all();
        }
    }

    void stopSearching() {
        for (auto& worker : workers) {
            worker.get()->stopped.store(true, std::memory_order_relaxed);
        }
    }

    void waitForSearchFinished() {
        for (auto& worker : workers) {
            worker.get()->waitForSearchFinished();
        }
    }

    void waitForHelpersFinished() {
        for (std::size_t i = 1; i < workers.size(); i++) {
            workers[i].get()->waitForSearchFinished();
        }
    }

    void exit() {
        for (auto& worker : workers) {
            worker.get()->exit();
        }
    }

    void ucinewgame() {
        TT.clear();
        for (auto& worker : workers) {
            worker.get()->ucinewgame();
        }
    }

    uint64_t nodesSearched() {
        uint64_t sum = 0;
        for (auto& worker : workers) {
            sum += worker.get()->searchData.nodesSearched.load(std::memory_order_relaxed);
        }
        return sum;
    }

    uint64_t tbhits() {
        uint64_t sum = 0;
        for (auto& worker : workers) {
            sum += worker.get()->searchData.tbHits;
        }
        return sum;
    }

};
#endif // CAPABLANCA_CORE
