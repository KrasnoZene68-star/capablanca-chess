#pragma once

#include <array>
#include "types.h"
#include "board.h"
#ifndef CAPABLANCA_CORE
#include "search.h"
#include "nnue.h"
#endif

const Eval EVAL_MATE = 30000;
const Eval EVAL_MATE_IN_MAX_PLY = EVAL_MATE - MAX_PLY;

const Eval EVAL_TBWIN = EVAL_MATE_IN_MAX_PLY - 1000;
const Eval EVAL_TBWIN_IN_MAX_PLY = EVAL_TBWIN - MAX_PLY;

const Eval EVAL_INFINITE = 31000;
const Eval EVAL_NONE = 31010;

extern int PIECE_VALUES[Piece::TOTAL + 1];

Eval evaluate(Board* board, NNUE* nnue, std::array<int, 2>& optimism);

std::string formatEval(Eval value);

bool SEE(Board* board, Move move, int threshold);
#ifdef CAPABLANCA_CORE
// White-minus-black feature totals before side-to-move tempo. Heuristic, not NNUE.
struct CoreEvalBreakdown {
    int material=0, activityMG=0, activityEG=0, pawnsMG=0, pawnsEG=0;
    int kingMG=0, kingEG=0, phase=0, total=0;
};
CoreEvalBreakdown evaluateCorePosition(const Board& board);
// Deterministic least-valuable-legal-attacker exchange estimate, in centipawns.
int staticExchangeValue(Board* board, Move move);
#endif

constexpr Eval mateIn(int ply) {
    return EVAL_MATE - ply;
}

constexpr Eval matedIn(int ply) {
    return -EVAL_MATE + ply;
}
