#include "thread.h"
#include "tt.h"
#include "time.h"
#include <algorithm>
#include <mutex>
#include <stdexcept>

void ThreadPool::stopSearching() { worker->requestStop(); }
Worker::Worker() {
    static std::once_flag initialized;
    std::call_once(initialized,initReductions);
    history.initHistory();
}
Hash Worker::transpositionKey(Board* board) const {
    // A repetition score depends on the reversible path, not only the board.
    Hash path=0xcbf29ce484222325ULL;
    size_t back=std::min<size_t>(boardHistory.size(),size_t(board->rule50_ply)+1);
    for(size_t i=boardHistory.size()-back;i<boardHistory.size();++i) {
        path^=boardHistory[i]; path*=0x100000001b3ULL;
    }
    return board->rule50Hash() ^ path;
}
CoreSearchResult Worker::run(const Board& root, SearchParameters limits, const std::vector<Hash>& past) {
    // Global TT/options still belong to the upstream architecture. No concurrent runs.
    static std::mutex active;
    std::unique_lock<std::mutex> lock(active,std::try_to_lock);
    if (!lock.owns_lock()) throw std::logic_error("native core permits one active search");
    if (limits.depth < 0 || limits.depth >= MAX_PLY || limits.ponder || limits.genfens || limits.perft || !limits.searchmoves.empty())
        throw std::invalid_argument("unsupported native search parameters");
    constexpr uint64_t maxClock=86400000;
    if(limits.movetime>maxClock || limits.wtime>maxClock || limits.btime>maxClock ||
       limits.winc>maxClock || limits.binc>maxClock || limits.movestogo<0)
        throw std::invalid_argument("native clock range is 0..24 hours");
    if(!limits.depth && !limits.nodes && !limits.movetime && !(limits.wtime && limits.btime))
        limits.movetime=1000; // bounded default for a native/browser request
    if (UCI::Options.threads.value != 1 || UCI::Options.multiPV.value != 1 || UCI::Options.datagen.value)
        throw std::invalid_argument("native core requires single-thread/single-PV mode");
    rootBoard=root;
    if (rootBoard.validateBoard()) throw std::invalid_argument("invalid search root");
    searchParameters=limits;
    stopped.store(false,std::memory_order_relaxed); exiting=false;
    rootMoves.clear(); excludedRootMoves.clear(); rootMoveNodes.clear();
    boardHistory=past; boardHistory.push_back(root.hashes.hash);
    rootBoard.nullmove_ply=uint16_t(std::min<size_t>(65535,past.size()));
    searchData.nodesSearched=0; searchData.tbHits=0; searchData.nmpPlies=0;
    searchData.rootDepth=0; searchData.selDepth=0;
    completedResult={};
    // Never retain draw/path-dependent bounds between independent requests.
    TT.clear(); TT.newSearch(); history.initHistory();
    initTimeManagement(rootBoard,searchParameters,searchData);
    const auto moves=rootBoard.legalMoves();
    if (moves.empty()) {
        completedResult.score=rootBoard.checkers ? matedIn(0) : 0;
        completedResult.completed=true; completedResult.terminal=true;
        return completedResult;
    }
    if (isDraw(&rootBoard,0)) {
        completedResult.completed=true; completedResult.terminal=true;
        return completedResult;
    }
    completedResult.move=moves.front(); // legal fallback if no iteration completes
    iterativeDeepening();
    assert(boardHistory.size()==past.size()+1 && boardHistory.back()==root.hashes.hash);
    completedResult.nodes=searchData.nodesSearched.load(std::memory_order_relaxed);
    return completedResult;
}
