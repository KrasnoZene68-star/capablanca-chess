#pragma once

#include <atomic>

#include "types.h"
#include "board.h"

struct SearchedMove {
    Move move;
    int8_t searchCount;
};

using SearchedMoveList = ArrayVec<SearchedMove, 32>;

#ifdef CAPABLANCA_CORE
constexpr int PAWN_HISTORY_SIZE = 1024;
constexpr int CONTINUATION_CONTEXTS = 1024;
#else
constexpr int PAWN_HISTORY_SIZE = 8192;
#endif
constexpr int CONTINUATION_STRIDE = Piece::TOTAL * BOARD_CAPACITY * 2;
constexpr int CORRECTION_HISTORY_SIZE = 16384;
constexpr int CORRECTION_HISTORY_LIMIT = 1024;

class alignas(64) SharedHistory {

    std::atomic<int16_t>* correctionHistory[2]{};
    std::atomic<int16_t>* nonPawnCorrectionHistory[2][2]{};
    std::atomic<int16_t>* minorCorrectionHistory[2]{};
    std::atomic<int16_t>* majorCorrectionHistory[2]{};

    int threadsOnNode;
    int threadsPowerOfTwo;
    int hashMask;

public:

    SharedHistory() = delete;
    SharedHistory(int _threadsOnNode);
#ifdef CAPABLANCA_CORE
    // The current native port is intentionally single-threaded.
    ~SharedHistory() { free(); }
    SharedHistory(const SharedHistory&) = delete;
    SharedHistory& operator=(const SharedHistory&) = delete;
    static constexpr size_t allocatedBytes() {
        return 10 * CORRECTION_HISTORY_SIZE * sizeof(std::atomic<int16_t>);
    }
#endif

    int16_t getPawnCorrectionEntry(Board* board);
    void storePawnCorrectionEntry(Board* board, int16_t value);

    int16_t getNonPawnCorrectionEntryWhite(Board* board);
    int16_t getNonPawnCorrectionEntryBlack(Board* board);
    void storeNonPawnCorrectionEntryWhite(Board* board, int16_t value);
    void storeNonPawnCorrectionEntryBlack(Board* board, int16_t value);

    int16_t getMinorCorrectionEntry(Board* board);
    void storeMinorCorrectionEntry(Board* board, int16_t value);
    int16_t getMajorCorrectionEntry(Board* board);
    void storeMajorCorrectionEntry(Board* board, int16_t value);

    void initHistory(int threadIdx);
    void free();

};

static_assert(sizeof(SharedHistory) % 64 == 0, "sizeof(SharedHistory) must be a multiple of 64");

class History {

    Move counterMoves[BOARD_CAPACITY][BOARD_CAPACITY];
    int16_t captureHistory[2][Piece::TOTAL][BOARD_CAPACITY][Piece::TOTAL];
    int16_t pawnHistory[PAWN_HISTORY_SIZE][2][Piece::TOTAL][BOARD_CAPACITY];

    int threadIdx;
    SharedHistory* sharedHistory;

public:

    int16_t quietHistory[2][BOARD_CAPACITY][2][BOARD_CAPACITY][2];

#ifdef CAPABLANCA_CORE
    int16_t continuationHistory[CONTINUATION_CONTEXTS][CONTINUATION_STRIDE];
#else
    int16_t continuationHistory[2][2][2][Piece::TOTAL][BOARD_CAPACITY][CONTINUATION_STRIDE];
#endif
    int16_t continuationCorrectionHistory[2][Piece::TOTAL][BOARD_CAPACITY][2][2];

    int16_t* continuationEntry(bool inCheck, bool capture, Color side, Piece piece, Square target) {
        assert(piece < Piece::TOTAL && target < BOARD_CAPACITY);
#ifdef CAPABLANCA_CORE
        // Hash only the past context. The future piece/square/side stays exact.
        uint32_t context = (((int(inCheck) * 2 + capture) * 2 + side) * Piece::TOTAL + piece) * BOARD_CAPACITY + target;
        context *= 0x9e3779b9u;
        return continuationHistory[context >> 22]; // high ten bits => 1024 rows
#else
        return continuationHistory[inCheck][capture][side][piece][target];
#endif
    }

    History() = delete;
    History(int _threadIdx, SharedHistory* _sharedHistory): threadIdx(_threadIdx), sharedHistory(_sharedHistory) {}

    void initHistory();

    int getCorrectionValue(Board* board, SearchStack* searchStack);
    Eval correctStaticEval(uint16_t rule50, Eval eval, int correctionValue);
    void updateCorrectionHistory(Board* board, SearchStack* searchStack, int16_t bonus);

    int getHistory(Board* board, SearchStack* searchStack, Move move, bool isCapture);

    int16_t getPawnHistory(Board* board, Move move);
    void updatePawnHistory(Board* board, Move move, int16_t bonus);

    int16_t getQuietHistory(Move move, Color stm, Board* board);
    void updateQuietHistory(Move move, Color stm, Board* board, int16_t bonus);

    int getContinuationHistory(SearchStack* stack, Color side, Piece piece, Move move);
    void updateContinuationHistory(SearchStack* stack, Color side, Piece piece, Move move, int16_t bonus);

    int16_t* getCaptureHistory(Board* board, Move move);
    void updateSingleCaptureHistory(Board* board, Move move, int16_t bonus);
    void updateCaptureHistory(Depth depth, Board* board, Move move, int moveSearchCount, SearchedMoveList& searchedCaptures);

    void updateQuietHistories(Depth depth, Board* board, SearchStack* stack, Move move, int moveSearchCount, SearchedMoveList& searchedQuiets);

    Move getCounterMove(Move move);
    void setCounterMove(Move move, Move counter);

};
#ifdef CAPABLANCA_CORE
static_assert(sizeof(History) + SharedHistory::allocatedBytes() < 7 * 1024 * 1024,
              "History must stay below the native-port mobile budget");
#endif
