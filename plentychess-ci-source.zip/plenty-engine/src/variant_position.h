#pragma once

#include "variant_attacks.h"
#include <algorithm>
#include <array>
#include <cctype>
#include <stdexcept>
#include <string>
#include <vector>
#include <sstream>

// Isolated correctness reference for regular moves. Special moves (castling,
// en passant, extended 10x10 pawn starts, emergency escape) will be added only
// after this reference agrees with the existing game.
namespace VariantPosition {

using CapablancaPort::Geometry;

struct Move {
    uint8_t from;
    uint8_t to;
    char promotion = 0;
    enum class Special : uint8_t { None, Double, Triple, EnPassant, CastleLeft, CastleRight, Escape } special = Special::None;
};

inline bool isRed(char p) { return p >= 'A' && p <= 'Z'; }
inline bool isGreen(char p) { return p >= 'a' && p <= 'z'; }
inline bool belongs(char p, bool red) { return red ? isRed(p) : isGreen(p); }

struct Position {
    Geometry geometry;
    std::array<char, 100> cells{};
    bool redToMove = true;
    bool kingKnight = false;
    bool emergencyEscape = false;
    // 0/1: red queen/king side; 2/3: green queen/king side.
    std::array<bool, 4> castle{};
    std::array<uint8_t, 2> tripleRemaining{2, 2};
    std::vector<uint8_t> enPassantTargets;
    uint8_t enPassantCaptured = 100;
    uint16_t halfmoveClock = 0;

    explicit Position(Geometry g) : geometry(g) { cells.fill('.'); }

    static Position fromFen(Geometry g, const std::string& fen, bool kingKnight = false,
                            bool emergencyEscape = false) {
        Position pos(g);
        pos.kingKnight = kingKnight;
        pos.emergencyEscape = emergencyEscape;
        int rank = g.height - 1, file = 0;
        size_t i = 0;
        for (; i < fen.size() && fen[i] != ' '; ++i) {
            const char c = fen[i];
            if (c == '/') {
                if (file != g.width || rank == 0) throw std::invalid_argument("bad FEN rank");
                --rank; file = 0;
            } else if (std::isdigit(static_cast<unsigned char>(c))) {
                int empty = 0;
                do { empty = 10 * empty + (fen[i] - '0'); ++i; }
                while (i < fen.size() && std::isdigit(static_cast<unsigned char>(fen[i])));
                --i;
                file += empty;
            } else if (std::string("PNBRQKACpnbrqkac").find(c) != std::string::npos) {
                if (file >= g.width || rank < 0) throw std::invalid_argument("FEN overflow");
                pos.cells[g.square(file++, rank)] = c;
            } else throw std::invalid_argument("unknown FEN piece");
            if (file > g.width) throw std::invalid_argument("FEN overflow");
        }
        if (rank != 0 || file != g.width || i + 2 >= fen.size() || fen[i] != ' ' ||
            (fen[i + 1] != 'w' && fen[i + 1] != 'b'))
            throw std::invalid_argument("bad FEN side or size");
        pos.redToMove = fen[i + 1] == 'w';
        std::istringstream remaining(fen.substr(i + 2));
        std::string castling, ep;
        remaining >> castling >> ep;
        for (char c : castling) {
            if (c == 'Q') pos.castle[0] = true;
            if (c == 'K') pos.castle[1] = true;
            if (c == 'q') pos.castle[2] = true;
            if (c == 'k') pos.castle[3] = true;
        }
        if (ep != "-" && !ep.empty()) {
            if (ep.size() % 2) throw std::invalid_argument("invalid en passant FEN");
            for (size_t p = 0; p < ep.size(); p += 2) {
                const int f = ep[p] - 'a', r = ep[p + 1] - '1';
                if (!VariantAttacks::inBounds(g, f, r)) throw std::invalid_argument("invalid en passant square");
                pos.enPassantTargets.push_back(uint8_t(g.square(f, r)));
            }
            // Captured pawn lies one rank behind the arrival square of the taking pawn.
            int nearest = pos.enPassantTargets.front();
            for (uint8_t target : pos.enPassantTargets)
                if (pos.redToMove ? target < nearest : target > nearest) nearest = target;
            pos.enPassantCaptured = uint8_t(nearest + (pos.redToMove ? -g.width : g.width));
        }
        std::string halfmove, fullmove, budget;
        remaining >> halfmove >> fullmove >> budget;
        if (!halfmove.empty()) {
            const int parsed = std::stoi(halfmove);
            if (parsed < 0 || parsed > 65535) throw std::invalid_argument("invalid halfmove clock");
            pos.halfmoveClock = uint16_t(parsed);
        }
        if (budget.size() == 4 && budget[0] == 't' && budget[2] == ',') {
            pos.tripleRemaining = {uint8_t(budget[1] - '0'), uint8_t(budget[3] - '0')};
        }
        return pos;
    }

    Bitboard occupied() const {
        Bitboard out = 0;
        for (int s = 0; s < geometry.count(); ++s)
            if (cells[s] != '.') out |= bitboard(Square(s));
        return out;
    }

    Bitboard attacks(int from, Bitboard occ) const {
        const char p = cells[from];
        const char t = static_cast<char>(std::tolower(static_cast<unsigned char>(p)));
        using namespace VariantAttacks;
        switch (t) {
        case 'p': return pawn(geometry, from, isRed(p));
        case 'n': return knight(geometry, from);
        case 'b': return bishop(geometry, from, occ);
        case 'r': return rook(geometry, from, occ);
        case 'q': return queen(geometry, from, occ);
        case 'a': return archbishop(geometry, from, occ);
        case 'c': return chancellor(geometry, from, occ);
        case 'k': return king(geometry, from, kingKnight);
        default: return 0;
        }
    }

    bool attacked(int target, bool byRed) const {
        const Bitboard occ = occupied(), targetBit = bitboard(Square(target));
        for (int s = 0; s < geometry.count(); ++s)
            if (belongs(cells[s], byRed) && (attacks(s, occ) & targetBit)) return true;
        return false;
    }

    bool inCheck(bool red) const {
        const char king = red ? 'K' : 'k';
        for (int s = 0; s < geometry.count(); ++s)
            if (cells[s] == king) return attacked(s, !red);
        throw std::invalid_argument("missing king");
    }

    Position after(Move move) const {
        Position next = *this;
        const char moving = cells[move.from];
        next.halfmoveClock = std::tolower(static_cast<unsigned char>(moving)) == 'p' ||
            cells[move.to] != '.' ||
            move.special == Move::Special::EnPassant ? 0 : uint16_t(std::min(65535, int(halfmoveClock) + 1));
        const int home = redToMove ? 0 : geometry.height - 1;
        const int sideIndex = redToMove ? 0 : 2;
        if (std::tolower(static_cast<unsigned char>(moving)) == 'k') {
            next.castle[sideIndex] = next.castle[sideIndex + 1] = false;
        }
        if (move.from == geometry.square(0, home)) next.castle[sideIndex] = false;
        if (move.from == geometry.square(9, home)) next.castle[sideIndex + 1] = false;
        const int enemyHome = redToMove ? geometry.height - 1 : 0;
        const int enemyIndex = redToMove ? 2 : 0;
        if (move.to == geometry.square(0, enemyHome)) next.castle[enemyIndex] = false;
        if (move.to == geometry.square(9, enemyHome)) next.castle[enemyIndex + 1] = false;
        next.enPassantTargets.clear();
        next.enPassantCaptured = 100;
        if (move.special == Move::Special::EnPassant) {
            if (enPassantCaptured >= geometry.count()) throw std::invalid_argument("invalid ep capture");
            next.cells[enPassantCaptured] = '.';
        }
        if (move.special == Move::Special::CastleLeft || move.special == Move::Special::CastleRight) {
            const int rookFrom = geometry.square(move.special == Move::Special::CastleLeft ? 0 : 9, home);
            const int rookTo = geometry.square(move.special == Move::Special::CastleLeft ? 3 : 7, home);
            next.cells[rookTo] = next.cells[rookFrom];
            next.cells[rookFrom] = '.';
        }
        if (move.special == Move::Special::Triple) {
            auto& budget = next.tripleRemaining[redToMove ? 0 : 1];
            if (!budget) throw std::invalid_argument("no triple moves left");
            --budget;
        }
        if (move.special == Move::Special::Double || move.special == Move::Special::Triple) {
            const int step = redToMove ? geometry.width : -geometry.width;
            next.enPassantTargets.push_back(uint8_t(move.from + step));
            if (move.special == Move::Special::Triple)
                next.enPassantTargets.push_back(uint8_t(move.from + 2 * step));
            next.enPassantCaptured = move.to;
        }
        next.cells[move.to] = move.promotion ? move.promotion : next.cells[move.from];
        next.cells[move.from] = '.';
        next.redToMove = !redToMove;
        return next;
    }

    std::vector<Move> regularLegalMoves() const {
        std::vector<Move> result;
        const Bitboard occ = occupied();
        const bool red = redToMove;
        auto addIfLegal = [&](int from, int to, char promotion = 0,
                              Move::Special special = Move::Special::None) {
            Move move{uint8_t(from), uint8_t(to), promotion, special};
            if (!inCheckAfter(move, red))
                result.push_back(move);
        };
        for (int from = 0; from < geometry.count(); ++from) {
            const char piece = cells[from];
            if (!belongs(piece, red)) continue;
            const char type = static_cast<char>(std::tolower(static_cast<unsigned char>(piece)));
            if (type == 'p') {
                const int forward = red ? 1 : -1;
                const int rank = geometry.rank(from), nextRank = rank + forward;
                if (nextRank < 0 || nextRank >= geometry.height) continue;
                const int forwardSquare = geometry.square(geometry.file(from), nextRank);
                auto addPawnMove = [&](int to) {
                    if (nextRank == (red ? geometry.height - 1 : 0)) {
                        for (const char p : std::string(red ? "NBRQAC" : "nbrqac"))
                            addIfLegal(from, to, p);
                    } else addIfLegal(from, to);
                };
                if (cells[forwardSquare] == '.') {
                    addPawnMove(forwardSquare);
                    const int home = red ? 1 : geometry.height - 2;
                    if (rank == home) {
                        const int twice = geometry.square(geometry.file(from), rank + 2 * forward);
                        if (cells[twice] == '.') {
                            addIfLegal(from, twice, 0, Move::Special::Double);
                            if (geometry.height == 10 && tripleRemaining[red ? 0 : 1]) {
                                const int thrice = geometry.square(geometry.file(from), rank + 3 * forward);
                                if (cells[thrice] == '.') addIfLegal(from, thrice, 0, Move::Special::Triple);
                            }
                        }
                    }
                }
                Bitboard captures = attacks(from, occ);
                while (captures) {
                    const int to = popLSB(&captures);
                    if (belongs(cells[to], !red) && std::tolower(cells[to]) != 'k')
                        addPawnMove(to);
                    if (cells[to] == '.' && enPassantCaptured < geometry.count() &&
                        belongs(cells[enPassantCaptured], !red) &&
                        std::tolower(cells[enPassantCaptured]) == 'p') {
                        for (uint8_t ep : enPassantTargets)
                            if (ep == to) addIfLegal(from, to, 0, Move::Special::EnPassant);
                    }
                }
                continue;
            }
            Bitboard destinations = attacks(from, occ);
            while (destinations) {
                const int to = popLSB(&destinations);
                if (belongs(cells[to], red) || std::tolower(cells[to]) == 'k') continue;
                addIfLegal(from, to);
            }
            if (type == 'k' && !inCheck(red)) {
                const int home = red ? 0 : geometry.height - 1;
                if (from == geometry.square(5, home)) {
                    const int offset = red ? 0 : 2;
                    const char rookPiece = red ? 'R' : 'r';
                    if (castle[offset] && cells[geometry.square(0, home)] == rookPiece) {
                        bool clear = true;
                        for (int f = 1; f <= 4; ++f) clear &= cells[geometry.square(f, home)] == '.';
                        for (int f = 2; f <= 4; ++f) clear &= !attacked(geometry.square(f, home), !red);
                        if (clear) addIfLegal(from, geometry.square(2, home), 0, Move::Special::CastleLeft);
                    }
                    if (castle[offset + 1] && cells[geometry.square(9, home)] == rookPiece) {
                        bool clear = true;
                        for (int f = 6; f <= 8; ++f) clear &= cells[geometry.square(f, home)] == '.';
                        for (int f = 6; f <= 8; ++f) clear &= !attacked(geometry.square(f, home), !red);
                        if (clear) addIfLegal(from, geometry.square(8, home), 0, Move::Special::CastleRight);
                    }
                }
            }
        }
        return result;
    }

    std::vector<Move> legalMoves() const {
        auto normal = regularLegalMoves();
        if (!normal.empty() || !emergencyEscape || !inCheck(redToMove)) return normal;
        int from = -1;
        for (int s = 0; s < geometry.count(); ++s)
            if (cells[s] == (redToMove ? 'K' : 'k')) { from = s; break; }
        if (from < 0) return normal;
        Bitboard neighbors = VariantAttacks::king(geometry, from, false);
        while (neighbors) {
            const int to = popLSB(&neighbors);
            if (!belongs(cells[to], redToMove) || std::tolower(cells[to]) == 'k') continue;
            if (attacked(to, !redToMove)) continue;
            Move escape{uint8_t(from), uint8_t(to), 0, Move::Special::Escape};
            if (!inCheckAfter(escape, redToMove)) normal.push_back(escape);
        }
        return normal;
    }

private:
    bool inCheckAfter(Move move, bool red) const { return after(move).inCheck(red); }
};

} // namespace VariantPosition
