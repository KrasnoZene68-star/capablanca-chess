#pragma once

#include "types.h"
#include "capablanca_geometry.h"

// Geometry-only attack generator. Occupancy blocks rays; the blocker square is
// included, so the caller must mask its own pieces when generating destinations.
// This component replaces 8x8 magic tables for variant boards, but is not yet
// wired into Board::generateMoves.
namespace VariantAttacks {

using CapablancaPort::Geometry;

constexpr bool inBounds(const Geometry& g, int f, int r) {
    return f >= 0 && f < g.width && r >= 0 && r < g.height;
}

inline Bitboard leaps(const Geometry& g, int from, const int (&deltas)[8][2],
                      int count) {
    Bitboard attacks = 0;
    const int f = g.file(from), r = g.rank(from);
    for (int i = 0; i < count; ++i) {
        const int nf = f + deltas[i][0], nr = r + deltas[i][1];
        if (inBounds(g, nf, nr)) attacks |= bitboard(Square(g.square(nf, nr)));
    }
    return attacks;
}

inline Bitboard knight(const Geometry& g, int from) {
    static constexpr int offsets[8][2] = {
        {1, 2}, {2, 1}, {-1, 2}, {-2, 1},
        {1, -2}, {2, -1}, {-1, -2}, {-2, -1}
    };
    return leaps(g, from, offsets, 8);
}

inline Bitboard king(const Geometry& g, int from, bool knightMove = false) {
    static constexpr int offsets[8][2] = {
        {1, 0}, {-1, 0}, {0, 1}, {0, -1},
        {1, 1}, {-1, 1}, {1, -1}, {-1, -1}
    };
    Bitboard attacks = leaps(g, from, offsets, 8);
    if (knightMove) attacks |= knight(g, from);
    return attacks;
}

inline Bitboard rays(const Geometry& g, int from, Bitboard occupied,
                     const int (&dirs)[4][2]) {
    Bitboard attacks = 0;
    const int f = g.file(from), r = g.rank(from);
    for (const auto& d : dirs) {
        int nf = f + d[0], nr = r + d[1];
        while (inBounds(g, nf, nr)) {
            const Bitboard target = bitboard(Square(g.square(nf, nr)));
            attacks |= target;
            if (occupied & target) break;
            nf += d[0]; nr += d[1];
        }
    }
    return attacks;
}

inline Bitboard rook(const Geometry& g, int from, Bitboard occupied) {
    static constexpr int dirs[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    return rays(g, from, occupied, dirs);
}

inline Bitboard bishop(const Geometry& g, int from, Bitboard occupied) {
    static constexpr int dirs[4][2] = {{1, 1}, {-1, 1}, {1, -1}, {-1, -1}};
    return rays(g, from, occupied, dirs);
}

inline Bitboard queen(const Geometry& g, int from, Bitboard occupied) {
    return rook(g, from, occupied) | bishop(g, from, occupied);
}

inline Bitboard chancellor(const Geometry& g, int from, Bitboard occupied) {
    return rook(g, from, occupied) | knight(g, from);
}

inline Bitboard archbishop(const Geometry& g, int from, Bitboard occupied) {
    return bishop(g, from, occupied) | knight(g, from);
}

inline Bitboard pawn(const Geometry& g, int from, bool redMovesUp) {
    Bitboard attacks = 0;
    const int f = g.file(from), r = g.rank(from) + (redMovesUp ? 1 : -1);
    for (const int df : {-1, 1}) {
        if (inBounds(g, f + df, r)) attacks |= bitboard(Square(g.square(f + df, r)));
    }
    return attacks;
}

} // namespace VariantAttacks
