#pragma once

#include "variant_position.h"
#include <cstdint>

// Whole-position hash for initial correctness work. Search can later switch to
// an incremental Zobrist update after this encoding is independently tested.
namespace VariantHash {

inline uint64_t position(const VariantPosition::Position& p) {
    uint64_t hash = 14695981039346656037ULL;
    auto mix = [&](uint8_t byte) { hash ^= byte; hash *= 1099511628211ULL; };
    mix(uint8_t(p.geometry.width));
    mix(uint8_t(p.geometry.height));
    mix(uint8_t(p.redToMove));
    mix(uint8_t(p.kingKnight));
    mix(uint8_t(p.emergencyEscape));
    for (int s = 0; s < p.geometry.count(); ++s)
        mix(uint8_t(p.cells[s]));
    for (bool right : p.castle) mix(uint8_t(right));
    if (p.geometry.height == 10) {
        mix(p.tripleRemaining[0]);
        mix(p.tripleRemaining[1]);
    }
    // An en-passant field changes repetition rights only when a legal capture
    // is possible. This matches the existing game's normalized position key.
    if (!p.enPassantTargets.empty()) {
        for (const auto m : p.legalMoves())
            if (m.special == VariantPosition::Move::Special::EnPassant)
                mix(uint8_t(m.to + 1));
    }
    return hash;
}

} // namespace VariantHash
