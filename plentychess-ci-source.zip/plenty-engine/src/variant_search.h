#pragma once

#include "variant_hash.h"
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <unordered_map>
#include <vector>

// Experimental adaptation layer for PlentyChess's search architecture:
// iterative deepening, alpha-beta/PVS, quiescence and a transposition table.
// The original NNUE and tuned pruning depend on 8x8 and are not used here.
namespace VariantSearch {

using VariantPosition::Position;
using VariantPosition::Move;

constexpr int MATE = 30000;
constexpr int INFINITY_SCORE = 32000;

inline bool sameMove(Move a, Move b) {
    return a.from == b.from && a.to == b.to && a.promotion == b.promotion && a.special == b.special;
}

inline int pieceValue(char piece) {
    switch (std::tolower(static_cast<unsigned char>(piece))) {
    case 'p': return 100;
    case 'n': return 315;
    case 'b': return 340;
    case 'r': return 530;
    case 'q': return 1000;
    case 'a': return 725;
    case 'c': return 835;
    default: return 0;
    }
}

inline int evaluate(const Position& p) {
    int redScore = 0;
    for (int s = 0; s < p.geometry.count(); ++s) {
        const char piece = p.cells[s];
        if (piece == '.') continue;
        const int value = pieceValue(piece);
        const int f = p.geometry.file(s), r = p.geometry.rank(s);
        const int center = 8 - (std::abs(2*f - 9) + std::abs(2*r - (p.geometry.height-1)))/3;
        const int positional = (std::tolower(static_cast<unsigned char>(piece)) == 'p' ?
            (VariantPosition::isRed(piece) ? r : p.geometry.height-1-r) * 3 : center * 2);
        redScore += (VariantPosition::isRed(piece) ? 1 : -1) * (value + positional);
    }
    return (p.redToMove ? redScore : -redScore) + 8;
}

struct Result {
    Move best{};
    int score = 0;
    int depth = 0;
    uint64_t nodes = 0;
    bool completed = false;
};

class Searcher {
    struct Entry {
        int depth = -1;
        int score = 0;
        uint8_t bound = 0; // 0 exact, 1 upper, 2 lower
        Move best{};
    };
    std::unordered_map<uint64_t, Entry> table;
    std::vector<uint64_t> history;
    uint64_t nodes = 0;
    std::chrono::steady_clock::time_point deadline;
    bool stopped = false;

    bool timeOver() {
        // On 10x10 each node may cost milliseconds; coarse 256-node polling
        // can substantially overrun a short mobile move budget.
        if ((nodes & 15) == 0 && std::chrono::steady_clock::now() >= deadline) stopped = true;
        return stopped;
    }

    bool repeated(uint64_t hash) const {
        return std::count(history.begin(), history.end(), hash) >= 2;
    }

    static uint64_t tableKey(uint64_t hash, uint16_t halfmoveClock) {
        // Fifty-move eligibility must be part of a transposition's identity.
        return hash ^ (uint64_t(halfmoveClock) * 0x9e3779b97f4a7c15ULL);
    }

    int order(const Position& p, Move move, Move ttBest) const {
        if (sameMove(move, ttBest)) return 100000;
        int value = 0;
        if (move.special == Move::Special::EnPassant) value += 1000;
        else if (p.cells[move.to] != '.' && move.special != Move::Special::Escape)
            value += 1000 + 10 * pieceValue(p.cells[move.to]) - pieceValue(p.cells[move.from]);
        if (move.promotion) value += pieceValue(move.promotion) + 300;
        return value;
    }

    void orderMoves(const Position& p, std::vector<Move>& moves, Move ttBest) {
        std::stable_sort(moves.begin(), moves.end(), [&](Move a, Move b) {
            return order(p, a, ttBest) > order(p, b, ttBest);
        });
    }

    int quiesce(const Position& p, int alpha, int beta, int ply) {
        ++nodes;
        if (timeOver()) return 0;
        const uint64_t hash = VariantHash::position(p);
        if (repeated(hash)) return 0;
        history.push_back(hash);
        struct Pop { std::vector<uint64_t>& h; ~Pop() { h.pop_back(); } } pop{history};
        const bool check = p.inCheck(p.redToMove);
        auto moves = p.legalMoves();
        if (moves.empty()) return check ? -MATE + ply : 0;
        if (p.halfmoveClock >= 100) return 0;
        const int stand = evaluate(p);
        // A forced checking sequence cannot safely terminate at a static score.
        if (ply >= 40) { stopped = true; return 0; }
        if (!check) {
            if (stand >= beta) return stand;
            if (stand > alpha) alpha = stand;
        }
        orderMoves(p, moves, {});
        for (Move m : moves) {
            if (!check && p.cells[m.to] == '.' && m.special != Move::Special::EnPassant && !m.promotion)
                continue;
            const Position next = p.after(m);
            const int score = -quiesce(next, -beta, -alpha, ply + 1);
            if (stopped) return 0;
            if (score >= beta) return score;
            if (score > alpha) alpha = score;
        }
        return alpha;
    }

    int negamax(const Position& p, int depth, int alpha, int beta, int ply) {
        ++nodes;
        if (timeOver()) return 0;
        const uint64_t hash = VariantHash::position(p);
        if (repeated(hash)) return 0;
        if (depth <= 0) return quiesce(p, alpha, beta, ply);
        auto moves = p.legalMoves();
        if (moves.empty()) return p.inCheck(p.redToMove) ? -MATE + ply : 0;
        if (p.halfmoveClock >= 100) return 0;
        const int oldAlpha = alpha;
        const uint64_t key = tableKey(hash, p.halfmoveClock);
        auto found = table.find(key);
        Move ttBest{};
        if (found != table.end()) {
            const Entry& e = found->second;
            ttBest = e.best;
            if (e.depth >= depth && std::abs(e.score) < MATE - 256) {
                if (e.bound == 0) return e.score;
                if (e.bound == 1 && e.score <= alpha) return e.score;
                if (e.bound == 2 && e.score >= beta) return e.score;
            }
        }
        orderMoves(p, moves, ttBest);
        history.push_back(hash);
        int bestScore = -INFINITY_SCORE;
        Move best{};
        for (size_t index = 0; index < moves.size(); ++index) {
            const Position next = p.after(moves[index]);
            int score;
            if (index == 0) score = -negamax(next, depth - 1, -beta, -alpha, ply + 1);
            else {
                // Principal variation search, as used by PlentyChess. A full
                // window is required after a null-window improvement.
                score = -negamax(next, depth - 1, -alpha-1, -alpha, ply + 1);
                if (!stopped && score > alpha && score < beta)
                    score = -negamax(next, depth - 1, -beta, -alpha, ply + 1);
            }
            if (stopped) break;
            if (score > bestScore) { bestScore = score; best = moves[index]; }
            if (score > alpha) alpha = score;
            if (alpha >= beta) break;
        }
        history.pop_back();
        if (stopped) return 0;
        if (table.size() >= 65536) table.clear();
        table[key] = {depth, bestScore, uint8_t(bestScore <= oldAlpha ? 1 : bestScore >= beta ? 2 : 0), best};
        return bestScore;
    }

public:
    // priorPositions lists actual positions before root, oldest first.
    Result go(const Position& root, int maxDepth, int milliseconds,
              const std::vector<uint64_t>& priorPositions = {}) {
        nodes = 0;
        stopped = false;
        history = priorPositions;
        deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(milliseconds);
        Result result;
        auto moves = root.legalMoves();
        if (moves.empty()) {
            result.score = root.inCheck(root.redToMove) ? -MATE : 0;
            result.completed = true;
            return result;
        }
        result.best = moves.front();
        if (root.halfmoveClock >= 100 || repeated(VariantHash::position(root))) {
            result.completed = true;
            return result;
        }
        for (int depth = 1; depth <= maxDepth; ++depth) {
            const uint64_t rootHash = VariantHash::position(root);
            auto previous = table.find(tableKey(rootHash, root.halfmoveClock));
            orderMoves(root, moves, previous == table.end() ? result.best : previous->second.best);
            int alpha = -INFINITY_SCORE;
            const int beta = INFINITY_SCORE;
            int bestScore = -INFINITY_SCORE;
            Move best = moves.front();
            history.push_back(rootHash);
            for (Move m : moves) {
                int score = -negamax(root.after(m), depth - 1, -beta, -alpha, 1);
                if (stopped) break;
                if (score > bestScore) { bestScore = score; best = m; }
                if (score > alpha) alpha = score;
            }
            history.pop_back();
            if (stopped) break;
            result.best = best;
            result.score = bestScore;
            result.depth = depth;
            result.completed = true;
            if (bestScore >= MATE - 10) break;
        }
        result.nodes = nodes;
        return result;
    }
};

} // namespace VariantSearch
