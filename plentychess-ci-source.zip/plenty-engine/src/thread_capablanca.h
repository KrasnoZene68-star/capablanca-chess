#pragma once
#include "board.h"
#include "search.h"
#include "history.h"
#include <array>
#include <atomic>
#include <map>
#include <vector>

struct RootMove {
    Eval value = -EVAL_INFINITE;
    Eval meanScore = EVAL_NONE;
    Depth depth = 0;
    int selDepth = 0;
    Move move = Move::none();
    std::vector<Move> pv;
};
struct CoreSearchResult {
    Move move = Move::none();
    Eval score = 0;
    int depth = 0;
    uint64_t nodes = 0;
    bool completed = false;
    bool terminal = false;
    std::vector<Move> pv;
};
class Worker;
class ThreadPool {
    Worker* worker;
public:
    explicit ThreadPool(Worker* w):worker(w) {}
    void stopSearching();
};
class Worker {
    SharedHistory sharedHistory{1};
    ThreadPool localPool{this};
public:
    std::vector<Hash> boardHistory;
    Board rootBoard{};
    std::atomic_bool stopped{false};
    bool exiting = false;
    SearchData searchData;
    SearchParameters searchParameters;
    History history{0,&sharedHistory};
    ThreadPool* threadPool = &localPool;
    bool mainThread = true;
    std::vector<RootMove> rootMoves;
    std::map<Move,uint64_t> rootMoveNodes;
    std::vector<Move> excludedRootMoves;
    std::vector<std::array<MoveGen,2>> movepickers;
    std::array<int,2> optimism{};
    CoreSearchResult completedResult;

    Worker();
    Worker(const Worker&) = delete;
    Worker& operator=(const Worker&) = delete;
    // History excludes the current root; elapsed/node limits apply to this call.
    CoreSearchResult run(const Board& root, SearchParameters limits, const std::vector<Hash>& past = {});
    void requestStop() { stopped.store(true,std::memory_order_relaxed); }
    NNUE* evaluator() { return nullptr; }
private:
    void iterativeDeepening();
    void sortRootMoves();
    void printUCI(Worker*,int=1) {} // native API does not print during search
    Board* doMove(Board*,Hash,Move);
    void undoMove();
    Board* doNullMove(Board*);
    void undoNullMove();
    bool hasUpcomingRepetition(Board*,int);
    bool isDraw(Board*,int);
    Hash transpositionKey(Board*) const;
    template<NodeType nt> Eval search(Board*,SearchStack*,Depth,Eval,Eval,bool);
    template<NodeType nt> Eval qsearch(Board*,SearchStack*,Eval,Eval);
};
