# PlentyChess 8.0.0 → шахи Капабланки: контрольна точка 23

Повний дослідний C++ форк із усіма попередніми етапами 04–22. GitHub не підключено, сайт не змінено.

Додано автономну перевірку `verification/test_variant_worker.cjs`: без WebAssembly вона запускає JavaScript worker з імітованим ABI й підтверджує ініціалізацію, передавання FEN з історією ходів, параметри часу/глибини, формат оцінки мату та повідомлення про помилки. Розширено нативний `verification/test_variant_web.py`: приймаються всі 8 назв варіантів; історія 10×10 і мат 10×8 залишаються перевіреними. Також повторно пройшли 64 двопівходові зіставлення з чинною грою.

```sh
g++ -std=c++17 -DARCH_X86 -O2 -shared -fPIC verification/variant_web.cpp -o verification/libvariant_web.so
python3 verification/test_variant_web.py
node verification/test_variant_worker.cjs
node verification/compare_reachable_games.cjs
```

Це **імітація протоколу**, не тест реального WebAssembly чи Safari. На цьому середовищі немає Emscripten; без доступного компілятора або незалежно запущеної збірки `.js/.wasm` зробити справжній браузерний тест поки неможливо. Код пошуку залишається новим експериментальним шаром форку, а не оригінальною NNUE/`search.cpp` PlentyChess. Не підмінювати чинну гру.
