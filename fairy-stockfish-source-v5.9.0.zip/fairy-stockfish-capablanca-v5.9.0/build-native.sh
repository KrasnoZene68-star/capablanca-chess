#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/src"
make -j2 build ARCH=x86-64 nnue=no largeboards=yes debug=yes
