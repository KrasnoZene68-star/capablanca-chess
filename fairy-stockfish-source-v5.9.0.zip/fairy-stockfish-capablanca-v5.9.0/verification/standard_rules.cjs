const assert = require('node:assert/strict');
const { loadGame, referenceEngine } = require('./harness.cjs');

const START = 'rnabqkbcnr/pppppppppp/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1';
const CASES = [
  ['initial position', START],
  ['central king', '9k/10/10/10/4K5/10/10/10 w - - 0 1'],
  ['only knight escape', 'rr7k/10/10/10/10/10/10/K9 w - - 0 1'],
  ['knight capture', '9k/10/10/6r3/4K5/10/10/10 w - - 0 1'],
  ['opposing royal knight attacks', '10/7k2/10/10/4K5/10/10/10 w - - 0 1'],
  ['adjacent king safety', '10/10/10/10/4K1k3/10/10/10 w - - 0 1'],
  ['both castlings', 'r4k3r/10/10/10/10/10/10/R4K3R w KQkq - 0 1'],
  ['castling through a knight attack', '10/10/10/10/10/7k2/10/R4K3R w KQ - 0 1'],
  ['en passant', '9k/10/10/4Pp4/10/10/10/5K4 w - f6 0 2'],
  ['en passant exposes king', '9k/10/10/K1Pp5r/10/10/10/10 w - d6 0 2'],
  ['all six promotions', '9k/P9/10/10/10/10/10/5K4 w - - 0 1'],
  ['mate including knight moves', 'rrr6k/10/10/10/10/10/10/K9 w - - 0 1'],
  ['stalemate', '10/10/10/10/10/1qk7/10/K9 w - - 0 1'],
  ['black knight escape', 'k9/10/10/10/10/10/10/RR7K b - - 0 1'],
];
const files = 'abcdefghij';
const uci = m => files[m.fc] + (8 - m.fr) + files[m.tc] + (8 - m.tr) + (m.promote || '').toLowerCase();
function expandedMoves(api, state, turn, ep) {
  return api.allLegalMoves(state, turn, ep).flatMap(m => state[m.fr][m.fc].t === 'P' && [0,7].includes(m.tr)
    ? ['Q','R','B','N','A','C'].map(promote => ({ ...m, promote })) : [m]);
}
function perft(api, state, turn, ep, depth) {
  if (depth === 0) return 1;
  let n = 0;
  for (const m of expandedMoves(api, state, turn, ep)) {
    const next = api.applyMove(state, m, ep, true);
    n += perft(api, next.s, turn === 'r' ? 'g' : 'r', next.ep, depth - 1);
  }
  return n;
}

(async () => {
  const game = loadGame(), api = game.api;
  const ref = await referenceEngine(api.config);
  let checked = 0;
  try {
    for (const [name, fen] of CASES) for (const rule of ['classic','kingKnight']) {
      api.setPosition(fen, rule);
      const { state, turn, ep } = api.snapshot();
      const actualMoves = Array.from(expandedMoves(api, state, turn, ep), uci).sort();
      const reference = await ref.perft(rule, fen, 1);
      assert.deepEqual(actualMoves, reference.moves, name + ': ' + rule + ' legal moves');
      const actualNodes = perft(api, state, turn, ep, 2);
      const expectedNodes = (await ref.perft(rule, fen, 2)).total;
      assert.equal(actualNodes, expectedNodes, name + ': ' + rule + ' perft 2');
      checked++;
      console.log('PASS', rule, name, 'moves=' + actualMoves.length, 'perft2=' + actualNodes);
    }
    // Exercise the production bridge with the actual JS/WASM engine.
    assert.equal(await api.initFairy(), true);
    assert.equal(api.engineState().kingKnightReady, true);
    api.setPosition(CASES[2][1], 'kingKnight'); api.setAi();
    await api.aiTurn();
    assert.equal(uci(api.snapshot().lastMove), 'a1c2');
    assert.equal(api.engineState().lastOk, true);
    assert.equal(api.snapshot().history.length, 1);
    assert.match(game.elements.get('engineIndicatorText').textContent, /АКТИВНИЙ · король \+ кінь/);
    console.log('PASS real WASM bridge: only legal escape a1c2 played by Fairy-Stockfish');
    api.setMode('two');
    api.setPosition(CASES[2][1], 'classic');
    assert.equal(api.checkGameEnd(), true);
    assert.equal(game.elements.get('resultTitle').textContent, 'МАТ');
    api.setPosition(CASES[12][1], 'kingKnight');
    assert.equal(api.checkGameEnd(), true);
    assert.equal(game.elements.get('resultTitle').textContent, 'ПАТ');
    api.setPosition(CASES[11][1], 'kingKnight');
    assert.equal(api.checkGameEnd(), true);
    assert.equal(game.elements.get('resultTitle').textContent, 'МАТ');
    console.log('PASS game end: ordinary mate, knight-king mate, stalemate');
    api.setPosition(START, 'classic'); api.setAi();
    await api.aiTurn();
    assert.equal(api.engineState().selected, 'capablanca');
    assert.equal(api.engineState().lastOk, true);
    assert.equal(api.snapshot().history.length, 1);
    console.log('PASS switch back to classical Fairy-Stockfish');
    api.setMode('two');
    // Ensure engine underpromotion is preserved in the board AND notation.
    api.setPosition(CASES[10][1], 'kingKnight'); api.setAi();
    const promotion = api.uciToMove('a7a8c');
    assert.ok(promotion); api.commitMove(promotion);
    assert.equal(api.snapshot().state[0][0].t, 'C');
    assert.equal(api.snapshot().history[0].note, 'a8=C');
    console.log('PASS Chancellor underpromotion and move history');
    console.log('PASS total:', checked, 'differential positions, all bridge checks');
  } finally { game.close(); ref.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; });
