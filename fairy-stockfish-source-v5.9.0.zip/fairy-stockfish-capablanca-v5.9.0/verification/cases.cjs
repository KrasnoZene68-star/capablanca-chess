const cases = [
 {name:'only safe own knight',fen:'r8k/10/10/10/10/2b7/10/KN8 w - - 0 1',escape:['a1b1']},
 {name:'own pawn',fen:'r8k/10/10/10/10/2n7/1P8/K9 w - - 0 1',escape:['a1b2']},
 {name:'attacked own piece forbidden',fen:'rr7k/10/10/10/10/2b7/10/KN8 w - - 0 1',escape:[]},
 {name:'vacating king exposes attack',fen:'9k/10/10/10/10/10/9r/NK1r6 w - - 0 1',escape:[]},
 {name:'stalemate with safe own pawn',fen:'10/10/10/10/10/p9/P1k7/K9 w - - 0 1',escape:[]},
 {name:'ordinary interposition takes priority',fen:'r8k/10/10/10/10/3n6/10/KN8 w - - 0 1',escape:[],ordinary:['b1a3']},
 {name:'several safe own pieces',fen:'9k/10/10/10/10/3n6/P1n7/KN8 w - - 0 1',escape:['a1a2','a1b1']},
 {name:'capture checker takes priority',fen:'9k/10/10/10/10/3n6/P1n7/KNR7 w - - 0 1',escape:[],ordinary:['c1c2']},
 {name:'en passant is the only normal rescue',fen:'10/10/2k7/Pp1n6/K9/PP8/10/10 w - b6 0 1',escape:[],ordinary:['a5b6']},
 {name:'same position without en passant',fen:'10/10/2k7/Pp1n6/K9/PP8/10/10 w - - 0 1',escape:['a4a3','a4a5','a4b3']},
 {name:'ordinary king escape takes priority',fen:'r8k/10/10/10/10/2b7/10/K9 w - - 0 1',escape:[],ordinary:['a1b1']},
 {name:'distant own piece cannot be removed',fen:'rr7k/10/10/10/10/2b7/10/K1N7 w - - 0 1',escape:[]},
 {name:'initial position',fen:'rnabqkbcnr/pppppppppp/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1',escape:[]},
 {name:'ordinary castling',fen:'r4k3r/10/10/10/10/10/10/R4K3R w KQkq - 0 1',escape:[]},
 {name:'six promotions',fen:'9k/P9/10/10/10/10/10/5K4 w - - 0 1',escape:[]},
];
for(const p of ['B','R','Q','A','C'])cases.push({name:'own '+p,fen:'r8k/10/10/10/10/2b7/10/K'+p+'8 w - - 0 1',escape:['a1b1']});
function mirror(fen){const f=fen.split(' ');f[0]=f[0].split('/').reverse().join('/').replace(/[a-z]/gi,p=>p===p.toLowerCase()?p.toUpperCase():p.toLowerCase());f[1]=f[1]==='w'?'b':'w';f[2]=f[2].replace(/[a-z]/gi,p=>p===p.toLowerCase()?p.toUpperCase():p.toLowerCase());if(f[3]!=='-')f[3]=f[3][0]+(9-Number(f[3][1]));return f.join(' ')}
for(const c of [...cases])if(c.escape.length)cases.push({name:'black '+c.name,fen:mirror(c.fen),escape:c.escape.map(m=>m.replace(/[1-8]/g,n=>String(9-Number(n))))});
module.exports=cases;
