import subprocess,sys,re
variant,position,depth,want,*rest=sys.argv[1:]
chess960=rest[0] if rest else 'false'
cmd=f'setoption name UCI_Chess960 value {chess960}\nsetoption name UCI_Variant value {variant}\nposition {position}\ngo perft {depth}\nquit\n'
p=subprocess.run(['./stockfish'],input=cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
match=re.search(r'Nodes searched:\s*(\d+)',p.stdout)
if p.returncode or not match or match[1]!=want:
 print('FAIL',variant,position,depth,want,p.returncode,p.stdout[-2500:],p.stderr,file=sys.stderr);sys.exit(1)
print('PASS',variant,depth,want,file=sys.stderr)
