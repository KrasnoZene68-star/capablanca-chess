const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const {loadGame,referenceEngine,releaseDir}=require('./harness.cjs');
const cases=require('./cases.cjs');
const path=require('node:path');
const oldDir=process.env.OLD_STOCKFISH_DIR;
const oldStockfish=oldDir?require(path.join(path.resolve(oldDir),'stockfish.js')):null;
const files='abcdefghij';
const uci=m=>files[m.fc]+(8-m.fr)+files[m.tc]+(8-m.tr)+(m.promote||'').toLowerCase();
function expanded(api,s,t,ep){return Array.from(api.allLegalMoves(s,t,ep)).flatMap(m=>s[m.fr][m.fc].t==='P'&&[0,7].includes(m.tr)?['Q','R','B','N','A','C'].map(promote=>({...m,promote})):[m])}
function perft(api,s,t,ep,d){if(!d)return 1;let n=0;for(const m of expanded(api,s,t,ep)){const r=api.applyMove(s,m,ep,true);n+=perft(api,r.s,t==='r'?'g':'r',r.ep,d-1)}return n}
(async()=>{
 const game=loadGame(),api=game.api;let ref;
 try{
  const html=fs.readFileSync(path.join(releaseDir,'index.html'),'utf8');
  for(const m of html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g))new vm.Script(m[1]);
  assert.equal(await api.initFairy(),true);assert.equal(api.engineState().escapeReady,true);assert.equal(api.strengthLevel(),10);assert.equal(api.profiles.length,16);
  ref=await referenceEngine(api.config);
  for(const c of cases){
   api.setPosition(c.fen,'escape');const {state,turn,ep}=api.snapshot();
   const moves=expanded(api,state,turn,ep);
   assert.deepEqual(moves.filter(m=>m.special==='escape').map(uci).sort(),[...c.escape].sort(),c.name+' expected escape');
   const real=await ref.perft('escape',c.fen,1);
   assert.deepEqual(real.moves,moves.map(uci).sort(),c.name+' moves');
   assert.equal((await ref.perft('escape',c.fen,2)).total,perft(api,state,turn,ep,2),c.name+' perft2');
  }
  console.log('PASS real WASM and UI agree on all '+cases.length+' positions (both colors, pawn/A/C, attack before/after, EP priority, stalemate)');
  // A legal previous position: moving B a5-c3 uncovers R a8 and gives
  // a double check. It is mate in classical rules, but not in variant III.
  const parent='r8k/10/10/b9/10/10/10/KN8 b - - 0 1';
  for(const variant of ['capablanca','capablanca_escape']){
   ref.engine.postMessage('setoption name UCI_Variant value '+variant);
   ref.engine.postMessage('setoption name Skill Level value 20');ref.engine.postMessage('ucinewgame');ref.engine.postMessage('position fen '+parent);
   const lines=await ref.command('go depth 3 searchmoves a5c3',l=>l.startsWith('bestmove '));
   const info=lines.filter(l=>l.startsWith('info depth ')).at(-1);
   if(variant==='capablanca')assert.match(info,/score mate 1\b/);
   else{assert.doesNotMatch(info,/score mate 1\b/);assert.match(info,/pv a5c3 a1b1/)}
   console.log('PASS search anticipates emergency',variant,info);
  }
  for(const c of [cases[0],cases[1],cases.find(c=>c.name==='own A'),cases.find(c=>c.name==='black own C')]){
   api.setPosition(c.fen,'escape');api.setAi();
   assert.equal(api.checkGameEnd(),false);
   await api.aiTurn();
   assert.equal(api.engineState().lastOk,true);assert.equal(api.snapshot().lastMove.special,'escape');
   assert.equal(api.snapshot().history.length,1);assert.match(api.snapshot().history[0].note,/^K!/);
   assert.match(game.elements.get('engineIndicatorText').textContent,/Fairy-Stockfish: АКТИВНИЙ · аварійний вихід/);
  }
  console.log('PASS production bridge: emergency turns and history for pawn, N, A and C, red and green');
  api.setMode('two');
  for(const [idx,end]of [[2,'МАТ'],[3,'МАТ'],[4,'ПАТ']]){api.setPosition(cases[idx].fen,'escape');assert.equal(api.checkGameEnd(),true);assert.equal(game.elements.get('resultTitle').textContent,end)}
  console.log('PASS mate and stalemate remain terminal when emergency is unavailable');
  api.setPosition(cases[0].fen,'escape');api.setAi();api.setStrength(16);
  let started;const seen=new Promise(r=>started=r);const e=api.engine(),send=e.postMessage.bind(e);
  e.postMessage=c=>{send(c);if(c.startsWith('go movetime '))started()};
  const thinking=api.aiTurn();await seen;
  api.setPosition(cases[12].fen,'kingKnight');api.setAi();api.setStrength(10);
  const next=api.aiTurn();await thinking;await next;
  assert.equal(api.snapshot().variant,'kingKnight');assert.equal(api.snapshot().history.length,1);assert.equal(api.engineState().selected,'capablanca_kingknight');assert.equal(api.engineState().lastOk,true);
  console.log('PASS switching variants stops and discards the previous search, then uses the correct new rules');
 }finally{if(ref)ref.close();game.close()}
 if(!oldStockfish){console.log('SKIP old-engine fallback: set OLD_STOCKFISH_DIR to the original 1.1.12 engine files to rerun this check');return}
 const old=loadGame(()=>oldStockfish({wasmBinary:fs.readFileSync(path.join(oldDir,'stockfish.wasm'))}));
 try{
  assert.equal(await old.api.initFairy(),true);assert.equal(old.api.engineState().escapeReady,false);
  old.api.setPosition(cases[0].fen,'escape');old.api.setAi();await old.api.aiTurn();
  assert.notEqual(old.api.engineState().lastOk,true);assert.equal(old.api.snapshot().lastMove.special,'escape');
  assert.match(old.elements.get('engineIndicatorText').textContent,/Вбудований ШІ.*оновлені файли рушія/);
  console.log('PASS old engine cannot masquerade as Fairy support for variant III; fallback is explicit');
 }finally{old.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
