from pathlib import Path
root=Path(__file__).parent/'fairy-stockfish.wasm-b2e693ef1e111233ce3fb40685921708b3276ed6'/'src'
def edit(name,old,new,count=1):
 p=root/name;s=p.read_text();assert s.count(old)==count,(name,s.count(old),old[:70]);p.write_text(s.replace(old,new))
edit('types.h','  SPECIAL            = 7 << (2 * SQUARE_BITS),','  SPECIAL            = 7 << (2 * SQUARE_BITS),\n  KING_ESCAPE        = 8 << (2 * SQUARE_BITS),')
edit('variant.h','  bool makpongRule = false;','  bool makpongRule = false;\n  bool emergencyKingEscape = false; // Safe own-piece capture only after ordinary mate')
edit('parser.cpp','    parse_attribute("makpongRule", v->makpongRule);','    parse_attribute("makpongRule", v->makpongRule);\n    parse_attribute("emergencyKingEscape", v->emergencyKingEscape);')
edit('variant.cpp','    // Capahouse\n','''    // Capablanca III: only after all ordinary check evasions fail, the king
    // may remove an adjacent friendly piece and occupy its safe square.
    Variant* capablanca_escape_variant() {
        Variant* v = capablanca_variant()->init();
        v->emergencyKingEscape = true;
        return v;
    }
    // Capahouse
''')
edit('variant.cpp','    add("capablanca", capablanca_variant());','    add("capablanca", capablanca_variant());\n    add("capablanca_escape", capablanca_escape_variant());')
edit('variant.cpp','                    && !makpongRule','                    && !makpongRule\n                    && !emergencyKingEscape')
edit('position.h','  bool must_capture() const;','  bool emergency_king_escape() const { return var->emergencyKingEscape; }\n  bool must_capture() const;')
edit('movegen.cpp','''  return us == WHITE ? generate_all<WHITE, Type>(pos, moveList)
                     : generate_all<BLACK, Type>(pos, moveList);''','''  ExtMove* end = us == WHITE ? generate_all<WHITE, Type>(pos, moveList)
                            : generate_all<BLACK, Type>(pos, moveList);

  if constexpr (Type == EVASIONS)
      if (pos.emergency_king_escape())
      {
          // Test EVERY ordinary evasion, including captures, blocks, promotions
          // and en passant. Generate no emergency actions if one is legal.
          // This tests the ordinary list directly, avoiding recursive LEGAL calls.
          for (ExtMove* cur = moveList; cur != end; ++cur)
              if (pos.legal(*cur))
                  return end;

          end = moveList;
          if (!pos.count<KING>(us))
              return end;
          Square from = pos.square<KING>(us);
          Bitboard targets = attacks_bb<KING>(from) & pos.pieces(us) & ~pos.pieces(us, KING);
          while (targets)
          {
              Square to = pop_lsb(targets);
              // The friendly piece must be unattacked BEFORE the action and
              // the king must be safe AFTER its original square is vacated.
              if (!pos.attackers_to(to, ~us) && !pos.attackers_to(to, pos.pieces() ^ from, ~us))
                  *end++ = make<KING_ESCAPE>(from, to);
          }
      }

  return end;''')
edit('position.cpp','''  // Illegal checks
''','''  // Recheck the full emergency condition for externally supplied moves too.
  // The EVASIONS generator checks only ordinary moves before adding escapes.
  if (type_of(m) == KING_ESCAPE)
      return emergency_king_escape() && checkers() && MoveList<EVASIONS>(*this).contains(m);

  // Illegal checks
''')
old='''  Bitboard occupied = (type_of(m) != DROP ? pieces() ^ from : pieces()) | to;
  Bitboard janggiCannons = pieces(JANGGI_CANNON);'''
new='''  Bitboard occupied = (type_of(m) != DROP ? pieces() ^ from : pieces()) | to;
  if (type_of(m) == KING_ESCAPE)
  {
      Square theirKing = square<KING>(~sideToMove);
      // Neither the removed friendly piece nor the old king can give check.
      return (attacks_bb(sideToMove, KING, to, occupied) & theirKing)
          || (attackers_to(theirKing, occupied, sideToMove) & ~(square_bb(from) | to));
  }
  Bitboard janggiCannons = pieces(JANGGI_CANNON);'''
edit('position.cpp',old,new)
edit('position.cpp','''  assert(captured == NO_PIECE || color_of(captured) == (type_of(m) != CASTLING ? them : us));''','''  assert(captured == NO_PIECE || color_of(captured) ==
         (type_of(m) == CASTLING || type_of(m) == KING_ESCAPE ? us : them));''')
edit('position.cpp','''          st->nonPawnMaterial[them] -= PieceValue[MG][captured];''','''          st->nonPawnMaterial[color_of(captured)] -= PieceValue[MG][captured];''')
edit('position.cpp','''  // Only deal with normal moves, assume others pass a simple SEE
''','''  // An emergency removes OUR piece. Its square is safe, so this is a
  // material loss, never an enemy capture gain. Search must not prune it.
  if (type_of(m) == KING_ESCAPE)
      return -PieceValue[MG][piece_on(to_sq(m))] >= threshold;

  // Only deal with normal moves, assume others pass a simple SEE
''')
edit('movepick.cpp','''          if (pos.capture(m))
              m.value =  PieceValue[MG][pos.piece_on(to_sq(m))]''','''          if (type_of(m) == KING_ESCAPE)
              m.value = -PieceValue[MG][pos.piece_on(to_sq(m))];
          else if (pos.capture(m))
              m.value =  PieceValue[MG][pos.piece_on(to_sq(m))]''')
edit('search.cpp','''      if (  !rootNode
          && (pos.non_pawn_material(us)''','''      if (  !rootNode
          && type_of(move) != KING_ESCAPE
          && (pos.non_pawn_material(us)''')
edit('search.cpp','''      // Futility pruning and moveCount pruning
      if (    bestValue''','''      // Emergency evasions must be searched even when they sacrifice material.
      // Futility pruning and moveCount pruning
      if (    type_of(move) != KING_ESCAPE
          &&  bestValue''')
edit('search.cpp','''      // Do not search moves with negative SEE values
      if (    bestValue''','''      // Do not prune the only class of legal check evasions for a material loss.
      if (    type_of(move) != KING_ESCAPE
          &&  bestValue''')
# The regular capture/undo path already stores the exact Piece (including its
# color), and restores castling rights, hashes, material and NNUE through StateInfo.
p=root/'variants.ini'
with p.open('a') as f:f.write('''\n# Capablanca III is built in as capablanca_escape. This flag is intended for\n# chess-like royal-king variants without drops, explosions or other capture rules.\n# The special capture is adjacent only, requires ordinary checkmate, an unattacked\n# own non-king piece, and a destination safe after moving the king.\n[capablanca-escape-example:capablanca]\nemergencyKingEscape = true\n''')
print('Patched engine rules, move generation, make/unmake material, check detection and search pruning.')
