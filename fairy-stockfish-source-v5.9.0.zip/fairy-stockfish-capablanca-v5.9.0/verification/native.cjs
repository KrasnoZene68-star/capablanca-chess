const fs=require('node:fs'),assert=require('node:assert/strict'),{spawn}=require('node:child_process');
const {loadGame}=require('./harness.cjs');
const cases=require('./cases.cjs');
const bin=process.env.STOCKFISH_TEST_BINARY || require('node:path').join(__dirname, '../src/stockfish');
const p=spawn(bin);let pending,buf='';const commands=[];let errors='';
p.stderr.on('data',x=>{errors+=x});p.stdout.on('data',x=>{buf+=x;let n;while((n=buf.indexOf('\n'))>=0){const l=buf.slice(0,n).trim();buf=buf.slice(n+1);if(pending){pending.lines.push(l);if(pending.pred(l)){const q=pending;pending=null;clearTimeout(q.timer);q.resolve(q.lines)}}}});p.on('exit',code=>{if(pending){clearTimeout(pending.timer);pending.reject(Error('Engine exited '+code+' '+errors));pending=null}});
function send(c){commands.push(c);p.stdin.write(c+'\n')}
function command(c,pred,timeout=15000){assert.ok(!pending);return new Promise((resolve,reject)=>{pending={pred,resolve,reject,lines:[],timer:setTimeout(()=>{pending=null;reject(Error('timeout '+c+' '+errors))},timeout)};send(c)})}
function uci(m){return 'abcdefghij'[m.fc]+(8-m.fr)+'abcdefghij'[m.tc]+(8-m.tr)+(m.promote||'').toLowerCase()}
function moves(a,s,t,ep){return Array.from(a.allLegalMoves(s,t,ep)).flatMap(m=>s[m.fr][m.fc].t==='P'&&[0,7].includes(m.tr)?['Q','R','B','N','A','C'].map(promote=>({...m,promote})):[m])}
function perft(a,s,t,ep,d){if(!d)return 1;let n=0;for(const m of moves(a,s,t,ep)){const x=a.applyMove(s,m,ep,true);n+=perft(a,x.s,t==='r'?'g':'r',x.ep,d-1)}return n}
(async()=>{const g=loadGame(()=>Promise.reject(Error('unused'))),a=g.api;
try{
 const info=await command('uci',l=>l==='uciok');assert.ok(info.some(l=>l.includes('var capablanca_escape')));
 send('setoption name Threads value 1');send('setoption name Hash value 32');
 send('setoption name UCI_Variant value capablanca_escape');
 for(const c of cases){
  a.setPosition(c.fen,'escape');const s=a.snapshot();const js=moves(a,s.state,s.turn,s.ep);
  assert.deepEqual(js.filter(m=>m.special==='escape').map(uci).sort(),[...c.escape].sort(),c.name+' independent escape expectation');
  if(c.ordinary)assert.deepEqual(js.map(uci).sort(),[...c.ordinary].sort(),c.name+' ordinary rescue');
  send('position fen '+c.fen);
  const one=await command('go perft 1',l=>l.startsWith('Nodes searched:'));
  const native=one.filter(l=>/^[a-j][1-8][a-j][1-8][qrbnac]?: /.test(l)).map(l=>l.split(':')[0]).sort();
  assert.deepEqual(native,js.map(uci).sort(),c.name+' legal move parity');
  const depth=c.name==='initial position'?2:3;
  const count=perft(a,s.state,s.turn,s.ep,depth);
  const n=await command('go perft '+depth,l=>l.startsWith('Nodes searched:'));
  assert.equal(Number(n.at(-1).split(':')[1]),count,c.name+' perft '+depth);
  if(c.escape.length){
   // Exercise move selection inside search, including do/undo and deep evasion nodes.
   send('ucinewgame');send('setoption name Skill Level value 20');send('position fen '+c.fen);
   const search=await command('go depth 5',l=>l.startsWith('bestmove '));
   assert.ok(c.escape.includes(search.at(-1).split(' ')[1]),c.name+' search selects legal escape');
  }
  console.log('PASS',c.name,'moves',native.length,'depth',depth,'nodes',count);
 }
 assert.equal(errors,'','no debug assertions or engine errors');
 console.log('PASS native engine differential positions:',cases.length);
}catch(e){console.error(e);process.exitCode=1}finally{g.close();send('quit');p.stdin.end()}
})();
