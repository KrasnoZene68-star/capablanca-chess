#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../src"
# First run ../build-native.sh in this clean native source tree.
objects=()
for object in *.o; do
    case "$object" in main.o|*.failed-*) ;; *) objects+=("$object") ;; esac
done
g++ -std=c++17 -O2 -g -DLARGEBOARDS -DALLVARS -DPRECOMPUTED_MAGICS -DNNUE_EMBEDDING_OFF -DUSE_PTHREADS -DIS_64BIT -DUSE_SSE2 -I. ../verification/state_roundtrip.cpp "${objects[@]}" -lpthread -o ../verification/state_roundtrip
../verification/state_roundtrip ../verification/positions.fen
