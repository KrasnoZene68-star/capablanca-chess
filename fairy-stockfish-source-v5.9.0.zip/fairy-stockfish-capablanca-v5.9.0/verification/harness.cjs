const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { performance } = require('node:perf_hooks');
const releaseDir = path.resolve(process.env.CAPABLANCA_RELEASE_DIR || path.join(__dirname, '../..'));
const Stockfish = require(path.join(releaseDir, 'stockfish.js'));
const wasmBinary = fs.readFileSync(path.join(releaseDir, 'stockfish.wasm'));

function loadGame(factory = () => Stockfish({ wasmBinary }), options = {}) {
  const html = fs.readFileSync(path.join(releaseDir, 'index.html'), 'utf8');
  const initialStrength=html.match(/<select id="strength"[^>]*>[\s\S]*?<option value="(\d+)" selected>/)[1];
  const elements = new Map(), timers = new Set(), engines = [];
  function element(id) {
    if (elements.has(id)) return elements.get(id);
    const listeners = new Map(), classes = new Set();
    const el = {
      getContext(){return options.gl||null},
      id, value: ({ variant: 'classic', mode: 'two', humanSide: 'r', strength: initialStrength, viewMode: '2d', pieceSet: 'n1' })[id] || '',
      children: [], options: [{ value: 'ai', textContent: '' }], dataset: {}, style: {}, textContent: '', innerHTML: '',
      attrs: {}, open: false, focused: false,
      classList: {
        add(...xs) { xs.forEach(x=>classes.add(x)); },
        remove(...xs) { xs.forEach(x=>classes.delete(x)); },
        toggle(x, force) { const yes=force??!classes.has(x); yes?classes.add(x):classes.delete(x); return yes; },
        contains(x) { return classes.has(x); },
      },
      setAttribute(name,value) { this.attrs[name]=value; },
      focus() { this.focused=true; },
      showModal() { this.open=true; },
      close() { this.open=false; this.dispatch('close'); },
      getBoundingClientRect() { return {left:20,top:20,right:380,bottom:700,width:360,height:680}; },
      addEventListener(name, fn) { listeners.set(name, fn); },
      dispatch(name,event={}) { return listeners.get(name)?.(event); },
      querySelectorAll() { return []; }, querySelector() { return null; },
      appendChild(child) { this.children.push(child); }, remove() {},
    };
    elements.set(id, el); return el;
  }
  let script = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)].at(-1)[1];
  const expose = `
  globalThis.game = {
    initialState, allLegalMoves, normalLegalMoves, inCheck, attacksSquare, applyMove,
    stateToFen, uciToMove, initFairy, aiTurn, reset, commitMove, checkGameEnd,
    fairyCommand, fairySend, config: FAIRY_KING_KNIGHT_CONFIG,
    profiles: STRENGTH_LEVELS, strengthLevel, strengthProfile,
    graphics:{render:renderGL,project:projectGLPoint,pick:screenToSquareGL,hit:screenToPieceGL,
      meshes:()=>PREBUILT_MESHES,ready:()=>GLReady,
      piece:makePieceGeom,view:()=>viewModeEl.value},
    setPosition(fen, rule='classic') {
      gameGeneration++; aiTurnRequest=null;
      if(fairyBusy)fairySend('stop');
      variantEl.value=mobileVariant.value=rule;
      const fields=fen.split(' ');
      state=fields[0].split('/').map(row=>{
        const out=[];
        for(const token of row.match(/\\d+|[a-z]/gi)) {
          if(/^\\d+$/.test(token))out.push(...Array(Number(token)).fill(null));
          else out.push({t:token.toUpperCase(),c:token===token.toUpperCase()?'r':'g',m:true});
        }
        return out;
      });
      for(const [letter,r,c] of [['K',7,9],['Q',7,0],['k',0,9],['q',0,0]]) {
        if(fields[2].includes(letter)) {
          if(state[r][5])state[r][5].m=false;
          if(state[r][c])state[r][c].m=false;
        }
      }
      turn=fields[1]==='w'?'r':'g';
      epSquare=fields[3]==='-'?null:{r:8-Number(fields[3][1]),c:FILES.indexOf(fields[3][0])};
      selected=null;legal=[];lastMove=null;history=[];gameOver=false;pendingPromotion=null;
      fairyLastSearchOk=null;
    },
    setAi(side=turn) {modeEl.value='ai';humanSideEl.value=enemy(side)},
    setMode(v){modeEl.value=v}, setHuman(v){humanSideEl.value=v},
    setStrength(v){strengthEl.value=String(v)},
    snapshot(){return {state,turn,history,gameOver,ep:epSquare,lastMove,variant:variant(),generation:gameGeneration}},
    engineState(){return {ready:fairyReady,kingKnightReady:fairyKingKnightReady,escapeReady:fairyEscapeReady,selected:fairySelectedVariant,lastOk:fairyLastSearchOk,reason:fairyFailureReason}},
    engine(){return fairyEngine},
    destroy(){discardFairy()}
  };
  `;
  script = script.replace('// Deterministic first-load initialization:', expose + '\n// Deterministic first-load initialization:');
  const context = {
    atob, requestAnimationFrame(fn){fn();return 1},
    document: { getElementById: element, querySelectorAll: () => [], createElement: () => element(Symbol()), body: element('body') },
    window: { addEventListener() {} }, console: options.console || console, performance,
    setTimeout(fn, ms) { const id = setTimeout(() => { timers.delete(id); fn(); }, options.fastTimeouts && ms >= 5000 ? 30 : ms); timers.add(id); return id; },
    clearTimeout(id) { timers.delete(id); clearTimeout(id); },
    Stockfish: async () => { const e = await factory(); engines.push(e); return e; },
  };
  vm.runInNewContext(script, context, { filename: 'index.html' });
  return {
    api: context.game, elements, engines,
    close() { for (const id of timers) clearTimeout(id); context.game.destroy(); },
  };
}

async function referenceEngine(config) {
  const engine = await Stockfish({ wasmBinary });
  let pending;
  engine.addMessageListener(line => {
    if (!pending) return;
    line = String(line).trim(); pending.lines.push(line);
    if (pending.predicate(line)) {
      const p = pending; pending = null; clearTimeout(p.timer); p.resolve(p.lines);
    }
  });
  const command = (cmd, predicate, timeout = 10000) => new Promise((resolve, reject) => {
    if (pending) return reject(new Error('Overlapping reference requests'));
    pending = { predicate, resolve, lines: [], timer: setTimeout(() => { pending = null; reject(new Error('Reference timeout: ' + cmd)); }, timeout) };
    engine.postMessage(cmd);
  });
  await command('uci', l => l === 'uciok');
  engine.FS.writeFile('/test.ini', config);
  engine.postMessage('setoption name VariantPath value /test.ini');
  engine.postMessage('setoption name Threads value 1');
  engine.postMessage('setoption name Hash value 16');
  await command('isready', l => l === 'readyok');
  return {
    engine, command,
    async perft(rule, fen, depth) {
      engine.postMessage('setoption name UCI_Variant value ' + (rule === 'classic' ? 'capablanca' : rule === 'escape' ? 'capablanca_escape' : 'capablanca_kingknight'));
      engine.postMessage('position fen ' + fen);
      const lines = await command('go perft ' + depth, l => l.startsWith('Nodes searched:'));
      return {
        total: Number(lines.find(l => l.startsWith('Nodes searched:')).split(':')[1]),
        moves: lines.filter(l => /^[a-j][1-8][a-j][1-8][qrbnac]?: /.test(l)).map(l => l.split(':')[0]).sort(),
        lines,
      };
    },
    close() { engine.terminate(); },
  };
}

module.exports = { loadGame, referenceEngine, releaseDir };
