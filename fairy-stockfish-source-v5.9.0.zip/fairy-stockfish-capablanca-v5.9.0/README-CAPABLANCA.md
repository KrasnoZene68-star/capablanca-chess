# Fairy-Stockfish for Capablanca Chess v5.9.0

Modified on 2026-09-14 for the author's emergency king escape rule.
This archive contains the complete corresponding C++ engine source and build scripts
for the stockfish.js, stockfish.wasm and stockfish.worker.js shipped in v5.9.0.
The engine retains its upstream GPLv3 license; see Copying.txt and AUTHORS.

Upstream: https://github.com/fairy-stockfish/fairy-stockfish.wasm
Exact source revision: b2e693ef1e111233ce3fb40685921708b3276ed6
Upstream npm release used by the previous game: fairy-stockfish-nnue.wasm 1.1.12.
capablanca-emergency.patch records every source change against that revision.

## Rule and implementation

The built-in UCI variant is capablanca_escape. The configurable rule is
emergencyKingEscape=true, intended here for the Capablanca base variant.
The side to move must be in check and have NO ordinary legal move by ANY piece.
Only then may its ordinary king remove one adjacent friendly non-king piece and
occupy that square. The square must be unattacked both before the action and after
the king vacates its original square. Stalemate does not activate the rule.

KING_ESCAPE is a distinct move type in the engine's existing move encoding.
Generation, legality, checks, make/unmake, material accounting, move ordering,
static exchange evaluation and main/quiescence search handle it explicitly.
Capturing one's own piece is a material cost. The only rescue cannot be pruned as
an unprofitable capture. Classical specialized endgame shortcuts are disabled for
this variant. No neural network was trained or embedded for this release.

Modified upstream files:
- src/movegen.cpp
- src/movepick.cpp
- src/parser.cpp
- src/position.cpp
- src/position.h
- src/search.cpp
- src/types.h
- src/variant.cpp
- src/variant.h
- src/variants.ini

## Build the shipped browser engine

Use a fresh source tree. Requirements: GNU make, Python 3, Emscripten SDK 2.0.26.
The SDK is available from https://github.com/emscripten-core/emsdk/tree/2.0.26 .
Install and activate that SDK, source its emsdk_env.sh, then run:

```sh
bash build-wasm.sh
```

The build and copy commands intentionally run sequentially. Results are under
src/emscripten/public/: stockfish.js, stockfish.wasm, stockfish.worker.js.
No SIMD, embedded network, or Closure minification is required. The pthread worker
interface matches the previous application; the existing COI service worker and
site setup remain necessary. The application points at the new assets with a
v=5.9.0 cache version. SDK/toolchain downloads are not bundled here.

## Native build and verification

Use a separate fresh source tree for the native build, avoiding mixed object files:

```sh
bash build-native.sh
cd src
./stockfish bench
./stockfish check variants.ini
../tests/perft.sh all
```

The original perft script requires expect. Without expect, from src run
`bash ../verification/perft-python.sh all`; it preserves the upstream test cases
and expected counts and invokes the included Python subprocess helper instead.
For the custom state/hash/material checks, run `bash verification/run-state-test.sh`
from the source root after the native build.

## Application and real WASM checks

Keep the release's index.html and three engine assets in one directory, then set
CAPABLANCA_RELEASE_DIR to that directory. With Node.js 18 or later:

```sh
export CAPABLANCA_RELEASE_DIR=/absolute/path/to/capablanca_v5_9_0
node verification/wasm_escape.cjs
node verification/standard_rules.cjs
node verification/native.cjs
```

The native test defaults to src/stockfish; STOCKFISH_TEST_BINARY can override it.
For the old-engine rejection check, also set OLD_STOCKFISH_DIR to a directory
containing the original 1.1.12 stockfish.js/wasm/worker files. Without that optional
baseline only that check is explicitly skipped. It passed with the baseline in
the recorded release run. The original patch construction script is archived for
reference and expects the original development folder layout; use the supplied
.patch with the exact upstream revision when reconstructing changes elsewhere.

Recorded release results are in verification/recorded-results. Test file paths in
this archive were made portable after the recorded runs. The corrected
'distant own piece cannot be used' fixture was verified in the final real-WASM
suite; the native log predates that fixture correction. The test harness executes
the actual game JavaScript with a stub DOM and the actual WebAssembly engine.
It does not establish Safari/Chrome rendering or performance on a physical device.

The game's variants I and II remain connected to Fairy-Stockfish. Variant IV still
uses the built-in AI and is not advertised as supported by this engine update.
