#!/usr/bin/env bash
set -euo pipefail
# Activate Emscripten 2.0.26 before running this script.
cd "$(dirname "$0")/src"
make -j2 build ARCH=wasm nnue=no embedded_nnue=no wasm_simd=no minify_js=no EM_COMMIT=b2e693e_escape1 EM_UPSTREAM=b2e693e EM_EMSCRIPTEN=2.0.26
make emscripten_copy_files ARCH=wasm nnue=no embedded_nnue=no wasm_simd=no minify_js=no EM_COMMIT=b2e693e_escape1 EM_UPSTREAM=b2e693e EM_EMSCRIPTEN=2.0.26
