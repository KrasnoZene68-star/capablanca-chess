#include <cassert>
#include <fstream>
#include <iostream>
#include <string>
#include "bitboard.h"
#include "evaluate.h"
#include "position.h"
#include "search.h"
#include "thread.h"
#include "uci.h"
#include "piece.h"
#include "variant.h"
#include "tt.h"
using namespace Stockfish;
size_t checked = 0, escapes = 0, triples = 0;
void visit(Position& p, const Variant* v, int depth) {
    if (!depth) return;
    const std::string original=p.fen();
    const Key originalKey=p.key();
    for (Move m : MoveList<LEGAL>(p)) {
        assert(p.pseudo_legal(m));
        const bool triple = type_of(p.moved_piece(m)) == PAWN && std::abs(int(to_sq(m))-int(from_sq(m)))==3*NORTH;
        const int whiteBudget=p.state()->tripleRemaining[WHITE],blackBudget=p.state()->tripleRemaining[BLACK];
        const Piece victim=p.piece_on(to_sq(m));
        const Color mover=p.side_to_move();
        const Value oldOwn=p.non_pawn_material(mover);
        const Value oldEnemy=p.non_pawn_material(~mover);
        StateInfo st{}, referenceSt{};
        p.do_move(m, st);
        if(triple) {
            ++triples;
            assert(p.state()->tripleRemaining[mover] == (mover==WHITE?whiteBudget:blackBudget)-1);
            assert(p.state()->tripleRemaining[~mover] == (mover==WHITE?blackBudget:whiteBudget));
        }
        // Null search moves must preserve budgets and restore the whole position.
        if(!p.checkers()) {const auto before=p.fen();const auto key=p.key();StateInfo nullState{};p.do_null_move(nullState);assert(p.state()->tripleRemaining[WHITE]==st.tripleRemaining[WHITE]);assert(p.state()->tripleRemaining[BLACK]==st.tripleRemaining[BLACK]);p.undo_null_move();assert(p.fen()==before&&p.key()==key);}
        Position reference;
        reference.set(v,p.fen(),false,&referenceSt,Threads.main());
        assert(p.key()==reference.key());
        assert(p.pawn_key()==reference.pawn_key());
        assert(p.material_key(v->endgameEval)==reference.material_key(v->endgameEval));
        assert(p.psq_score()==reference.psq_score());
        assert(p.non_pawn_material(WHITE)==reference.non_pawn_material(WHITE));
        assert(p.non_pawn_material(BLACK)==reference.non_pawn_material(BLACK));
        assert(p.checkers()==reference.checkers());
        if(type_of(m)==KING_ESCAPE) {
            assert(color_of(victim)==mover);
            assert(p.non_pawn_material(~mover)==oldEnemy);
            assert(p.non_pawn_material(mover)==oldOwn-(type_of(victim)==PAWN?0:PieceValue[MG][victim]));
            assert(p.rule50_count()==0);
            ++escapes;
        }
        ++checked;
        visit(p,v,depth-1);
        p.undo_move(m);
        assert(p.fen()==original);
        assert(p.key()==originalKey);
    }
}
int main(int argc,char**argv) {
    pieceMap.init();variants.init();CommandLine::init(argc,argv);UCI::init(Options);
    Options["UCI_Variant"]=std::string("capablanca10_escape");
    const Variant* v=variants.find("capablanca10_escape")->second;
    assert(v->endgameEval==NO_EG_EVAL);
    PSQT::init(v);Bitboards::init();Position::init();Bitbases::init();Endgames::init();
    Threads.set(1);Search::clear();Eval::NNUE::init();
    std::ifstream input(argv[1]);std::string fen;
    while(std::getline(input,fen)){
        Position p;StateInfo st{};p.set(v,fen,false,&st,Threads.main());
        visit(p,v,2);
    }
    std::cout<<"PASS "<<checked<<" make/undo/rebuild checks; "<<escapes<<" own captures; "<<triples<<" triple starts; hashes, material, checks, rights and counters consistent\n";
    Threads.set(0);variants.clear_all();pieceMap.clear_all();
}
