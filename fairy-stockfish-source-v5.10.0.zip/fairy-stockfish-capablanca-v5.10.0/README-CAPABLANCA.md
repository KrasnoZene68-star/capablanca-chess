# Capablanca Chess engine v5.10.0

Exact corresponding source for the distributed scalar WASM runtime.
Upstream: https://github.com/fairy-stockfish/fairy-stockfish.wasm
Upstream commit: b2e693ef1e111233ce3fb40685921708b3276ed6 (npm 1.1.12).
License: GPLv3, see Copying.txt. Authors: upstream AUTHORS plus project modifications.

Includes the emergency-king rule from v5.9.0 and the v5.10.0 10x10 extension.
Native variants: capablanca, capablanca_escape, capablanca10, capablanca10_escape.
Royal KN definitions are loaded inline by the game (see included variants.ini.example).

On 10x10, pawns start on ranks 2/9, promote on 10/1, and may move 1/2 squares
at the start, or 3 if that side has a remaining triple-start credit. Each side
starts with two credits. A triple needs all three squares empty. Both passed
squares permit en passant for the next ply. Ordinary starts spend no credit.
All four king rules are supported; emergency self-captures stay adjacent and
require no ordinary legal evasion plus target safety before and after the move.

The optional FEN field after the standard six is t<white>,<black>, e.g. t2,2
or t0,1. It records remaining credits. Omitted field defaults to the variant
limit. Counters are StateInfo fields, copied on make, restored on undo and null
moves, included in the full position hash. Triple movement region is disabled
when the mover's counter is zero. Extended EP hashes encode squares independently.
8x8-specific special endgame evaluations are disabled on these 10x10 variants.

Build natively with ./build-native.sh. Build WASM in a separate clean copy,
activate Emscripten 2.0.26, then ./build-wasm.sh. No SIMD or embedded NNUE.
Distribute src/emscripten/public/stockfish.{js,wasm,worker.js}; the worker must
include the upstream postamble. SHIPPED-RUNTIME-SHA256.json identifies outputs.
Cumulative patch: capablanca-all-changes.patch. Old emergency patch is retained
as historical documentation. No closed-source dependency is needed.

Verification: after native build, ./verification/run-state-test.sh checks the
10x10 FEN corpus, make/undo/FEN rebuild, full/pawn/material hashes, PSQT, checks,
null moves and triple budgets. Upstream perft runner is verification/perft-python.sh
(run from src), using the same upstream cases without the unavailable expect tool.
The playable package includes Node/WASM/application tests and recorded results.
