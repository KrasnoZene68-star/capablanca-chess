#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/src"
make -j2 build ARCH=x86-64 largeboards=yes nnue=no embedded_nnue=no debug=yes optimize=yes
