// Native 10-file implementation of the upstream Board interface.
// Built through board.cpp with -DCAPABLANCA_CORE. No reference Position is used.
// Original NNUE/search are deliberately not linked by the stage-24 target.
#include "board.h"
#include "variant_attacks.h"
#include <algorithm>
#include <array>
#include <cctype>
#include <limits>
#include <stdexcept>

namespace {
constexpr Hash mixKey(Hash x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}
Hash pieceKey(Color side, Piece piece, Square square) {
    return mixKey(1 + square + 100 * (int(piece) + 8 * int(side)));
}
constexpr char symbols[] = "pnbrqkac";
void requireNoNNUE(NNUE* nnue) {
    if (nnue) throw std::logic_error("8x8 NNUE cannot be used with CAPABLANCA_CORE");
}
uint32_t decimal(const std::string& s, uint32_t maximum) {
    if (s.empty()) throw std::invalid_argument("missing FEN number");
    uint64_t result = 0;
    for (unsigned char c : s) {
        if (!std::isdigit(c)) throw std::invalid_argument("invalid FEN number");
        result = result * 10 + c - '0';
        if (result > maximum) throw std::invalid_argument("FEN number out of range");
    }
    return uint32_t(result);
}
}

void Board::setVariant(int height, bool knightKing, bool escape) {
    if (height != 8 && height != 10) throw std::invalid_argument("board height must be 8 or 10");
    geometry = {10, height};
    kingKnight = knightKing;
    emergencyEscape = escape;
    startpos();
}

void Board::startpos() {
    std::string initial = "rnabqkbcnr/pppppppppp/";
    for (int r = 0; r < geometry.height - 4; ++r) initial += "10/";
    initial += "PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1";
    if (geometry.height == 10) initial += " t2,2";
    parseFen(initial, false);
}

void Board::parseFen(std::istringstream& input, bool isChess960) {
    if (isChess960) throw std::invalid_argument("Capablanca Chess960 is not supported");
    // Transactional parsing: failures do not corrupt a live Board.
    Board next{};
    next.geometry = geometry;
    next.kingKnight = kingKnight;
    next.emergencyEscape = emergencyEscape;
    next.chess960 = false;
    next.lastMove = Move::none();
    std::fill(std::begin(next.pieces), std::end(next.pieces), Piece::NONE);
    std::string placement, side, rights, ep, half, full, budget, extra;
    if (!(input >> placement >> side >> rights >> ep >> half >> full))
        throw std::invalid_argument("FEN requires six fields");
    input >> budget;
    if (input >> extra) throw std::invalid_argument("unexpected FEN field");
    next.stm = side == "w" ? WHITE : BLACK;
    if (side != "w" && side != "b") throw std::invalid_argument("invalid FEN side");
    next.rule50_ply = uint16_t(decimal(half, 65535));
    next.ply = decimal(full, std::numeric_limits<uint32_t>::max());
    if (!next.ply) throw std::invalid_argument("fullmove starts at one");
    if (!budget.empty()) {
        if (geometry.height != 10 || budget.size() != 4 || budget[0] != 't' ||
            budget[2] != ',' || budget[1] < '0' || budget[1] > '2' ||
            budget[3] < '0' || budget[3] > '2')
            throw std::invalid_argument("invalid triple-move budget");
        next.tripleRemaining[WHITE] = budget[1] - '0';
        next.tripleRemaining[BLACK] = budget[3] - '0';
    }
    int rank = geometry.height - 1, file = 0;
    for (size_t i = 0; i < placement.size();) {
        unsigned char c = placement[i++];
        if (c == '/') {
            if (file != 10 || rank == 0) throw std::invalid_argument("invalid FEN rank");
            --rank; file = 0;
        } else if (std::isdigit(c)) {
            size_t start = i - 1;
            while (i < placement.size() && std::isdigit(static_cast<unsigned char>(placement[i]))) ++i;
            unsigned empty = decimal(placement.substr(start, i - start), 10);
            if (!empty) throw std::invalid_argument("zero empty-square run");
            file += empty;
        } else {
            auto index = std::string(symbols).find(char(std::tolower(c)));
            if (index == std::string::npos || file >= 10) throw std::invalid_argument("invalid FEN piece");
            next.put(Piece(index), std::isupper(c) ? WHITE : BLACK, Square(rank * 10 + file++));
        }
        if (file > 10) throw std::invalid_argument("FEN rank overflow");
    }
    if (rank != 0 || file != 10) throw std::invalid_argument("incorrect FEN dimensions");
    for (Color color : {WHITE, BLACK}) {
        if (BB::popcount(next.byPiece[KING] & next.byColor[color]) != 1)
            throw std::invalid_argument("exactly one king per side is required");
        const int home = color == WHITE ? 0 : (geometry.height - 1) * 10;
        next.castlingSquares[2 * color] = Square(home + 9);
        next.castlingSquares[2 * color + 1] = Square(home);
    }
    if (rights != "-") for (char c : rights) {
        size_t index = std::string("KQkq").find(c);
        if (index == std::string::npos || (next.castling & (1 << index)))
            throw std::invalid_argument("invalid castling rights");
        next.castling |= 1 << index;
    }
    if (ep != "-") {
        size_t i = 0;
        while (i < ep.size()) {
            int f = ep[i++] - 'a';
            size_t start = i;
            while (i < ep.size() && std::isdigit(static_cast<unsigned char>(ep[i]))) ++i;
            int r = int(decimal(ep.substr(start, i - start), geometry.height)) - 1;
            if (f < 0 || f >= 10 || r < 0) throw std::invalid_argument("invalid en-passant square");
            Bitboard bit = bitboard(Square(r * 10 + f));
            if (next.enpassantTarget & bit) throw std::invalid_argument("duplicate en-passant square");
            next.enpassantTarget |= bit;
        }
        int count = BB::popcount(next.enpassantTarget);
        if (count > (geometry.height == 10 ? 2 : 1)) throw std::invalid_argument("too many en-passant targets");
        Square near = next.stm == WHITE ? lsb(next.enpassantTarget) : msb(next.enpassantTarget);
        int captured = int(near) + (next.stm == WHITE ? -10 : 10);
        if (!geometry.valid(captured)) throw std::invalid_argument("invalid en-passant victim");
        next.enpassantCaptured = Square(captured);
        if (count == 2 && msb(next.enpassantTarget) - lsb(next.enpassantTarget) != 10)
            throw std::invalid_argument("nonadjacent triple en-passant targets");
    }
    next.rebuildHashes();
    next.refreshDerived();
    *this = next;
}

std::string Board::fen() {
    std::ostringstream out;
    for (int r = geometry.height - 1; r >= 0; --r) {
        int empty = 0;
        for (int f = 0; f < 10; ++f) {
            Square s = Square(r * 10 + f);
            if (pieces[s] == NONE) { ++empty; continue; }
            if (empty) { out << empty; empty = 0; }
            char c = symbols[pieces[s]];
            out << char(byColor[WHITE] & bitboard(s) ? std::toupper(c) : c);
        }
        if (empty) out << empty;
        if (r) out << '/';
    }
    out << (stm == WHITE ? " w " : " b ");
    if (!castling) out << '-';
    else for (int i = 0; i < 4; ++i) if (castling & (1 << i)) out << "KQkq"[i];
    out << ' ';
    if (!enpassantTarget) out << '-';
    for (Bitboard targets = enpassantTarget; targets;) out << popLSB(&targets);
    out << ' ' << rule50_ply << ' ' << ply;
    if (geometry.height == 10) out << " t" << int(tripleRemaining[0]) << ',' << int(tripleRemaining[1]);
    return out.str();
}

void Board::updatePieceHash(Piece p, Color color, uint64_t delta) {
    hashes.hash ^= delta;
    if (p == PAWN) hashes.pawnHash ^= delta;
    else hashes.nonPawnHash[color] ^= delta;
    if (p == KNIGHT || p == BISHOP || p == ARCHBISHOP || p == KING) hashes.minorHash ^= delta;
    if (p == ROOK || p == QUEEN || p == CHANCELLOR || p == KING) hashes.majorHash ^= delta;
}
void Board::put(Piece p, Color color, Square s) {
    assert(geometry.valid(s) && pieces[s] == NONE && p < TOTAL);
    pieces[s] = p;
    byPiece[p] |= bitboard(s);
    byColor[color] |= bitboard(s);
    updatePieceHash(p, color, pieceKey(color, p, s));
}
void Board::erase(Square s) {
    assert(geometry.valid(s) && pieces[s] != NONE);
    Color color = (byColor[WHITE] & bitboard(s)) ? WHITE : BLACK;
    Piece p = pieces[s];
    updatePieceHash(p, color, pieceKey(color, p, s));
    byColor[color] &= ~bitboard(s);
    byPiece[p] &= ~bitboard(s);
    pieces[s] = NONE;
}
void Board::rebuildHashes() {
    hashes = {};
    for (int s = 0; s < geometry.count(); ++s) if (pieces[s] != NONE) {
        Color c = byColor[WHITE] & bitboard(Square(s)) ? WHITE : BLACK;
        updatePieceHash(pieces[s], c, pieceKey(c, pieces[s], Square(s)));
    }
    hashes.hash ^= stateHash();
}

Bitboard Board::attacksFrom(Square s, Bitboard occupied) const {
    using namespace VariantAttacks;
    switch (pieces[s]) {
    case PAWN: return pawn(geometry, s, bool(byColor[WHITE] & bitboard(s)));
    case KNIGHT: return knight(geometry, s);
    case BISHOP: return bishop(geometry, s, occupied);
    case ROOK: return rook(geometry, s, occupied);
    case QUEEN: return queen(geometry, s, occupied);
    case KING: return king(geometry, s, kingKnight);
    case ARCHBISHOP: return archbishop(geometry, s, occupied);
    case CHANCELLOR: return chancellor(geometry, s, occupied);
    default: return 0;
    }
}
Bitboard Board::attackersTo(Square s, Bitboard occupied) {
    Bitboard attackers = 0, candidates = (byColor[WHITE] | byColor[BLACK]) & occupied;
    while (candidates) {
        Square from = popLSB(&candidates);
        if (attacksFrom(from, occupied) & bitboard(s)) attackers |= bitboard(from);
    }
    return attackers;
}
Bitboard Board::attackersTo(Square s) { return attackersTo(s, byColor[WHITE] | byColor[BLACK]); }
bool Board::kingInCheck(Color side) const {
    Bitboard king = byPiece[KING] & byColor[side];
    assert(BB::popcount(king) == 1);
    Bitboard enemies = byColor[flip(side)], occupied = byColor[WHITE] | byColor[BLACK];
    while (enemies) if (attacksFrom(popLSB(&enemies), occupied) & king) return true;
    return false;
}
void Board::calculateThreats() {
    threats = {};
    Bitboard enemies = byColor[flip(stm)], occupied = byColor[WHITE] | byColor[BLACK];
    while (enemies) {
        Square s = popLSB(&enemies);
        Bitboard attacks = attacksFrom(s, occupied);
        threats.allThreats |= attacks;
        switch (pieces[s]) {
        case PAWN: threats.pawnThreats |= attacks; break;
        case KNIGHT: threats.knightThreats |= attacks; break;
        case BISHOP: threats.bishopThreats |= attacks; break;
        case ROOK: threats.rookThreats |= attacks; break;
        case QUEEN: threats.queenThreats |= attacks; break;
        case KING: threats.kingThreats |= attacks; break;
        case ARCHBISHOP: threats.archbishopThreats |= attacks; break;
        case CHANCELLOR: threats.chancellorThreats |= attacks; break;
        default: break;
        }
    }
}
void Board::updateSliderPins(Color side) {
    blockers[side] = 0;
    Square king = lsb(byPiece[KING] & byColor[side]);
    constexpr int dirs[8][2] = {{1,0},{-1,0},{0,1},{0,-1},{1,1},{-1,1},{1,-1},{-1,-1}};
    for (int d = 0; d < 8; ++d) {
        int f = fileOf(king), r = rankOf(king);
        Square candidate = NO_SQUARE;
        while (VariantAttacks::inBounds(geometry, f += dirs[d][0], r += dirs[d][1])) {
            Square s = Square(r * 10 + f);
            if (pieces[s] == NONE) continue;
            if (candidate == NO_SQUARE) { candidate = s; continue; }
            Piece p = pieces[s];
            bool slider = p == QUEEN || (d < 4 ? p == ROOK || p == CHANCELLOR : p == BISHOP || p == ARCHBISHOP);
            if (slider && (byColor[flip(side)] & bitboard(s))) blockers[side] |= bitboard(candidate);
            break;
        }
    }
}
void Board::refreshDerived() {
    checkers = attackersTo(lsb(byPiece[KING] & byColor[stm])) & byColor[flip(stm)];
    checkerCount = uint8_t(BB::popcount(checkers));
    updateSliderPins(WHITE);
    updateSliderPins(BLACK);
    calculateThreats();
}
bool Board::isSquareThreatened(Square s) { return bool(threats.allThreats & bitboard(s)); }

std::vector<Move> Board::regularCandidates() const {
    std::vector<Move> result;
    const Bitboard own = byColor[stm], enemy = byColor[flip(stm)], occupied = own | enemy;
    const Bitboard enemyKing = byPiece[KING] & enemy;
    const int step = stm == WHITE ? 10 : -10;
    auto pawnMove = [&](Square from, Square to) {
        if (rankOf(to) == (stm == WHITE ? geometry.height - 1 : 0))
            for (Piece p : {KNIGHT, BISHOP, ROOK, QUEEN, ARCHBISHOP, CHANCELLOR}) result.push_back(Move::makePromotion(from, to, p));
        else result.push_back(Move::makeNormal(from, to));
    };
    Bitboard origins = own;
    while (origins) {
        Square from = popLSB(&origins);
        if (pieces[from] == PAWN) {
            int to = from + step;
            if (!geometry.valid(to)) continue;
            if (pieces[to] == NONE) {
                pawnMove(from, Square(to));
                if (rankOf(from) == (stm == WHITE ? 1 : geometry.height - 2) && pieces[to + step] == NONE) {
                    result.push_back(Move::makeNormal(from, Square(to + step)));
                    if (geometry.height == 10 && tripleRemaining[stm] && pieces[to + 2 * step] == NONE)
                        result.push_back(Move::makeNormal(from, Square(to + 2 * step)));
                }
            }
            Bitboard attacks = attacksFrom(from, occupied), captures = attacks & enemy & ~enemyKing;
            while (captures) pawnMove(from, popLSB(&captures));
            if (enpassantCaptured < geometry.count() && pieces[enpassantCaptured] == PAWN &&
                (enemy & bitboard(enpassantCaptured))) {
                Bitboard ep = attacks & enpassantTarget & ~occupied;
                while (ep) result.push_back(Move::makeEnpassant(from, popLSB(&ep)));
            }
        } else {
            Bitboard targets = attacksFrom(from, occupied) & ~own & ~enemyKing;
            while (targets) result.push_back(Move::makeNormal(from, popLSB(&targets)));
        }
    }
    int home = stm == WHITE ? 0 : (geometry.height - 1) * 10;
    Square king = Square(home + 5);
    if (pieces[king] == KING && (own & bitboard(king)) && !kingInCheck(stm)) {
        for (auto direction : {Castling::KINGSIDE, Castling::QUEENSIDE}) {
            if (!(castling & Castling::getMask(stm, direction))) continue;
            Square rook = castlingSquares[2 * stm + direction];
            if (pieces[rook] != ROOK || !(own & bitboard(rook))) continue;
            bool clear = true;
            int delta = direction == Castling::KINGSIDE ? 1 : -1;
            for (int s = king + delta; s != rook; s += delta) if (pieces[s] != NONE) clear = false;
            // Test transit with the king removed from its source, so it cannot hide a ray.
            int target = Castling::getKingSquare(stm, direction, geometry.height);
            for (int s = king + delta; clear && s != target + delta; s += delta)
                clear = safeAfter(Move::makeNormal(king, Square(s)));
            if (clear) result.push_back(Move::makeCastling(king, rook)); // upstream king-to-rook encoding
        }
    }
    return result;
}
bool Board::safeAfter(Move move) const {
    Board next = *this;
    next.applyUnchecked(move);
    return !next.kingInCheck(stm);
}
std::vector<Move> Board::legalMoves() const {
    std::vector<Move> result;
    for (Move m : regularCandidates()) if (safeAfter(m)) result.push_back(m);
    if (!result.empty() || !emergencyEscape || !kingInCheck(stm)) return result;
    Square king = lsb(byPiece[KING] & byColor[stm]);
    Bitboard targets = VariantAttacks::king(geometry, king, false) & byColor[stm] & ~byPiece[KING];
    while (targets) {
        Square to = popLSB(&targets);
        // Preserve the game's extra pre-move safety check for emergency replacement.
        bool attacked = false;
        Bitboard enemies = byColor[flip(stm)], occupied = byColor[WHITE] | byColor[BLACK];
        while (enemies) attacked |= bool(attacksFrom(popLSB(&enemies), occupied) & bitboard(to));
        Move m = Move::makeEmergency(king, to);
        if (!attacked && safeAfter(m)) result.push_back(m);
    }
    return result;
}
bool Board::isPseudoLegal(Move move) {
    if (!move) return false;
    if (move.isEmergency()) return isLegal(move); // must establish absence of regular evasions
    auto candidates = regularCandidates();
    return std::find(candidates.begin(), candidates.end(), move) != candidates.end();
}
bool Board::isLegal(Move move) {
    if (!move) return false;
    auto moves = legalMoves();
    return std::find(moves.begin(), moves.end(), move) != moves.end();
}

void Board::updatePieceCastling(Piece p, Color side, Square s) {
    if (p == KING) castling &= ~Castling::getMask(side);
    for (auto direction : {Castling::KINGSIDE, Castling::QUEENSIDE})
        if (s == castlingSquares[2 * side + direction]) castling &= ~Castling::getMask(side, direction);
}
void Board::applyUnchecked(Move m) {
    const Square from = m.origin(), to = m.target();
    const Piece moving = pieces[from];
    const bool captured = !m.isCastling() && (pieces[to] != NONE || m.isEnpassant());
    const Square oldEpVictim = enpassantCaptured;
    enpassantTarget = 0;
    enpassantCaptured = NO_SQUARE;
    updatePieceCastling(moving, stm, from);
    if (m.isCastling()) {
        auto direction = Castling::getDirection(from, to);
        erase(from); erase(to);
        put(KING, stm, Castling::getKingSquare(stm, direction, geometry.height));
        put(ROOK, stm, Castling::getRookSquare(stm, direction, geometry.height));
    } else {
        if (m.isEnpassant()) erase(oldEpVictim);
        if (pieces[to] != NONE) {
            Color victimSide = byColor[WHITE] & bitboard(to) ? WHITE : BLACK;
            updatePieceCastling(pieces[to], victimSide, to);
            erase(to);
        }
        erase(from);
        put(m.isPromotion() ? m.promotionPiece() : moving, stm, to);
        if (moving == PAWN && std::abs(int(to) - int(from)) >= 20) {
            int step = stm == WHITE ? 10 : -10;
            for (int s = from + step; s != to; s += step) enpassantTarget |= bitboard(Square(s));
            enpassantCaptured = to;
            if (std::abs(int(to) - int(from)) == 30) { assert(tripleRemaining[stm]); --tripleRemaining[stm]; }
        }
    }
    rule50_ply = moving == PAWN || captured ? 0 : uint16_t(std::min(65535, int(rule50_ply) + 1));
    nullmove_ply = uint16_t(std::min(65535, int(nullmove_ply) + 1));
    if (stm == BLACK && ply != std::numeric_limits<uint32_t>::max()) ++ply;
    stm = flip(stm);
    lastMove = m;
}
Hash Board::stateHash() const {
    Hash hash = mixKey(2000 + geometry.height + 16 * int(kingKnight) + 32 * int(emergencyEscape));
    if (stm == BLACK) hash ^= mixKey(2100);
    hash ^= mixKey(2200 + castling);
    if (geometry.height == 10) hash ^= mixKey(2300 + tripleRemaining[0] + 3 * tripleRemaining[1]);
    // Normalize EP for repetition: a pinned/nonexistent capture adds no key.
    if (enpassantTarget && enpassantCaptured < geometry.count() && pieces[enpassantCaptured] == PAWN &&
        (byColor[flip(stm)] & bitboard(enpassantCaptured))) {
        Bitboard targets = enpassantTarget & ~(byColor[WHITE] | byColor[BLACK]);
        while (targets) {
            Square target = popLSB(&targets);
            Bitboard pawns = byPiece[PAWN] & byColor[stm];
            bool legal = false;
            while (pawns && !legal) {
                Square from = popLSB(&pawns);
                if (VariantAttacks::pawn(geometry, from, stm == WHITE) & bitboard(target))
                    legal = safeAfter(Move::makeEnpassant(from, target));
            }
            if (legal) hash ^= mixKey(3000 + target + 100 * enpassantCaptured);
        }
    }
    return hash;
}
Hash Board::rule50Hash() const { return hashes.hash ^ mixKey(14000 + std::min(100, int(rule50_ply))); }
void Board::doMove(Move move, Hash newHash, NNUE* nnue) {
    requireNoNNUE(nnue);
    hashes.hash ^= stateHash();
    applyUnchecked(move);
    hashes.hash ^= stateHash();
    assert(!newHash || hashes.hash == newHash);
    (void)newHash;
    refreshDerived();
}
void Board::makeMove(Move move) {
    if (!isLegal(move)) throw std::invalid_argument("illegal move");
    doMove(move, 0, nullptr);
}
std::pair<Hash, Hash> Board::hashAfter(Move move) {
    Board next = *this;
    next.doMove(move, 0, nullptr);
    return {next.hashes.hash, next.rule50Hash()};
}
void Board::doNullMove() {
    if (kingInCheck(stm)) throw std::invalid_argument("null move in check");
    hashes.hash ^= stateHash();
    enpassantTarget = 0; enpassantCaptured = NO_SQUARE;
    stm = flip(stm);
    rule50_ply = uint16_t(std::min(65535, int(rule50_ply) + 1));
    nullmove_ply = 0;
    lastMove = Move::none();
    hashes.hash ^= stateHash();
    refreshDerived();
}
bool Board::givesCheck(Move move) {
    Board next = *this;
    next.applyUnchecked(move);
    return next.kingInCheck(next.stm);
}

int Board::validateBoard() {
    Bitboard piecesSeen[TOTAL]{};
    const Bitboard occupied = byColor[WHITE] | byColor[BLACK];
    const Bitboard mask = (Bitboard(1) << geometry.count()) - 1;
    if ((byColor[WHITE] & byColor[BLACK]) || (occupied & ~mask)) return 1;
    for (int s = 0; s < BOARD_CAPACITY; ++s) {
        if (pieces[s] == NONE) { if (occupied & bitboard(Square(s))) return 2; continue; }
        if (!geometry.valid(s) || pieces[s] >= TOTAL || !(occupied & bitboard(Square(s)))) return 3;
        piecesSeen[pieces[s]] |= bitboard(Square(s));
    }
    for (Piece p = PAWN; p < TOTAL; ++p) if (piecesSeen[p] != byPiece[p]) return 4;
    for (Color side : {WHITE, BLACK}) if (BB::popcount(byColor[side] & byPiece[KING]) != 1) return 5;
    Board rebuilt = *this;
    rebuilt.rebuildHashes(); rebuilt.refreshDerived();
    if (rebuilt.hashes.hash != hashes.hash || rebuilt.hashes.pawnHash != hashes.pawnHash ||
        rebuilt.hashes.nonPawnHash[0] != hashes.nonPawnHash[0] || rebuilt.hashes.nonPawnHash[1] != hashes.nonPawnHash[1] ||
        rebuilt.hashes.minorHash != hashes.minorHash || rebuilt.hashes.majorHash != hashes.majorHash) return 6;
    if (rebuilt.checkers != checkers || rebuilt.checkerCount != checkerCount ||
        rebuilt.blockers[0] != blockers[0] || rebuilt.blockers[1] != blockers[1] ||
        rebuilt.threats.allThreats != threats.allThreats) return 7;
    return 0;
}
void Board::debugBoard() { std::cout << fen() << '\n'; }

void generateMoves(Board* board, MoveList& moves, bool onlyCaptures) {
    for (Move m : board->legalMoves()) if (!onlyCaptures || board->isCapture(m)) moves.add(m);
}
Square stringToSquare(const char* text) {
    if (!text || text[0] < 'a' || text[0] > 'j') return NO_SQUARE;
    std::string rank(text + 1);
    if (rank != "1" && rank != "2" && rank != "3" && rank != "4" && rank != "5" &&
        rank != "6" && rank != "7" && rank != "8" && rank != "9" && rank != "10") return NO_SQUARE;
    return Square((std::stoi(rank) - 1) * 10 + text[0] - 'a');
}
Move stringToMove(const char* text, Board* board) {
    if (!text) return Move::none();
    for (Move m : board->legalMoves()) if (m.toString(false) == text) return m;
    return Move::none();
}
