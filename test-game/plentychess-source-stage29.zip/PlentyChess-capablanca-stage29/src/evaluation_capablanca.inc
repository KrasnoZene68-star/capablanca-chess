// Temporary, explicitly non-NNUE evaluation for the native core port.
// Material constants are initial estimates, not tuned PlentyChess weights.
#include "evaluation.h"
#include <algorithm>
#include <stdexcept>

int PIECE_VALUES[Piece::TOTAL + 1] = {100, 315, 340, 530, 1000, 0, 725, 835, 0};

Eval evaluate(Board* board, NNUE* nnue, std::array<int, 2>& optimism) {
    if (nnue) throw std::logic_error("Capablanca evaluation does not accept the 8x8 NNUE");
    int whiteScore = 0;
    Bitboard occupied = board->byColor[WHITE] | board->byColor[BLACK];
    while (occupied) {
        Square s = popLSB(&occupied);
        Piece p = board->pieces[s];
        bool white = bool(board->byColor[WHITE] & bitboard(s));
        int rank = white ? rankOf(s) : board->geometry.height - 1 - rankOf(s);
        int center = 8 - (std::abs(2 * fileOf(s) - 9) + std::abs(2 * rankOf(s) - (board->geometry.height - 1))) / 3;
        int positional = p == PAWN ? rank * 3 : center * 2;
        whiteScore += (white ? 1 : -1) * (PIECE_VALUES[p] + positional);
    }
    (void)optimism; // 8x8 tuning is not transferable to this baseline evaluator.
    int value = (board->stm == WHITE ? whiteScore : -whiteScore) + 8;
    return Eval(std::clamp(value, -int(EVAL_TBWIN_IN_MAX_PLY) + 1, int(EVAL_TBWIN_IN_MAX_PLY) - 1));
}

std::string formatEval(Eval value) {
    if (value >= EVAL_MATE_IN_MAX_PLY) return "mate " + std::to_string((EVAL_MATE - value) / 2 + 1);
    if (value <= -EVAL_MATE_IN_MAX_PLY) return "mate " + std::to_string(-(EVAL_MATE + value) / 2);
    // Baseline evaluation uses centipawns directly, not the original NNUE's scale.
    return "cp " + std::to_string(value);
}

int staticExchangeValue(Board* board, Move move) {
    assert(move && board->isPseudoLegal(move));
    if (move.isCastling()) return 0;
    const Square target = move.target();
    int gains[BOARD_CAPACITY + 1]{};
    gains[0] = move.isEnpassant() ? PIECE_VALUES[PAWN] : PIECE_VALUES[board->pieces[target]];
    if (move.isEmergency()) gains[0] = -gains[0];
    if (move.isPromotion()) gains[0] += PIECE_VALUES[move.promotionPiece()] - PIECE_VALUES[PAWN];
    Board exchange = *board;
    exchange.applyUnchecked(move);
    int depth = 0;
    // Unlike enum order, this is sorted by the actual initial material values.
    constexpr Piece order[] = {PAWN, KNIGHT, BISHOP, ROOK, ARCHBISHOP, CHANCELLOR, QUEEN, KING};
    while (exchange.pieces[target] != KING) {
        Bitboard attackers = exchange.attackersTo(target) & exchange.byColor[exchange.stm];
        Move chosen = Move::none();
        for (Piece p : order) {
            Bitboard candidates = attackers & exchange.byPiece[p];
            while (candidates) {
                Square origin = popLSB(&candidates);
                bool promote = p == PAWN && rankOf(target) == (exchange.stm == WHITE ? exchange.geometry.height - 1 : 0);
                Move candidate = promote ? Move::makePromotion(origin, target, QUEEN) : Move::makeNormal(origin, target);
                if (exchange.safeAfter(candidate)) { chosen = candidate; break; }
            }
            if (chosen) break;
        }
        if (!chosen) break;
        int captured = PIECE_VALUES[exchange.pieces[target]];
        if (chosen.isPromotion()) captured += PIECE_VALUES[QUEEN] - PIECE_VALUES[PAWN];
        ++depth;
        assert(depth <= BOARD_CAPACITY);
        gains[depth] = captured - gains[depth - 1];
        exchange.applyUnchecked(chosen);
    }
    while (depth > 0) {
        gains[depth - 1] = -std::max(-gains[depth - 1], gains[depth]);
        --depth;
    }
    return gains[0];
}

bool SEE(Board* board, Move move, int threshold) {
    assert(move && board->isPseudoLegal(move));
    // Preserve upstream's conservative no-pruning policy for special moves.
    // In particular, do not prune the sole emergency evasion for losing material.
    if (move.isSpecial()) return true;
    return staticExchangeValue(board, move) >= threshold;
}
