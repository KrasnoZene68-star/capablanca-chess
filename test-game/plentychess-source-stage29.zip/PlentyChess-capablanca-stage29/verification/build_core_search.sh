#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
output="${1:-/tmp/plenty-core26-cli}"
"${CXX:-g++}" -std=c++17 -DCAPABLANCA_CORE -O2 -pthread \
 verification/core_search_cli.cpp src/board.cpp src/move.cpp src/history.cpp \
 src/evaluation.cpp src/search.cpp src/tt.cpp src/time.cpp src/core_worker.cpp -o "$output"
echo "$output"
