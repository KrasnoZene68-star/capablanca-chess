//! Capablanca adaptation, 2026-09-22. Legal moves at every Reckless search node.
use crate::{lookup::*, types::*};
#[derive(Clone, Copy)]
struct Position {
    mailbox: [Piece; 100],
    pieces: [Bitboard; 8],
    colors: [Bitboard; 2],
    kings: [Square; 2],
    rows: u8,
    rule: u8,
    side: Color,
    rights: u8,
    ep: Bitboard,
    ep_victim: Square,
    triple: [u8; 2],
    half: u8,
    full: usize,
    keys: Keys,
    captured: Piece,
    null_position: bool,
}
impl Position {
    fn empty(rows: u8, rule: u8) -> Self {
        Self {
            mailbox: [Piece::None; 100],
            pieces: [Bitboard(0); 8],
            colors: [Bitboard(0); 2],
            kings: [Square::None; 2],
            rows,
            rule,
            side: Color::White,
            rights: 0,
            ep: Bitboard(0),
            ep_victim: Square::None,
            triple: [if rows == 10 { 2 } else { 0 }; 2],
            half: 0,
            full: 1,
            keys: Keys::default(),
            captured: Piece::None,
            null_position: false,
        }
    }
    fn mask(&self) -> Bitboard {
        Bitboard((1u128 << (self.rows * 10)) - 1)
    }
    fn occ(&self) -> Bitboard {
        self.colors[0] | self.colors[1]
    }
    fn remove(&mut self, s: Square) -> Piece {
        let p = self.mailbox[s];
        if p != Piece::None {
            self.pieces[p.piece_type()].clear(s);
            self.colors[p.color()].clear(s);
            self.keys.toggle(p, s);
            self.mailbox[s] = Piece::None;
        }
        p
    }
    fn add(&mut self, p: Piece, s: Square) {
        debug_assert!(self.mailbox[s] == Piece::None);
        self.mailbox[s] = p;
        self.pieces[p.piece_type()].set(s);
        self.colors[p.color()].set(s);
        self.keys.toggle(p, s);
        if p.piece_type() == PieceType::King {
            self.kings[p.color()] = s;
        }
    }
    fn royal_knight(&self) -> bool {
        self.rule & 1 != 0
    }
    fn emergency(&self) -> bool {
        self.rule & 2 != 0
    }
    fn attacks_from(&self, s: Square) -> Bitboard {
        let p = self.mailbox[s];
        let mut a = attacks(p, s, self.occ());
        if p.piece_type() == PieceType::King && self.royal_knight() {
            a |= knight_attacks(s)
        }
        a & self.mask()
    }
    fn attackers(&self, s: Square, c: Color) -> Bitboard {
        let n =
            self.pieces[PieceType::Knight] | self.pieces[PieceType::Archbishop] | self.pieces[PieceType::Chancellor];
        let b = self.pieces[PieceType::Bishop] | self.pieces[PieceType::Queen] | self.pieces[PieceType::Archbishop];
        let r = self.pieces[PieceType::Rook] | self.pieces[PieceType::Queen] | self.pieces[PieceType::Chancellor];
        let mut a = (pawn_attacks(s, !c) & self.pieces[PieceType::Pawn])
            | (knight_attacks(s) & n)
            | (bishop_attacks(s, self.occ()) & b)
            | (rook_attacks(s, self.occ()) & r)
            | (king_attacks(s) & self.pieces[PieceType::King]);
        if self.royal_knight() {
            a |= knight_attacks(s) & self.pieces[PieceType::King]
        }
        a & self.colors[c]
    }
    fn attacked(&self, s: Square, c: Color) -> bool {
        !self.attackers(s, c).is_empty()
    }
    fn threatened(&self, c: Color, pt: Option<PieceType>) -> Bitboard {
        let mut a = Bitboard(0);
        let bb = if let Some(t) = pt { self.colors[c] & self.pieces[t] } else { self.colors[c] };
        for s in bb {
            a |= self.attacks_from(s)
        }
        a
    }
    fn in_check(&self) -> bool {
        self.attacked(self.kings[self.side], !self.side)
    }
    fn clear_rook_right(&mut self, s: Square) {
        let top = (self.rows - 1) * 10;
        if s as u8 == 0 {
            self.rights &= !2
        }
        if s as u8 == 9 {
            self.rights &= !1
        }
        if s as u8 == top {
            self.rights &= !8
        }
        if s as u8 == top + 9 {
            self.rights &= !4
        }
    }
    fn apply(&mut self, m: Move) {
        let c = self.side;
        let p = self.mailbox[m.from()];
        let victim = if m.is_en_passant() { m.capture_sq() } else { m.to() };
        self.captured = self.remove(victim);
        self.clear_rook_right(victim);
        self.clear_rook_right(m.from());
        self.remove(m.from());
        self.add(if m.is_promotion() { Piece::new(c, m.promo_piece_type()) } else { p }, m.to());
        if p.piece_type() == PieceType::King {
            self.rights &= if c == Color::White { 12 } else { 3 };
        }
        if m.is_castling() {
            let rank = m.to().rank() as u8;
            let short = m.to().file() as u8 == 8;
            let rf = Square::from_rank_file(rank, if short { 9 } else { 0 });
            let rt = Square::from_rank_file(rank, if short { 7 } else { 3 });
            let rook = self.remove(rf);
            self.add(rook, rt);
        }
        self.ep = Bitboard(0);
        self.ep_victim = Square::None;
        if p.piece_type() == PieceType::Pawn && (m.to() as i16 - m.from() as i16).abs() >= 20 {
            let step = if c == Color::White { 10 } else { -10 };
            let mut s = m.from().shift(step);
            while s != m.to() {
                self.ep.set(s);
                s = s.shift(step)
            }
            self.ep_victim = m.to();
            if matches!(m.kind(), MoveKind::TriplePush) {
                self.triple[c] -= 1;
            }
        }
        self.half = if p.piece_type() == PieceType::Pawn || self.captured != Piece::None {
            0
        } else {
            self.half.saturating_add(1)
        };
        if c == Color::Black {
            self.full += 1;
        }
        self.side = !c;
        self.null_position = false;
    }
    fn safe_move(&self, m: Move) -> bool {
        let mut p = *self;
        p.apply(m);
        !p.attacked(p.kings[self.side], !self.side)
    }
    fn push_safe(&self, l: &mut MoveList, m: Move) {
        if self.safe_move(m) {
            l.push_move(m)
        }
    }
    fn promo(&self, l: &mut MoveList, f: Square, t: Square, capture: bool) {
        let ks = if capture {
            [
                MoveKind::PromotionCaptureQ,
                MoveKind::PromotionCaptureC,
                MoveKind::PromotionCaptureA,
                MoveKind::PromotionCaptureR,
                MoveKind::PromotionCaptureB,
                MoveKind::PromotionCaptureN,
            ]
        } else {
            [
                MoveKind::PromotionQ,
                MoveKind::PromotionC,
                MoveKind::PromotionA,
                MoveKind::PromotionR,
                MoveKind::PromotionB,
                MoveKind::PromotionN,
            ]
        };
        for k in ks {
            self.push_safe(l, Move::new(f, t, k));
        }
    }
    fn ordinary(&self) -> MoveList {
        let mut l = MoveList::new();
        let c = self.side;
        let their = self.colors[!c] & !self.pieces[PieceType::King];
        for f in self.colors[c] {
            let pt = self.mailbox[f].piece_type();
            if pt == PieceType::Pawn {
                let dr = if c == Color::White { 1 } else { -1 };
                let rank = f.rank() as i8;
                let nr = rank + dr;
                if nr < 0 || nr >= self.rows as i8 {
                    continue;
                }
                let t = Square::from_rank_file(nr as u8, f.file() as u8);
                let promotes = nr == 0 || nr == self.rows as i8 - 1;
                if self.mailbox[t] == Piece::None {
                    if promotes {
                        self.promo(&mut l, f, t, false)
                    } else {
                        self.push_safe(&mut l, Move::new(f, t, MoveKind::Normal));
                    }
                    if rank == if c == Color::White { 1 } else { self.rows as i8 - 2 } {
                        let two = t.shift(dr * 10);
                        if self.mailbox[two] == Piece::None {
                            self.push_safe(&mut l, Move::new(f, two, MoveKind::DoublePush));
                            if self.rows == 10 && self.triple[c] > 0 {
                                let three = two.shift(dr * 10);
                                if self.mailbox[three] == Piece::None {
                                    self.push_safe(&mut l, Move::new(f, three, MoveKind::TriplePush));
                                }
                            }
                        }
                    }
                }
                for t in pawn_attacks(f, c) & their {
                    if promotes {
                        self.promo(&mut l, f, t, true)
                    } else {
                        self.push_safe(&mut l, Move::new(f, t, MoveKind::Capture));
                    }
                }
                for t in pawn_attacks(f, c) & self.ep {
                    if self.mailbox[t] == Piece::None
                        && self.ep_victim != Square::None
                        && self.mailbox[self.ep_victim] == Piece::new(!c, PieceType::Pawn)
                    {
                        self.push_safe(&mut l, Move::en_passant(f, t, self.ep_victim));
                    }
                }
            } else {
                for t in self.attacks_from(f) & !self.colors[c] & !self.pieces[PieceType::King] {
                    self.push_safe(
                        &mut l,
                        Move::new(
                            f,
                            t,
                            if self.mailbox[t] == Piece::None { MoveKind::Normal } else { MoveKind::Capture },
                        ),
                    );
                }
                if pt == PieceType::King {
                    self.castles(&mut l, f);
                }
            }
        }
        l
    }
    fn castles(&self, l: &mut MoveList, from: Square) {
        let c = self.side;
        let rank = if c == Color::White { 0 } else { self.rows - 1 };
        if from != Square::from_rank_file(rank, 5) || self.in_check() {
            return;
        }
        for short in [false, true] {
            let right = if c == Color::White {
                if short { 1 } else { 2 }
            } else if short {
                4
            } else {
                8
            };
            if self.rights & right == 0 {
                continue;
            }
            let rf = Square::from_rank_file(rank, if short { 9 } else { 0 });
            if self.mailbox[rf] != Piece::new(c, PieceType::Rook) {
                continue;
            }
            let files = if short { 6..9 } else { 1..5 };
            if files.clone().any(|f| self.mailbox[Square::from_rank_file(rank, f)] != Piece::None) {
                continue;
            }
            let route = if short { 6..9 } else { 2..5 };
            let mut clear = true;
            for f in route {
                let t = Square::from_rank_file(rank, f);
                let mut p = *self;
                p.remove(from);
                p.add(Piece::new(c, PieceType::King), t);
                if p.attacked(t, !c) {
                    clear = false;
                    break;
                }
            }
            if clear {
                self.push_safe(
                    l,
                    Move::new(from, Square::from_rank_file(rank, if short { 8 } else { 2 }), MoveKind::Castling),
                );
            }
        }
    }
    fn legal(&self) -> MoveList {
        let mut l = self.ordinary();
        if l.is_empty() && self.emergency() && self.in_check() {
            let f = self.kings[self.side];
            for t in king_attacks(f) & self.colors[self.side] & !self.pieces[PieceType::King] {
                // Adjacent own victim must be unattacked before, king must be safe after.
                if !self.attacked(t, !self.side) {
                    self.push_safe(&mut l, Move::new(f, t, MoveKind::Emergency));
                }
            }
        }
        l
    }
    fn effective_ep(&self) -> Bitboard {
        let mut out = Bitboard(0);
        if self.ep_victim == Square::None {
            return out;
        }
        for t in self.ep {
            for f in pawn_attacks(t, !self.side) & self.colors[self.side] & self.pieces[PieceType::Pawn] {
                if self.safe_move(Move::en_passant(f, t, self.ep_victim)) {
                    out.set(t);
                    break;
                }
            }
        }
        out
    }
    fn repetition_key(&self) -> u64 {
        let mut k = self.keys.full
            ^ ZOBRIST.castling[self.rights as usize]
            ^ mix(4000 + self.rows as u64 * 8 + self.rule as u64)
            ^ mix(5000 + self.triple[0] as u64 * 3 + self.triple[1] as u64);
        if self.side == Color::Black {
            k ^= ZOBRIST.side
        }
        for s in self.effective_ep() {
            k ^= ZOBRIST.en_passant[s]
        }
        k
    }
}
#[derive(Clone)]
pub struct Board {
    p: Position,
    stack: Vec<Position>,
    repetitions: Vec<u64>,
    key: u64,
}
impl Default for Board {
    fn default() -> Self {
        Self::starting_position()
    }
}
impl Board {
    pub fn starting_position() -> Self {
        Self::from_fen("rnabqkbcnr/pppppppppp/10/10/10/10/PPPPPPPPPP/RNABQKBCNR w KQkq - 0 1").unwrap()
    }
    pub fn from_fen(fen: &str) -> Result<Self, String> {
        Self::from_variant_fen(fen, 0)
    }
    pub fn from_variant_fen(fen: &str, rule: u8) -> Result<Self, String> {
        if rule > 3 {
            return Err("Unknown variant".into());
        }
        let f: Vec<_> = fen.split_whitespace().collect();
        if f.len() < 6 {
            return Err("Incomplete FEN".into());
        }
        let ranks: Vec<_> = f[0].split('/').collect();
        let rows = ranks.len() as u8;
        if rows != 8 && rows != 10 {
            return Err("Expected 10x8 or 10x10".into());
        }
        let mut p = Position::empty(rows, rule);
        let mut kings = [0; 2];
        for (row, text) in ranks.iter().enumerate() {
            let chars: Vec<_> = text.chars().collect();
            let mut i = 0;
            let mut file = 0;
            while i < chars.len() {
                if chars[i].is_ascii_digit() {
                    let mut n = 0;
                    while i < chars.len() && chars[i].is_ascii_digit() {
                        n = n * 10 + chars[i].to_digit(10).unwrap() as usize;
                        i += 1
                    }
                    if n == 0 {
                        return Err("Zero run".into());
                    }
                    file += n;
                } else {
                    let pc = Piece::try_from(chars[i]).map_err(|_| "Unknown piece")?;
                    if file >= 10 {
                        return Err("Rank overflow".into());
                    }
                    if pc.piece_type() == PieceType::King {
                        kings[pc.color()] += 1
                    }
                    p.add(pc, Square::from_rank_file(rows - 1 - row as u8, file as u8));
                    file += 1;
                    i += 1;
                }
            }
            if file != 10 {
                return Err("Rank width is not 10".into());
            }
        }
        if kings != [1, 1] {
            return Err("One king per side required".into());
        }
        p.side = match f[1] {
            "w" => Color::White,
            "b" => Color::Black,
            _ => return Err("Bad side".into()),
        };
        for c in f[2].chars() {
            p.rights |= match c {
                'K' => 1,
                'Q' => 2,
                'k' => 4,
                'q' => 8,
                '-' => 0,
                _ => return Err("Bad castling".into()),
            };
        }
        p.half = f[4].parse::<u8>().map_err(|_| "Bad halfmove")?;
        p.full = f[5].parse().map_err(|_| "Bad fullmove")?;
        if p.full == 0 {
            return Err("Bad fullmove".into());
        }
        if rows == 10 {
            if let Some(b) = f.get(6) {
                let t = b.strip_prefix('t').ok_or("Missing triple budget")?;
                let v: Vec<_> = t.split(',').collect();
                if v.len() != 2 {
                    return Err("Bad triple budget".into());
                }
                for c in 0..2 {
                    p.triple[c] = v[c].parse().map_err(|_| "Bad triple budget")?;
                    if p.triple[c] > 2 {
                        return Err("Bad triple budget".into());
                    }
                }
            }
        }
        if f[3] != "-" {
            let b = f[3].as_bytes();
            let mut i = 0;
            let mut targets = Vec::new();
            while i < b.len() {
                let start = i;
                i += 1;
                while i < b.len() && b[i].is_ascii_digit() {
                    i += 1
                }
                let s = Square::try_from(&f[3][start..i]).map_err(|_| "Bad EP square")?;
                if s as usize >= rows as usize * 10 || p.mailbox[s] != Piece::None {
                    return Err("Bad EP target".into());
                }
                targets.push(s);
                p.ep.set(s);
            }
            if targets.is_empty() || targets.len() > 2 {
                return Err("Bad EP targets".into());
            }
            let last =
                if p.side == Color::White { *targets.iter().min().unwrap() } else { *targets.iter().max().unwrap() };
            let idx = last as i16 + if p.side == Color::White { -10 } else { 10 };
            if idx < 0 || idx >= rows as i16 * 10 {
                return Err("Bad EP victim".into());
            }
            p.ep_victim = Square::new(idx as u8);
            if p.mailbox[p.ep_victim] != Piece::new(!p.side, PieceType::Pawn) {
                return Err("Missing EP pawn".into());
            }
        }
        let key = p.repetition_key();
        Ok(Self { p, stack: Vec::new(), repetitions: Vec::new(), key })
    }
    pub fn to_fen(&self) -> String {
        let mut ranks = Vec::new();
        for r in (0..self.p.rows).rev() {
            let mut row = String::new();
            let mut empty = 0;
            for f in 0..10 {
                let p = self.p.mailbox[Square::from_rank_file(r, f)];
                if p == Piece::None {
                    empty += 1
                } else {
                    if empty > 0 {
                        row.push_str(&empty.to_string());
                        empty = 0
                    }
                    row.push(TryInto::<char>::try_into(p).unwrap())
                }
            }
            if empty > 0 {
                row.push_str(&empty.to_string())
            }
            ranks.push(row)
        }
        let ep = if self.p.ep.is_empty() { "-".into() } else { self.p.ep.map(|s| s.to_string()).collect::<String>() };
        let mut s = format!(
            "{} {} {} {} {} {}",
            ranks.join("/"),
            if self.p.side == Color::White { "w" } else { "b" },
            self.castling().to_string(self),
            ep,
            self.p.half,
            self.p.full
        );
        if self.p.rows == 10 {
            s.push_str(&format!(" t{},{}", self.p.triple[0], self.p.triple[1]))
        }
        s
    }
    pub fn rows(&self) -> u8 {
        self.p.rows
    }
    pub fn rule(&self) -> u8 {
        self.p.rule
    }
    pub fn mask(&self) -> Bitboard {
        self.p.mask()
    }
    pub fn is_frc(&self) -> bool {
        false
    }
    pub fn fullmove_number(&self) -> usize {
        self.p.full
    }
    pub fn side_to_move(&self) -> Color {
        self.p.side
    }
    pub fn fiftymove_clock_bucket(&self) -> usize {
        (self.p.half.saturating_sub(8) as usize / 8).min(15)
    }
    pub fn hash(&self) -> u64 {
        self.key ^ ZOBRIST.fiftymove[self.fiftymove_clock_bucket()]
    }
    pub fn key_after(&self, m: Move) -> u64 {
        let mut p = self.p;
        p.apply(m);
        p.repetition_key() ^ ZOBRIST.fiftymove[(p.half.saturating_sub(8) as usize / 8).min(15)]
    }
    pub fn pawn_key(&self) -> u64 {
        self.p.keys.pawn ^ mix(self.p.rows as u64 + self.p.rule as u64 * 100)
    }
    pub fn non_pawn_key(&self, c: Color) -> u64 {
        self.p.keys.non_pawn[c]
    }
    pub fn all_threats(&self) -> Bitboard {
        self.p.threatened(!self.p.side, None)
    }
    pub fn piece_threats(&self, pt: PieceType) -> Bitboard {
        self.p.threatened(!self.p.side, Some(pt))
    }
    pub fn checking_squares(&self, pt: PieceType) -> Bitboard {
        let k = self.king_square(!self.p.side);
        let pc = Piece::new(if pt == PieceType::Pawn { !self.p.side } else { self.p.side }, pt);
        let mut a = attacks(pc, k, self.occupancies());
        if pt == PieceType::King && self.p.royal_knight() {
            a |= knight_attacks(k)
        }
        a & self.mask()
    }
    pub fn prior_threats(&self) -> Bitboard {
        self.stack.last().map(|p| p.threatened(!p.side, None)).unwrap_or(Bitboard(0))
    }
    pub fn captured_piece(&self) -> Piece {
        self.p.captured
    }
    pub fn castling(&self) -> Castling {
        Castling { raw: self.p.rights }
    }
    pub fn fiftymove_clock(&self) -> u8 {
        self.p.half
    }
    pub fn material(&self) -> i32 {
        self.p.mailbox.iter().map(|p| p.value()).sum()
    }
    pub fn in_check(&self) -> bool {
        self.p.in_check()
    }
    pub fn colors(&self, c: Color) -> Bitboard {
        self.p.colors[c]
    }
    pub fn pieces(&self, pt: PieceType) -> Bitboard {
        self.p.pieces[pt]
    }
    pub fn occupancies(&self) -> Bitboard {
        self.p.occ()
    }
    pub fn colored_pieces(&self, c: Color, pt: PieceType) -> Bitboard {
        self.colors(c) & self.pieces(pt)
    }
    pub fn king_square(&self, c: Color) -> Square {
        self.p.kings[c]
    }
    pub fn piece_on(&self, s: Square) -> Piece {
        self.p.mailbox[s]
    }
    pub fn type_on(&self, s: Square) -> PieceType {
        self.piece_on(s).piece_type()
    }
    pub fn moved_piece(&self, m: Move) -> Piece {
        self.piece_on(m.from())
    }
    pub fn capture_type(&self, m: Move) -> PieceType {
        if m.is_emergency() { PieceType::None } else { self.type_on(m.capture_sq()) }
    }
    pub fn is_home_rank(&self, s: Square, c: Color) -> bool {
        s.rank() as u8 == if c == Color::White { 0 } else { self.p.rows - 1 }
    }
    pub fn lever_ranks(&self, c: Color) -> Bitboard {
        let a = if c == Color::White { 4 } else { self.p.rows - 6 };
        Bitboard((1023u128 << (a * 10)) | (1023u128 << ((a + 1) * 10)))
    }
    pub fn get_castling_rook(&self, t: Square) -> (Square, Square) {
        let short = t.file() as u8 == 8;
        (
            Square::from_rank_file(t.rank() as u8, if short { 9 } else { 0 }),
            Square::from_rank_file(t.rank() as u8, if short { 7 } else { 3 }),
        )
    }
    pub fn generate_all_moves(&self) -> MoveList {
        self.p.legal()
    }
    pub fn append_noisy_moves(&self, l: &mut MoveList) {
        for e in self.generate_all_moves().iter() {
            if e.mv.is_noisy() {
                l.push_move(e.mv)
            }
        }
    }
    pub fn append_quiet_moves(&self, l: &mut MoveList) {
        for e in self.generate_all_moves().iter() {
            if e.mv.is_quiet() {
                l.push_move(e.mv)
            }
        }
    }
    pub fn is_legal(&self, m: Move) -> bool {
        m.is_present() && self.generate_all_moves().iter().any(|e| e.mv == m)
    }
    pub fn is_direct_check(&self, m: Move) -> bool {
        let mut p = self.p;
        p.apply(m);
        p.in_check()
    }
    pub fn make_move(&mut self, m: Move, _: &mut impl BoardObserver) {
        self.stack.push(self.p);
        self.repetitions.push(self.key);
        self.p.apply(m);
        self.key = self.p.repetition_key();
    }
    pub fn undo_move(&mut self, _: Move) {
        self.p = self.stack.pop().unwrap();
        self.key = self.repetitions.pop().unwrap();
    }
    pub fn make_null_move(&mut self) {
        self.stack.push(self.p);
        self.repetitions.push(self.key);
        self.p.ep = Bitboard(0);
        self.p.ep_victim = Square::None;
        self.p.side = !self.p.side;
        self.p.null_position = true;
        self.key = self.p.repetition_key();
    }
    pub fn undo_null_move(&mut self) {
        self.undo_move(Move::NULL);
    }
    pub fn is_draw(&self, ply: isize) -> bool {
        if self.p.null_position {
            return false;
        }
        let mut count = 0;
        for i in (0..self.repetitions.len()).rev() {
            if self.stack[i].null_position {
                break;
            }
            if self.repetitions[i] == self.key {
                count += 1;
                if count >= 2 || ply > 0 && self.repetitions.len() - i < ply as usize {
                    return true;
                }
            }
        }
        if self.occupancies() == self.pieces(PieceType::King) {
            return true;
        }
        if self.p.half >= 100 {
            return !self.in_check() || !self.generate_all_moves().is_empty();
        }
        false
    }
    pub fn upcoming_repetition(&self, _: usize) -> bool {
        false
    } // Exact repetition above replaces the 8x8 cuckoo predictor.
    pub fn see(&self, m: Move, threshold: i32) -> bool {
        if m.is_castling() || m.is_emergency() {
            return threshold <= 0;
        }
        let mut p = self.p;
        let gain = if m.is_capture() { self.piece_on(m.capture_sq()).value() } else { 0 }
            + if m.is_promotion() { m.promo_piece_type().value() - PieceType::Pawn.value() } else { 0 };
        p.apply(m);
        let mut gains = [0i32; 40];
        gains[0] = gain;
        let mut d = 0;
        loop {
            let mut best = None;
            let mut value = i32::MAX;
            for f in p.attackers(m.to(), p.side) {
                let pt = p.mailbox[f].piece_type();
                let v = if pt == PieceType::King { 30000 } else { pt.value() };
                if v >= value {
                    continue;
                }
                let promo = pt == PieceType::Pawn && (m.to().rank() as u8 == 0 || m.to().rank() as u8 == p.rows - 1);
                let cap = Move::new(f, m.to(), if promo { MoveKind::PromotionCaptureQ } else { MoveKind::Capture });
                if p.safe_move(cap) {
                    best = Some(cap);
                    value = v;
                }
            }
            let Some(cap) = best else { break };
            if d >= 38 {
                break;
            }
            d += 1;
            gains[d] = p.mailbox[m.to()].value() - gains[d - 1];
            if cap.is_promotion() {
                gains[d] += PieceType::Queen.value() - PieceType::Pawn.value()
            }
            p.apply(cap);
            if value == 30000 {
                break;
            }
        }
        while d > 0 {
            gains[d - 1] = -(-gains[d - 1]).max(gains[d]);
            d -= 1
        }
        gains[0] >= threshold
    }
    pub fn play_uci(&mut self, s: &str) -> Result<(), String> {
        let m = self
            .generate_all_moves()
            .iter()
            .find(|e| e.mv.to_uci(self) == s)
            .map(|e| e.mv)
            .ok_or_else(|| format!("Illegal move {s}"))?;
        self.make_move(m, &mut NullBoardObserver);
        Ok(())
    }
    pub fn perft(&mut self, d: u32) -> u64 {
        if d == 0 {
            return 1;
        }
        let moves = self.generate_all_moves();
        if d == 1 {
            return moves.len() as u64;
        }
        let mut n = 0;
        for e in moves.iter() {
            self.make_move(e.mv, &mut NullBoardObserver);
            n += self.perft(d - 1);
            self.undo_move(e.mv);
        }
        n
    }
    pub fn attacks_from(&self, s: Square) -> Bitboard {
        self.p.attacks_from(s)
    }
}
pub trait BoardObserver {}
pub struct NullBoardObserver;
impl BoardObserver for NullBoardObserver {}
impl std::fmt::Display for Board {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.to_fen())
    }
}
