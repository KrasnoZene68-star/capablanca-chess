//! Synchronous UCI/diagnostic interface for native verification.
use crate::{
    board::Board,
    search::Report,
    thread::SharedContext,
    threadpool::ThreadPool,
    time::{Limits, TimeManager},
};
use std::{
    collections::VecDeque,
    io::{self, BufRead},
    sync::Arc,
};
pub fn message_loop(mut queued: VecDeque<String>) {
    let shared = Arc::new(SharedContext::default());
    let mut pool = ThreadPool::new(shared.clone());
    let mut b = Board::starting_position();
    let mut rule = 0;
    let stdin = io::stdin();
    let mut lines = stdin.lock().lines();
    loop {
        let line = if let Some(s) = queued.pop_front() {
            s
        } else {
            match lines.next() {
                Some(Ok(s)) => s,
                _ => break,
            }
        };
        let a: Vec<_> = line.split_whitespace().collect();
        if a.is_empty() {
            continue;
        }
        match a[0] {
            "quit" => break,
            "uci" => println!("id name Reckless Capablanca 1.0\nuciok"),
            "isready" => println!("readyok"),
            "variant" => {
                rule = a.get(1).and_then(|x| x.parse().ok()).unwrap_or(0);
            }
            "position" => {
                let mut parts = line.strip_prefix("position fen ").unwrap_or("").split(" moves ");
                match Board::from_variant_fen(parts.next().unwrap_or(""), rule) {
                    Ok(mut p) => {
                        let mut valid = true;
                        if let Some(moves) = parts.next() {
                            for m in moves.split_whitespace() {
                                if let Err(e) = p.play_uci(m) {
                                    println!("error {e}");
                                    valid = false;
                                    break;
                                }
                            }
                        }
                        if valid {
                            b = p
                        }
                    }
                    Err(e) => println!("error {e}"),
                }
            }
            "fen" => println!("fen {}", b.to_fen()),
            "legal" => println!(
                "legal {}",
                b.generate_all_moves().iter().map(|e| e.mv.to_uci(&b)).collect::<Vec<_>>().join(" ")
            ),
            "perft" => {
                let d = a.get(1).and_then(|x| x.parse().ok()).unwrap_or(1);
                println!("nodes {}", b.perft(d));
            }
            "eval" => println!("eval {}", crate::nnue::evaluate(&b)),
            "go" => {
                let n = a.get(2).and_then(|x| x.parse::<u64>().ok()).unwrap_or(100);
                let limits = if a.get(1) == Some(&"depth") { Limits::Depth(n as i32) } else { Limits::Time(n) };
                let tm = TimeManager::new(limits, b.fullmove_number(), 0);
                pool.execute_searches(tm, Report::Full, 1, &b, &shared);
                println!(
                    "bestmove {}",
                    pool.vector[0].root_moves.first().map(|r| r.mv.to_uci(&b)).unwrap_or("0000".into())
                );
            }
            _ => {}
        }
    }
}
