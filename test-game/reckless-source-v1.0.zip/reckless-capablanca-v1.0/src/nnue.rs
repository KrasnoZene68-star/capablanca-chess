//! Variant-specific classical evaluation. No stock 8x8 NNUE is loaded.
//! The Network interface keeps Reckless search integration intact.
use crate::{
    board::{Board, BoardObserver},
    lookup::*,
    numa::NumaReplicable,
    types::*,
};
use std::sync::Arc;
pub fn initialize() {}
#[derive(Clone)]
pub struct ParametersHandle;
impl NumaReplicable for ParametersHandle {
    fn allocate() -> Arc<Self> {
        Arc::new(Self)
    }
    fn allocate_shared() -> Option<Arc<Self>> {
        Some(Arc::new(Self))
    }
}
#[derive(Clone)]
pub struct Network;
impl Network {
    pub fn new(_: Arc<ParametersHandle>) -> Self {
        Self
    }
    pub fn push(&mut self, _: Move, _: &Board) {}
    pub fn pop(&mut self) {}
    pub fn full_refresh(&mut self, _: &Board) {}
    pub fn evaluate(&mut self, b: &Board) -> i32 {
        evaluate(b)
    }
}
impl BoardObserver for Network {}
pub fn evaluate(b: &Board) -> i32 {
    let rows = b.rows() as i32;
    let mut total = [0i32; 2];
    let mut phase = 0;
    for s in b.occupancies() {
        phase += match b.type_on(s) {
            PieceType::Knight | PieceType::Bishop => 1,
            PieceType::Rook => 2,
            PieceType::Archbishop => 3,
            PieceType::Chancellor | PieceType::Queen => 4,
            _ => 0,
        };
    }
    let phase = phase.min(38);
    let end = 38 - phase;
    for c in [Color::White, Color::Black] {
        let own = b.colors(c);
        let enemy = b.colors(!c);
        let pawns = b.colored_pieces(c, PieceType::Pawn);
        let epawns = b.colored_pieces(!c, PieceType::Pawn);
        let pthreats = epawns.fold(Bitboard(0), |a, s| a | pawn_attacks(s, !c));
        let king = b.king_square(c);
        let zone = (king_attacks(king) | king.to_bb()) & b.mask();
        let mut danger = 0;
        for s in enemy {
            let hits = (b.attacks_from(s) & zone).popcount() as i32;
            if hits > 0 {
                danger += hits
                    * match b.type_on(s) {
                        PieceType::Queen => 16,
                        PieceType::Chancellor => 15,
                        PieceType::Archbishop => 14,
                        PieceType::Rook => 10,
                        _ => 7,
                    };
            }
        }
        total[c] -= danger * phase / 38;
        if b.colored_pieces(c, PieceType::Bishop).popcount() >= 2 {
            total[c] += 40;
        }
        for s in own {
            let pt = b.type_on(s);
            let f = s.file() as i32;
            let rank = s.rank() as i32;
            let adv = if c == Color::White { rank } else { rows - 1 - rank };
            let cf = 9 - (2 * f - 9).abs();
            let cr = rows - 1 - (2 * rank - (rows - 1)).abs();
            let center = cf + cr;
            let mob = (b.attacks_from(s) & !own & !pthreats).popcount() as i32;
            let mut v = pt.value();
            match pt {
                PieceType::Pawn => {
                    v += adv * 5 + cf * 2;
                    let adj = (if f > 0 { Bitboard::file(File::from_index((f - 1) as u8)) } else { Bitboard(0) })
                        | (if f < 9 { Bitboard::file(File::from_index((f + 1) as u8)) } else { Bitboard(0) });
                    if (pawns & adj).is_empty() {
                        v -= 14
                    }
                    if (pawns & Bitboard::file(s.file())).popcount() > 1 {
                        v -= 12
                    }
                    let mut passed = true;
                    for e in epawns {
                        if (e.file() as i32 - f).abs() <= 1
                            && if c == Color::White { e.rank() as i32 > rank } else { (e.rank() as i32) < rank }
                        {
                            passed = false;
                            break;
                        }
                    }
                    if passed {
                        let dist = rows - 1 - adv;
                        v += ((rows - dist) * (rows - dist) * 3 + 20) * (38 + end) / 76;
                        if dist == 1 {
                            v += 130
                        } else if dist == 2 {
                            v += 70
                        }
                    }
                    if !(pawn_attacks(s, !c) & pawns).is_empty() {
                        v += 10
                    }
                }
                PieceType::Knight => {
                    v += center * 5 + mob * 6;
                    if adv == 0 {
                        v -= 22
                    }
                }
                PieceType::Bishop => {
                    v += center * 2 + mob * 4;
                    if adv == 0 {
                        v -= 16
                    }
                }
                PieceType::Archbishop => {
                    v += center * 3 + mob * 5;
                    if adv == 0 {
                        v -= 24
                    }
                }
                PieceType::Chancellor => {
                    v += center * 2 + mob * 4;
                    if adv == 0 {
                        v -= 10
                    }
                }
                PieceType::Rook => {
                    v += mob * 3;
                    let file = Bitboard::file(s.file());
                    if (file & pawns).is_empty() {
                        v += 18;
                        if (file & epawns).is_empty() {
                            v += 12
                        }
                    }
                    if adv == rows - 2 {
                        v += 28
                    }
                }
                PieceType::Queen => {
                    v += center + mob * 2;
                    if adv > 2 {
                        v -= phase / 2
                    }
                }
                PieceType::King => {
                    v += center * 5 * end / 38;
                    v -= adv * 10 * phase / 38;
                    v += (king_attacks(s) & pawns).popcount() as i32 * 13 * phase / 38;
                    if adv == 0 && (f <= 2 || f >= 7) {
                        v += 25 * phase / 38
                    }
                    if b.rule() & 1 != 0 {
                        v += mob * end / 12
                    }
                }
                _ => {}
            }
            total[c] += v;
        }
    }
    let c = b.side_to_move();
    (total[c] - total[!c] + 12).clamp(-25000, 25000)
}
