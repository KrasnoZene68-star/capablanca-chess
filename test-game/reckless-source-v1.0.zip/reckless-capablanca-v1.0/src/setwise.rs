use crate::{lookup, types::*};
pub fn pawn_attacks_setwise(b: Bitboard, c: Color) -> Bitboard {
    b.fold(Bitboard(0), |a, s| a | lookup::pawn_attacks(s, c))
}
pub fn knight_attacks_setwise(b: Bitboard) -> Bitboard {
    b.fold(Bitboard(0), |a, s| a | lookup::knight_attacks(s))
}
pub fn bishop_attacks_setwise(b: Bitboard, o: Bitboard) -> Bitboard {
    b.fold(Bitboard(0), |a, s| a | lookup::bishop_attacks(s, o))
}
pub fn rook_attacks_setwise(b: Bitboard, o: Bitboard) -> Bitboard {
    b.fold(Bitboard(0), |a, s| a | lookup::rook_attacks(s, o))
}
