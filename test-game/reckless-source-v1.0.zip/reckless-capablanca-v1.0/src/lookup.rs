//! Portable attacks on ten files. Board masks restrict rays to eight or ten ranks.
use crate::types::*;
pub fn initialize() {}
const KNIGHT: [(i8, i8); 8] = [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)];
const KING: [(i8, i8); 8] = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (-1, 1), (1, -1), (-1, -1)];
const DIAG: [(i8, i8); 4] = [(1, 1), (-1, 1), (1, -1), (-1, -1)];
const ORTH: [(i8, i8); 4] = [(1, 0), (-1, 0), (0, 1), (0, -1)];
fn leaper(s: Square, steps: &[(i8, i8)]) -> Bitboard {
    let mut b = Bitboard(0);
    for &(dx, dy) in steps {
        let x = s.file() as i8 + dx;
        let y = s.rank() as i8 + dy;
        if (0..10).contains(&x) && (0..10).contains(&y) {
            b.set(Square::from_rank_file(y as u8, x as u8));
        }
    }
    b
}
fn slider(s: Square, o: Bitboard, dirs: &[(i8, i8)]) -> Bitboard {
    let mut b = Bitboard(0);
    for &(dx, dy) in dirs {
        let mut x = s.file() as i8 + dx;
        let mut y = s.rank() as i8 + dy;
        while (0..10).contains(&x) && (0..10).contains(&y) {
            let t = Square::from_rank_file(y as u8, x as u8);
            b.set(t);
            if o.contains(t) {
                break;
            }
            x += dx;
            y += dy;
        }
    }
    b
}
pub fn pawn_attacks(s: Square, c: Color) -> Bitboard {
    let d = if c == Color::White { 1 } else { -1 };
    leaper(s, &[(-1, d), (1, d)])
}
pub fn knight_attacks(s: Square) -> Bitboard {
    leaper(s, &KNIGHT)
}
pub fn king_attacks(s: Square) -> Bitboard {
    leaper(s, &KING)
}
pub fn bishop_attacks(s: Square, o: Bitboard) -> Bitboard {
    slider(s, o, &DIAG)
}
pub fn rook_attacks(s: Square, o: Bitboard) -> Bitboard {
    slider(s, o, &ORTH)
}
pub fn queen_attacks(s: Square, o: Bitboard) -> Bitboard {
    bishop_attacks(s, o) | rook_attacks(s, o)
}
pub fn attacks(p: Piece, s: Square, o: Bitboard) -> Bitboard {
    match p.piece_type() {
        PieceType::Pawn => pawn_attacks(s, p.color()),
        PieceType::Knight => knight_attacks(s),
        PieceType::Bishop => bishop_attacks(s, o),
        PieceType::Rook => rook_attacks(s, o),
        PieceType::Queen => queen_attacks(s, o),
        PieceType::King => king_attacks(s),
        PieceType::Archbishop => bishop_attacks(s, o) | knight_attacks(s),
        PieceType::Chancellor => rook_attacks(s, o) | knight_attacks(s),
        _ => Bitboard(0),
    }
}
