//! Capablanca fork: 100 squares, six promotions, explicit en-passant victim.
use super::{PieceType, Square};
use crate::board::Board;
#[derive(Copy, Clone, Eq, Hash, PartialEq, Debug, Default)]
#[repr(transparent)]
pub struct Move(u32);
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
#[repr(u8)]
pub enum MoveKind {
    Normal = 0,
    DoublePush = 1,
    Castling = 2,
    TriplePush = 3,
    Capture = 4,
    EnPassant = 5,
    Emergency = 6,
    PromotionN = 8,
    PromotionB = 9,
    PromotionR = 10,
    PromotionQ = 11,
    PromotionCaptureN = 12,
    PromotionCaptureB = 13,
    PromotionCaptureR = 14,
    PromotionCaptureQ = 15,
    PromotionA = 16,
    PromotionC = 17,
    PromotionCaptureA = 20,
    PromotionCaptureC = 21,
}
impl Move {
    pub const NULL: Self = Self(0);
    pub const fn new(f: Square, t: Square, k: MoveKind) -> Self {
        Self(f as u32 | ((t as u32) << 7) | ((k as u32) << 14))
    }
    pub const fn en_passant(f: Square, t: Square, v: Square) -> Self {
        Self(Self::new(f, t, MoveKind::EnPassant).0 | ((v as u32) << 19))
    }
    pub const fn from(self) -> Square {
        Square::new((self.0 & 127) as u8)
    }
    pub const fn to(self) -> Square {
        Square::new(((self.0 >> 7) & 127) as u8)
    }
    pub const fn kind(self) -> MoveKind {
        unsafe { std::mem::transmute(((self.0 >> 14) & 31) as u8) }
    }
    pub const fn is_present(self) -> bool {
        self.0 != 0
    }
    pub const fn is_null(self) -> bool {
        self.0 == 0
    }
    pub const fn is_quiet(self) -> bool {
        self.is_present() && !self.is_noisy()
    }
    pub const fn is_noisy(self) -> bool {
        self.is_capture() || self.is_promotion()
    }
    pub const fn is_special(self) -> bool {
        !matches!(self.kind(), MoveKind::Normal | MoveKind::Capture)
    }
    pub const fn is_capture(self) -> bool {
        matches!(
            self.kind(),
            MoveKind::Capture
                | MoveKind::EnPassant
                | MoveKind::PromotionCaptureN
                | MoveKind::PromotionCaptureB
                | MoveKind::PromotionCaptureR
                | MoveKind::PromotionCaptureQ
                | MoveKind::PromotionCaptureA
                | MoveKind::PromotionCaptureC
        )
    }
    pub const fn is_promotion(self) -> bool {
        (self.kind() as u8) >= 8
    }
    pub const fn is_en_passant(self) -> bool {
        matches!(self.kind(), MoveKind::EnPassant)
    }
    pub const fn is_emergency(self) -> bool {
        matches!(self.kind(), MoveKind::Emergency)
    }
    pub const fn capture_sq(self) -> Square {
        if self.is_en_passant() { Square::new(((self.0 >> 19) & 127) as u8) } else { self.to() }
    }
    pub const fn is_castling(self) -> bool {
        matches!(self.kind(), MoveKind::Castling)
    }
    pub const fn is_double_push(self) -> bool {
        matches!(self.kind(), MoveKind::DoublePush)
    }
    pub const fn promo_piece_type(self) -> PieceType {
        match self.kind() {
            MoveKind::PromotionN | MoveKind::PromotionCaptureN => PieceType::Knight,
            MoveKind::PromotionB | MoveKind::PromotionCaptureB => PieceType::Bishop,
            MoveKind::PromotionR | MoveKind::PromotionCaptureR => PieceType::Rook,
            MoveKind::PromotionQ | MoveKind::PromotionCaptureQ => PieceType::Queen,
            MoveKind::PromotionA | MoveKind::PromotionCaptureA => PieceType::Archbishop,
            MoveKind::PromotionC | MoveKind::PromotionCaptureC => PieceType::Chancellor,
            _ => PieceType::None,
        }
    }
    pub fn to_uci(self, _: &Board) -> String {
        if self.is_null() {
            return "0000".into();
        }
        let mut s = format!("{}{}", self.from(), self.to());
        if self.is_promotion() {
            s.push(match self.promo_piece_type() {
                PieceType::Knight => 'n',
                PieceType::Bishop => 'b',
                PieceType::Rook => 'r',
                PieceType::Queen => 'q',
                PieceType::Archbishop => 'a',
                PieceType::Chancellor => 'c',
                _ => unreachable!(),
            })
        }
        s
    }
}
