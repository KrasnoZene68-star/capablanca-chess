//! Deterministic keys, including all 100 squares and all 16 colored pieces.
pub struct Zobrist {
    pub pieces: [[u64; 100]; 16],
    pub side: u64,
    pub castling: [u64; 16],
    pub en_passant: [u64; 100],
    pub fiftymove: [u64; 16],
}
pub const fn mix(mut x: u64) -> u64 {
    x = x.wrapping_add(0x9e3779b97f4a7c15);
    x = (x ^ (x >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
    x = (x ^ (x >> 27)).wrapping_mul(0x94d049bb133111eb);
    x ^ (x >> 31)
}
const fn generate() -> Zobrist {
    let mut z = Zobrist {
        pieces: [[0; 100]; 16],
        side: mix(2000),
        castling: [0; 16],
        en_passant: [0; 100],
        fiftymove: [0; 16],
    };
    let mut p = 0;
    while p < 16 {
        let mut s = 0;
        while s < 100 {
            z.pieces[p][s] = mix((p * 100 + s) as u64);
            s += 1
        }
        z.castling[p] = mix(2100 + p as u64);
        z.fiftymove[p] = mix(2200 + p as u64);
        p += 1
    }
    let mut s = 0;
    while s < 100 {
        z.en_passant[s] = mix(2300 + s as u64);
        s += 1
    }
    z
}
pub const ZOBRIST: Zobrist = generate();
