#!/bin/sh
set -eu
cd "$(dirname "$0")"
case "$(wasm-bindgen --version)" in
  "wasm-bindgen 0.2.128") ;;
  *) echo "This Cargo.lock requires wasm-bindgen-cli 0.2.128." >&2; exit 1 ;;
esac
cargo build --locked --release --no-default-features --target wasm32-unknown-unknown --lib
mkdir -p web verification/node
wasm-bindgen target/wasm32-unknown-unknown/release/reckless.wasm --target no-modules --out-dir web --out-name reckless --no-typescript
mv web/reckless_bg.wasm web/reckless.wasm
wasm-bindgen target/wasm32-unknown-unknown/release/reckless.wasm --target nodejs --out-dir verification/node --out-name reckless --no-typescript
