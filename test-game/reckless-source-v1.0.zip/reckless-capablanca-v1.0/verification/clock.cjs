const assert=require('node:assert/strict'),{loadGame}=require('./harness.cjs');
const g=loadGame(()=>Promise.reject(Error('unused'))),a=g.api,e=id=>g.elements.get(id);
try{
 a.setMode('two');
 for(let minutes=1;minutes<=6;minutes++){
  e('timeControl').value=String(minutes);a.reset();assert.equal(a.clockState().r,minutes*60000);assert.equal(a.clockState().g,minutes*60000);
  a.commitMove(a.uciToMove('a2a3'));assert.equal(a.snapshot().history.length,0);
  a.startClock();a.elapse(1200);a.commitMove(a.uciToMove('a2a3'));
  assert.ok(a.clockState().r<=minutes*60000-1200);assert.equal(a.clockState().g,minutes*60000);assert.equal(a.snapshot().turn,'g');
  const red=a.clockState().r;a.elapse(2100);a.settleClock();assert.equal(a.clockState().r,red);assert.ok(a.clockState().g<=minutes*60000-2100);
 }
 a.elapse(400000);assert.equal(a.settleClock(),true);assert.equal(a.gameReport().result,'1-0');assert.equal(a.gameReport().endReason,'timeout');assert.equal(a.clockState().running,false);
 const fen=a.stateToFen();a.commitMove({fr:1,fc:0,tr:2,tc:0});assert.equal(a.stateToFen(),fen);
 assert.match(e('turnStatus').textContent,/ЧАС ВИЧЕРПАНО/);
 e('timeControl').value='0';a.reset();a.commitMove(a.uciToMove('a2a3'));assert.equal(a.snapshot().history.length,1);
 // Persistent mate status even after closing the result overlay.
 a.setPosition('rrr6k/10/10/10/10/10/10/K9 w - - 0 1','classic');assert.equal(a.checkGameEnd(),true);a.render();
 assert.equal(e('resultTitle').textContent,'МАТ');assert.match(e('turnStatus').textContent,/МАТ/);assert.match(e('boardOutcome').textContent,/МАТ/);assert.ok(!e('mobileState').textContent.includes('під шахом'));
 e('resultClose').dispatch('click');a.render();assert.match(e('turnStatus').textContent,/МАТ/);
 a.reset();a.setPosition('rr7k/10/10/10/10/10/10/K9 w - - 0 1','kingKnight');assert.equal(a.checkGameEnd(),false);a.render();assert.match(e('turnStatus').innerHTML,/ШАХ/);
 // Pending promotion consumes mover's clock and rolls back on flag fall.
 e('timeControl').value='1';a.reset();a.setPosition('9k/P9/10/10/10/10/10/5K4 w - - 0 1','classic');a.startClock();const before=a.stateToFen();a.commitMove(a.uciToMove('a7a8'));assert.equal(a.snapshot().history.length,0);
 a.elapse(61000);a.settleClock();assert.equal(a.stateToFen(),before);assert.equal(a.gameReport().result,'½-½');assert.equal(a.gameReport().endReason,'timeout');
 console.log('PASS 1–6 minutes, explicit start, independent turn clocks, background elapsed time, timeout and late move rejection, unlimited mode, persistent MATE, KN rescue stays CHECK, promotion clock and rollback, bare-king timeout draw.');
}finally{g.close()}
