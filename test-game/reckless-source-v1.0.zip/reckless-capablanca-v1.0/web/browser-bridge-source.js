// Real Reckless WASM worker; generation checks reject stale answers.
const engineSelect=document.getElementById('engineSelect'),mobileEngineSelect=document.getElementById('mobileEngineSelect');
let activeEngine='stockfish';
let recklessWorker=null,recklessReady=false,recklessBusy=false,recklessLastSearchOk=null,recklessFailureReason='';
let recklessInitPromise=null,recklessSerial=0;const recklessPending=new Map();
function selectedEngine(){return engineSelect.value==='reckless'?'reckless':'stockfish'}
function discardReckless(reason='Розрахунок скасовано'){
 const old=recklessWorker;recklessWorker=null;recklessReady=false;recklessBusy=false;recklessInitPromise=null;
 for(const q of recklessPending.values()){clearTimeout(q.timer);q.reject(new Error(reason))}recklessPending.clear();if(old)old.terminate();
}
function recklessCall(type,payload={},timeout=15000){return new Promise((resolve,reject)=>{
 if(!recklessWorker){reject(new Error('Reckless не завантажений'));return}
 const id=++recklessSerial,timer=setTimeout(()=>{recklessPending.delete(id);reject(new Error('Reckless: вичерпано час очікування'))},timeout);
 recklessPending.set(id,{resolve,reject,timer});try{recklessWorker.postMessage({id,type,...payload})}catch(e){clearTimeout(timer);recklessPending.delete(id);reject(e)}
})}
function initReckless(){
 if(recklessReady)return Promise.resolve(true);if(recklessInitPromise)return recklessInitPromise;let worker;
 const attempt=(async()=>{try{
  if(typeof Worker!=='function')throw new Error('Браузер не підтримує Web Worker');
  worker=recklessWorker=new Worker('./reckless.worker.js?v=5.11.0');
  worker.onmessage=event=>{if(recklessWorker!==worker)return;const d=event.data||{},q=recklessPending.get(d.id);if(!q)return;recklessPending.delete(d.id);clearTimeout(q.timer);if(d.error)q.reject(new Error(d.error));else q.resolve(d)};
  worker.onerror=event=>{if(recklessWorker!==worker)return;recklessFailureReason=event.message||'Не вдалося завантажити файли Reckless';recklessLastSearchOk=false;discardReckless(recklessFailureReason);updateStrengthStatus()};
  const reply=await recklessCall('init',{},30000);if(recklessWorker!==worker)return false;
  if(reply.engine!=='reckless-capablanca-1.0')throw new Error('Невідповідна версія Reckless');
  recklessReady=true;recklessFailureReason='';recklessLastSearchOk=null;updateStrengthStatus();return true;
 }catch(e){if(!worker||recklessWorker===worker){recklessFailureReason=String(e.message||e);recklessLastSearchOk=false;discardReckless(recklessFailureReason);updateStrengthStatus()}return false}})();
 recklessInitPromise=attempt;attempt.finally(()=>{if(recklessInitPromise===attempt)recklessInitPromise=null});return attempt;
}
async function recklessBestMove(request){
 if(!currentAiRequest(request)||!await initReckless()||!currentAiRequest(request))return null;
 if(settleClock()||!currentAiRequest(request))return null;recklessBusy=true;
 try{
  const moveTime=clock.running?Math.max(1,Math.min(request.strength.moveTime,Math.floor(clock[turn]/20),Math.floor(clock[turn]-30))):request.strength.moveTime;
  const reply=await recklessCall('search',{position:request.position,fen:request.fen,variant:request.variant,level:request.strength.level,depth:request.strength.searchDepth||0,time:moveTime,generation:request.generation},moveTime+8000);
  if(!currentAiRequest(request))return null;const mv=uciToMove(reply.move);if(!mv)throw new Error('Reckless повернув хід, який не відповідає правилам позиції');
  recklessLastSearchOk=true;recklessFailureReason='';request.engineName='Reckless';request.analysis=reply.analysis;request.actualLimits={depth:request.strength.searchDepth,timeMs:moveTime,level:request.strength.level};updateStrengthStatus();return mv;
 }catch(e){if(currentAiRequest(request)){recklessFailureReason=String(e.message||e);recklessLastSearchOk=false;discardReckless(recklessFailureReason);updateStrengthStatus()}return null}
 finally{if(aiTurnRequest===request)recklessBusy=false}
}
function initSelectedEngine(){return activeEngine==='reckless'?initReckless():initFairy()}
function engineSelectionHint(){const pending=selectedEngine()!==activeEngine;for(const id of ['engineHint','mobileEngineHint']){const el=document.getElementById(id);if(el)el.textContent=(pending?'Натисніть «Нова партія», щоб змінити рушій. ':'Рушій обирається для нової партії. ')+(selectedEngine()==='reckless'?'Reckless адаптований до наших правил. Однакові номери рівнів у різних рушіїв можуть відрізнятися за силою.':'Усі 48 рівнів доступні для обох рушіїв.')}}
engineSelect.addEventListener('change',()=>{mobileEngineSelect.value=engineSelect.value;engineSelectionHint()});
mobileEngineSelect.addEventListener('change',()=>{engineSelect.value=mobileEngineSelect.value;engineSelectionHint()});
