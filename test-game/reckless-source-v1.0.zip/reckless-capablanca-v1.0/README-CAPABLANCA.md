# Reckless Capablanca 1.0 — source for game v5.11.0

This is a modified Reckless engine for Oleksandr's Capablanca game, dated
2026-09-22. Upstream: https://github.com/codedeliveryservice/Reckless,
commit `31d9cd6fd2bea6d9f72eeb35e0bac70daa295fb1` (`0.10.0-dev`).
The original authors' work and GNU AGPL v3 license are retained; see `LICENSE`
and `README-UPSTREAM.md`. This fork is not an official upstream release.

## What is retained and changed

Reckless's iterative deepening, aspiration/PVS search, transposition table,
move ordering, history learning, reductions and time management form the search
core. Board representation, legal moves, move encoding, attack generation,
piece values and evaluation were adapted to this game's rules. Histories and
table entries were resized for 100 squares and the two extra piece types.
Quiet check evasions are searched in quiescence, including emergency moves.

The original neural network is trained for ordinary 8×8 chess. It is **not**
loaded or presented as suitable for Capablanca. This build uses a classical
evaluation of material, mobility, pawn structure, passed pawns and king safety.
Archbishop and Chancellor are evaluated explicitly. Consequently, upstream
Reckless ratings and playing strength do not apply to this fork. The 48 UI
levels keep the game's existing names, points and thinking budgets; matching
numbers in Fairy-Stockfish and Reckless are not calibrated to equal strength.
Levels 1–14 can select a weaker searched alternative; levels 15–48 use the
best searched move. A forced mating score is not deliberately weakened.

The single-thread browser build runs in its own Worker. It does not require
SharedArrayBuffer, SIMD, a server-side engine or an external NNUE file.
Changing the engine applies to a new game. Searches cancelled by a new game
or an expired clock cannot move on the replacement board. If the engine fails,
the UI explicitly identifies the local fallback; it does not label it Reckless.

## Supported rules

- Ten files a–j; 8 or 10 ranks. Starting back rank: `RNABQKBCNR`.
- A = bishop + knight; C = rook + knight. Promotions: Q/R/B/N/A/C.
- Rule IDs: 0 ordinary royal king, 1 king + knight, 2 emergency escape,
  3 king + knight + emergency escape.
- Emergency: only in check with **no ordinary legal move by any piece**.
  The king may remove an adjacent friendly non-king only if that square is
  not attacked before the move and the resulting king position is safe.
  In rule 3 normal king-knight escapes take priority; the emergency itself
  remains an adjacent step, never a knight jump.
- Castling: king f→i / f→c, rook j→h / a→d, with safe king transit squares.
- On 10×10 each side has two initial three-square pawn advances in total.
  The whole path must be clear. One- and two-square initial advances remain.
- En passant is available only on the next turn. Following a triple advance,
  either crossed square can be used when a pawn attacks it; the actual pawn
  at the end of the advance is removed, including a remote capture.
- Full position history, castling rights, effective en passant rights and
  the remaining triple-advance budgets are used for repetition.
  Checkmate takes precedence over the 50-move draw.

Extended FEN uses the existing application's format. On 10×10 append `t2,2`
for remaining red/green triple advances. Multiple en passant targets are
concatenated, e.g. `d3d4`. Red is FEN white, green is FEN black.

## Rebuild

Verified toolchain: Rust 1.98.1, `wasm32-unknown-unknown`,
`wasm-bindgen-cli 0.2.128`. Cargo.lock is included. Install the normal Rust
toolchain and the matching wasm-bindgen CLI if they are not already present:

```sh
rustup target add wasm32-unknown-unknown
cargo install wasm-bindgen-cli --version 0.2.128 --locked
sh build-wasm.sh
```

`build-wasm.sh` generates `web/reckless.js`, `web/reckless.wasm` and the Node
test wrapper. The worker and the game's HTML are source files in `web/`.
Serve that folder over HTTP(S). The existing game's Fairy-Stockfish files are
included unchanged, with their corresponding source archive. Keep the existing
GitHub Pages `coi-serviceworker.js` if present; it is not replaced by this update.

Syzygy and the ordinary-chess NNUE tooling are not supported in this fork.
Build without default features; do not enable `syzygy` or use the historical
upstream Makefile, PGO scripts or ordinary-chess benchmark corpus.

Optional native diagnostic build:

```sh
cargo build --locked --release --no-default-features
./target/release/reckless
```

Native commands: `variant 0` (or 1/2/3),
`position fen <extended FEN> moves <UCI moves>`, `legal`, `perft 2`, `fen`,
`eval`, `go depth 5`, `go movetime 500`, `quit`. This synchronous diagnostic
interface is not a complete replacement for upstream's UCI tournament frontend.
The browser uses the strict WASM position/history API directly.

## Verification

Run from this folder with Node 20+ after `sh build-wasm.sh`:

```sh
node verification/rules.cjs
node verification/engines.cjs
node verification/history.cjs
node verification/clock.cjs
```

Recorded results and a browser test are included in `verification/`.
Rules were compared against the actual game's move generator for 164 positions
at perft depth 2 and 400 successive plies across all eight board/rule
combinations. Worker tests exercised real Reckless and Fairy-Stockfish WASM,
forced emergency escapes, valuable A/C captures, engine switching and stale
answers after reset/timeout. Clock/history tests retain the preceding release's
draw and mate checks. Chromium was checked at 1366×900 and 390×844.
These are functional/regression checks, not a playing-strength tournament.
Physical iPhone Safari and Lenovo hardware still need user verification.

For the browser test install Playwright in your environment, then run
`node verification/browser.cjs`. Set `CHROME_PATH` to an installed Chromium
binary if Playwright's default browser is unavailable. The test serves its own
local HTTP endpoint with isolation headers for the unchanged Fairy engine.

The archive contains the corresponding source of this modified engine, worker
and integration. Generated JS uses the wasm-bindgen runtime under its upstream
MIT/Apache-2.0 terms; dependency versions are recorded in Cargo.lock.
