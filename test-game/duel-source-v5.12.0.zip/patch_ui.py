from pathlib import Path

root=Path(__file__).resolve().parents[1]
src=root/'capablanca_v5_11_0/index.html'
dst=root/'capablanca_v5_12_0/index.html'
text=src.read_text()
def sub(before,after,n=1):
 global text
 assert text.count(before)==n,(before[:100],text.count(before))
 text=text.replace(before,after)

sub('v5.11.0 · 2 РУШІЇ · 48 РІВНІВ','v5.12.0 · МАТЧ РУШІЇВ · 48 РІВНІВ')
sub('/* Approved 2D palette. WebGL uses its existing materials and N1/N2 meshes. */', '''#duelControls[hidden]{display:none}
#duelControls{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:0 0 10px}
#duelControls button{min-height:44px;padding:9px 13px;font-size:14px;font-weight:650}
#duelStart{background:#3f652d;border-color:#608947}
#duelPause{background:#3b3630}
#duelSummary{width:100%;font-size:13px;color:#c5dfb3;line-height:1.4}
body:not(.duel-mode) .duelOnly,body.duel-mode .soloOnly{display:none}
/* Approved 2D palette. WebGL uses its existing materials and N1/N2 meshes. */''')
sub('   </div>\n   <div class="boardShell">', '''   </div>
   <div id="duelControls" hidden role="group" aria-label="Керування матчем рушіїв">
    <button id="duelStart" type="button">Почати матч</button>
    <button id="duelPause" type="button" disabled>Пауза</button>
    <span id="duelSummary" role="status"></span>
   </div>
   <div class="boardShell">''')
for key in ['engineSelect','mobileEngineSelect','strength','mobileStrength','humanSide','mobileHumanSide']:
 sub(f'<div class="settingsField"><label for="{key}">',f'<div class="settingsField soloOnly"><label for="{key}">')
sub('     <option value="two">Двоє гравців</option>\n    </select>\n</div>\n<div class="settingsField soloOnly"><label for="humanSide">',
'''     <option value="two">Двоє гравців</option>
     <option value="engines">Fairy-Stockfish проти Reckless</option>
    </select>
</div>
<div class="settingsField duelOnly"><label for="duelRedEngine">Червоні грають за</label>
<select id="duelRedEngine"><option value="stockfish" selected>Fairy-Stockfish</option><option value="reckless">Reckless · адаптований</option></select>
<p class="strengthHint">Зеленими автоматично грає інший рушій. Зміна кольорів починає нову партію.</p></div>
<div class="settingsField duelOnly"><label for="duelRedLevel">Рівень червоних</label>
<select id="duelRedLevel" class="strengthSelect" aria-label="Рівень червоних"></select></div>
<div class="settingsField duelOnly"><label for="duelGreenLevel">Рівень зелених</label>
<select id="duelGreenLevel" class="strengthSelect" aria-label="Рівень зелених"></select>
<p class="strengthHint">Рівень кожної сторони можна змінювати під час матчу: зміна діє з наступного її ходу. Однакові номери рівнів не означають однакової сили рушіїв.</p></div>
<div class="settingsField soloOnly"><label for="humanSide">''')
sub('<select id="mobileMode"><option value="ai">Ви (червоні) проти комп’ютера</option><option value="two">Двоє гравців</option></select>\n</div>\n<div class="settingsField soloOnly"><label for="mobileHumanSide">',
'''<select id="mobileMode"><option value="ai">Ви (червоні) проти комп’ютера</option><option value="two">Двоє гравців</option><option value="engines">Fairy-Stockfish проти Reckless</option></select>
</div>
<div class="settingsField duelOnly"><label for="mobileDuelRedEngine">Червоні грають за</label>
<select id="mobileDuelRedEngine"><option value="stockfish" selected>Fairy-Stockfish</option><option value="reckless">Reckless · адаптований</option></select>
<p class="strengthHint">Зеленими автоматично грає інший рушій. Зміна кольорів починає нову партію.</p></div>
<div class="settingsField duelOnly"><label for="mobileDuelRedLevel">Рівень червоних</label>
<select id="mobileDuelRedLevel" class="strengthSelect" aria-label="Рівень червоних"></select></div>
<div class="settingsField duelOnly"><label for="mobileDuelGreenLevel">Рівень зелених</label>
<select id="mobileDuelGreenLevel" class="strengthSelect" aria-label="Рівень зелених"></select>
<p class="strengthHint">Рівень кожної сторони можна змінювати під час матчу. Однакові номери рівнів не означають однакової сили рушіїв.</p></div>
<div class="settingsField soloOnly"><label for="mobileHumanSide">''')
dst.write_text(text)
print('Duel settings and controls generated:',dst)
