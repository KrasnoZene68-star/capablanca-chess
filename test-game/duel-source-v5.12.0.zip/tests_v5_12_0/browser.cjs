const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const path=require('path'),fs=require('fs'),http=require('http'),assert=require('assert/strict');
const root=path.resolve('capablanca_v5_12_0');
const server=http.createServer((req,res)=>{
 res.setHeader('Cross-Origin-Opener-Policy','same-origin');
 res.setHeader('Cross-Origin-Embedder-Policy','require-corp');
 res.setHeader('Cache-Control','no-store');
 const name=new URL(req.url,'http://localhost').pathname;
 if(name==='/coi-serviceworker.js'){
  res.setHeader('Content-Type','application/javascript');
  res.end('// Local browser check: isolation headers supplied by test server.');return;
 }
 const file=path.resolve(root,'.'+(name==='/'?'/index.html':name));
 if(!file.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
 fs.readFile(file,(err,data)=>{
  if(err){res.writeHead(404);res.end();return;}
  res.setHeader('Content-Type',file.endsWith('.html')?'text/html':file.endsWith('.wasm')?'application/wasm':'application/javascript');
  res.end(data);
 });
});
const twoMoves=()=>{const row=document.querySelector('#mobileMoveList .moveRow');return Boolean(row?.querySelectorAll('span')[2]?.textContent.trim())};
(async()=>{
 await new Promise(done=>server.listen(0,'127.0.0.1',done));
 const address='http://127.0.0.1:'+server.address().port+'/';
 const browser=await chromium.launch({executablePath:path.resolve('reckless_work/browser/chrome-headless-shell-linux64/chrome-headless-shell'),headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});
 try{
  for(const mobile of [false,true]){
   const context=await browser.newContext({viewport:mobile?{width:390,height:844}:{width:1366,height:900},isMobile:mobile,hasTouch:mobile});
   const page=await context.newPage(),errors=[];
   page.on('pageerror',e=>errors.push(e.message));
   await page.goto(address,{waitUntil:'networkidle'});
   await page.waitForFunction(()=>document.getElementById('engineIndicatorText').textContent.includes('ГОТОВИЙ'));
   await page.click('#settingsOpen');
   await page.selectOption('#'+(mobile?'mobileMode':'mode'),'engines');
   const redLevel=mobile?'mobileDuelRedLevel':'duelRedLevel';
   const greenLevel=mobile?'mobileDuelGreenLevel':'duelGreenLevel';
   const redEngine=mobile?'mobileDuelRedEngine':'duelRedEngine';
   assert.equal(await page.locator('#'+redLevel+' option').count(),48);
   assert.equal(await page.locator('#'+greenLevel+' option').count(),48);
   await page.selectOption('#'+redLevel,'15');
   await page.selectOption('#'+greenLevel,'16');
   await page.click('#settingsDone');
   assert.equal(await page.locator('#duelControls').isVisible(),true);
   await page.click('#duelStart');
   await page.waitForFunction(twoMoves,{},{timeout:25000});
   await page.click('#duelPause');
   const atPause=await page.locator('#mobileMoveList .moveRow').count();
   await page.waitForTimeout(300);
   assert.equal(await page.locator('#mobileMoveList .moveRow').count(),atPause);
   await page.click('#duelStart');
   await page.waitForFunction(()=>document.querySelectorAll('#mobileMoveList .moveRow').length>=2,{},{timeout:25000});
   await page.click('#duelPause');
   await page.click('#settingsOpen');
   if(mobile){await page.selectOption('#mobileBoardSize','10');await page.selectOption('#mobileVariant','both')}
   await page.selectOption('#'+redEngine,'reckless');
   await page.click('#settingsDone');
   assert.match(await page.locator('#duelSummary').textContent(),/Червоні — Reckless/);
   await page.click('#duelStart');
   await page.waitForFunction(twoMoves,{},{timeout:25000});
   await page.click('#duelPause');
   assert.equal(await page.locator('.sq').count(),mobile?100:80);
   assert.deepEqual(errors,[]);
   console.log('PASS real browser',mobile?'390×844':'1366×900','two engines, reverse sides, pause/resume, 48 levels, no JS errors');
   await context.close();
  }
 }finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
})().catch(error=>{console.error(error);process.exitCode=1});
