const fs=require('fs'),assert=require('assert/strict'),{Engine}=require('../reckless_work/node/reckless.js'),{loadGame}=require('./harness.cjs');
const g=loadGame(()=>Promise.reject(Error('unused'))),a=g.api,e=new Engine();
const expanded=(s,t,ep)=>Array.from(a.allLegalMoves(s,t,ep)).flatMap(m=>s[m.fr][m.fc].t==='P'&&[0,s.length-1].includes(m.tr)?'QRBNAC'.split('').map(promote=>({...m,promote})):[m]);
const uci=(m,r)=>'abcdefghij'[m.fc]+(r-m.fr)+'abcdefghij'[m.tc]+(r-m.tr)+(m.promote||'').toLowerCase();
function perft(s,t,ep,d){if(!d)return 1;let n=0;for(const m of expanded(s,t,ep)){const x=a.applyMove(s,m,ep,true);n+=perft(x.s,t==='r'?'g':'r',x.ep,d-1)}return n}
function check(f,ruleId,rule,d=2){a.setPosition(f,rule);e.set_position(f,ruleId,'');const s=a.snapshot(),expected=expanded(s.state,s.turn,s.ep).map(m=>uci(m,s.state.length)).sort();assert.deepEqual(e.legal_moves().split(' ').filter(Boolean).sort(),expected,rule+' '+f);assert.equal(e.perft(d),perft(s.state,s.turn,s.ep,d),rule+' perft '+f);assert.equal(e.fen().split(' ')[0],f.split(' ')[0]);}
const positions=new Set(fs.readFileSync('board10_work/positions10.fen','utf8').trim().split('\n'));
for(const f of ['r8k/10/10/10/10/2b7/10/KN8 w - - 0 1','rr7k/10/10/10/10/2b7/10/KN8 w - - 0 1','r8k/10/10/10/3n6/2b7/10/KN8 w - - 0 1','rr7k/10/10/10/3n6/2b7/10/KN8 w - - 0 1','rr7k/10/10/10/10/2b7/2N7/K9 w - - 0 1','9k/10/10/10/4K5/10/10/10 w - - 0 1','r4k3r/10/10/10/10/10/10/R4K3R w KQkq - 0 1','9k/P9/10/10/10/10/10/5K4 w - - 0 1','9k/10/10/3pP5/10/10/10/5K4 w - d6 0 1'])positions.add(f);
let total=0,random=0;try{
 for(const [id,rule]of ['classic','kingKnight','escape','both'].entries()){
  for(const rows of [8,10]){g.elements.get('boardSize').value=String(rows);g.elements.get('variant').value=rule;a.reset();positions.add(a.stateToFen())}
  for(const f of positions){check(f,id,rule);total++}console.log('PASS',rule,total,'differential positions');
  for(const rows of[8,10]){g.elements.get('boardSize').value=String(rows);g.elements.get('variant').value=rule;a.reset();const start=a.stateToFen();e.set_position(start,id,'');let seed=67+id*3+rows;const played=[];
   for(let ply=0;ply<50;ply++){const s=a.snapshot(),moves=expanded(s.state,s.turn,s.ep),expected=moves.map(m=>uci(m,rows)).sort();assert.deepEqual(e.legal_moves().split(' ').filter(Boolean).sort(),expected);if(!moves.length)break;seed=(Math.imul(seed,1664525)+1013904223)>>>0;const m=moves[seed%moves.length],u=uci(m,rows);played.push(u);e.make_move(u);a.commitMove(m);const normalize=f=>{const t=f.split(' ');if(t[3]!=='-')t[3]=(t[3].match(/[a-j](?:10|[1-9])/g)||[]).sort().join('');return t.join(' ')};assert.equal(normalize(e.fen()),normalize(a.stateToFen()));random++;if(a.snapshot().gameOver)break;}
   const final=e.fen();e.set_position(start,id,played.join(' '));assert.equal(e.fen(),final);
  }
 }
 console.log('PASS',total,'legal/perft2 positions;',random,'random ply legal/FEN/history comparisons');
}catch(err){console.error(err);process.exitCode=1}finally{g.close();e.free()}
