const assert=require('node:assert/strict');
const {loadGame,referenceEngine}=require('./harness.cjs');
const {fen,mirror,engineName}=require('../audit_strength_work/tactics.cjs');
const rules=['classic','kingKnight','escape','both'];
const move=(a,u)=>{const m=a.uciToMove(u);assert.ok(m,'legal '+u);a.commitMove(m)};
(async()=>{const g=loadGame(),a=g.api,ref=await referenceEngine(a.config);try{
 for(const n of [8,10])for(const rule of rules){
  a.setMode('two');g.elements.get('boardSize').value=String(n);g.elements.get('variant').value=rule;a.reset();
  const initial=a.stateToFen();
  const cycle=['b1c3',`b${n}c${n-2}`,'c3b1',`c${n-2}b${n}`];
  for(const m of cycle)move(a,m);
  assert.equal(a.snapshot().gameOver,false);assert.equal(a.repetitionCount(),2);
  assert.equal(a.snapshot().state.halfmoveClock,4);assert.equal(a.snapshot().state.fullmoveNumber,3);
  assert.equal(a.enginePositionCommand(),'position fen '+initial+' moves '+cycle.join(' '));
  ref.engine.postMessage('setoption name UCI_Variant value '+engineName(rule,n));
  ref.engine.postMessage(a.enginePositionCommand());
  const d=await ref.command('d',l=>l.startsWith('Checkers:'));
  assert.equal(d.find(l=>l.startsWith('Fen:')).slice(5),a.stateToFen(),'history replay equals current FEN');
  for(let i=0;i<3;i++){move(a,cycle[i]);assert.equal(a.snapshot().gameOver,false)}
  move(a,cycle[3]);assert.equal(a.snapshot().gameOver,true);assert.equal(a.repetitionCount(),3);
  assert.equal(a.gameReport().result,'½-½');assert.match(g.elements.get('resultText').textContent,/тричі/);
  assert.equal(a.gameReport().moves.length,8);
  // 50-move clock is restored, increments correctly, and resets on real captures.
  const start=fen({f1:'K',['f'+n]:'k',a1:'R'},n).replace(' 0 1',' 99 17');
  a.setPosition(start,rule);move(a,'a1a2');assert.equal(a.snapshot().state.halfmoveClock,100);
  assert.equal(a.snapshot().gameOver,true);assert.match(g.elements.get('resultText').textContent,/50 ходів/);
  const cap=fen({f1:'K',['f'+n]:'k',a1:'R',a3:'p'},n).replace(' 0 1',' 99 17');
  a.setPosition(cap,rule);move(a,'a1a3');assert.equal(a.snapshot().state.halfmoveClock,0);assert.equal(a.snapshot().gameOver,false);
  const pawn=fen({f1:'K',['f'+n]:'k',a2:'P'},n).replace(' 0 1',' 99 17');
  a.setPosition(pawn,rule);move(a,'a2a3');assert.equal(a.snapshot().state.halfmoveClock,0);
  a.setPosition(mirror(pawn),rule);move(a,`a${n-1}a${n-2}`);assert.equal(a.snapshot().state.fullmoveNumber,18);
  // An irrelevant EP marker must not create different repetition rights.
  const noEp=fen({f1:'K',['f'+n]:'k',a4:'P'},n,'b');
  a.setPosition(noEp,rule);const k=a.repetitionKey();a.setPosition(noEp.replace(' - - ',' - a3 '),rule);assert.equal(a.repetitionKey(),k);
  // A real right to EP and the remaining triple budgets DO distinguish rights.
  const ep=fen({f1:'K',['f'+n]:'k',e5:'P',d5:'p'},n,'w','d6');
  a.setPosition(ep,rule);const rights=a.repetitionKey();a.setPosition(ep.replace(' d6 ',' - '),rule);assert.notEqual(a.repetitionKey(),rights);
  if(n===10){a.setPosition(noEp,rule);const two=a.repetitionKey();a.setPosition(noEp.replace('t2,2','t1,2'),rule);assert.notEqual(a.repetitionKey(),two)}
  a.setMode('two');a.reset();assert.equal(a.gameReport().result,'*');assert.equal(a.snapshot().state.halfmoveClock,0);assert.equal(a.snapshot().history.length,0);
  console.log('PASS history, replay, draw clocks, rights and reset',n,rule);
 }
 for(const green of [false,true]){
  const mate=fen({a1:'k',c3:'K',b3:'Q'}).replace(' 0 1',' 99 51');
  a.setPosition(green?mirror(mate):mate,'classic');
  move(a,green?'b6b7':'b3b2');
  assert.equal(a.gameReport().result,green?'0-1':'1-0');
  assert.match(a.snapshot().history[0].note,/#$/);assert.equal(g.elements.get('resultTitle').textContent,'МАТ');
 }
 // Checkmate beats a draw counter, and the last move records # and a result.
 a.setPosition('rrr6k/10/10/10/10/10/10/K9 w - - 100 51','both');
 assert.equal(a.checkGameEnd(),true);assert.equal(g.elements.get('resultTitle').textContent,'МАТ');
 // Underpromotion is preserved exactly, including rank 10 and fullmove counters.
 a.setPosition(fen({f1:'K',j10:'k',a9:'P'},10));a.setAi();move(a,'a9a10c');
 assert.equal(a.snapshot().state[0][0].t,'C');assert.equal(a.gameReport().moves[0].uci,'a9a10c');
 assert.match(a.enginePositionCommand(),/moves a9a10c$/);
 const replay=[
  ['escape','r8k/10/10/10/10/2b7/10/KN8 w - - 0 1','a1b1'],
  ['both','r8k/10/10/10/3n6/2b7/10/KN8 w - - 0 1','a1b1'],
  ['classic',fen({f1:'K',f8:'k',j1:'R'}).replace(' - - ',' K - '),'f1i1'],
  ['both',fen({f1:'K',f10:'k',e7:'P',d6:'p'},10,'w','d7d8','2,1'),'e7d8'],
 ];
 for(const [rule,f,u] of replay){
  a.setPosition(f,rule);a.setMode('two');move(a,u);
  ref.engine.postMessage('setoption name UCI_Variant value '+engineName(rule,a.snapshot().state.length));
  ref.engine.postMessage(a.enginePositionCommand());const d=await ref.command('d',l=>l.startsWith('Checkers:'));
  assert.equal(d.find(l=>l.startsWith('Fen:')).slice(5),a.stateToFen(),'special-move history replays in engine '+u);
 }
 console.log('PASS # notation, mate before 50-move draw, friendly capture/castling/far-EP replay');
 // Quiet check evasions must be searched even at the quiescence horizon.
 const quiet=fen({a1:'K',b2:'P',c2:'N',a8:'r',c3:'n',j8:'k'});
 for(const [f,rule,expected] of [[quiet,'classic','c2a3'],['rr7k/10/10/10/10/10/10/K9 w - - 0 1','kingKnight','a1c2'],['r8k/10/10/10/10/2b7/10/KN8 w - - 0 1','escape','a1b1']]){
  a.setPosition(f,rule);const snap=a.snapshot(),m=a.uciToMove(expected);assert.ok(m);
  assert.equal(a.allLegalMoves(snap.state,snap.turn,snap.ep).length,1);
  const after=a.applyMove(snap.state,m,snap.ep,true);
  for(const root of ['r','g']){
   const q=a.qScore(root,0);assert.equal(q.aborted,false);
   assert.equal(q.score,a.evaluate(after.s,root,after.ep),'must evaluate actual quiet/escape response, never stand pat in check');
  }
 }
 a.setPosition('rrr6k/10/10/10/10/10/10/K9 w - - 0 1','both');assert.equal(a.qScore('r',0).score,-1000000);
 console.log('PASS local quiescence: quiet blocking, KN evasion, emergency sacrifice, mate at horizon and both score perspectives');
 console.log('PASS game report includes exact UCI history, FEN, clocks, result and promotion');
}finally{g.close();ref.close()}})().catch(e=>{console.error(e);process.exitCode=1});
