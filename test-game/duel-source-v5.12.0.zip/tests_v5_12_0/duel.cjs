const assert=require('node:assert/strict');
const {loadGame}=require('./harness.cjs');
const {BrowserWorker}=require('../reckless_work/tests/worker-class.cjs');

const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function until(predicate,limit=12000){
 const end=Date.now()+limit;
 while(Date.now()<end){if(predicate())return;await sleep(25)}
 throw new Error('Match did not reach expected state before timeout');
}
(async()=>{
 const g=loadGame(undefined,{Worker:BrowserWorker}),a=g.api,e=g.elements;
 try{
  e.get('mode').value='engines';
  e.get('duelRedEngine').value='stockfish';
  e.get('duelRedLevel').value='15';
  e.get('duelGreenLevel').value='16';
  for(const rows of [8,10])for(const rule of ['classic','kingKnight','escape','both']){
   e.get('boardSize').value=String(rows);e.get('variant').value=rule;
   a.reset();
   assert.equal(a.duelState().engines.r,'stockfish');
   assert.equal(a.duelState().engines.g,'reckless');
   assert.equal(g.elements.get('duelControls').hidden,false);
   const initial=a.stateToFen();a.startDuel();
   await until(()=>a.snapshot().history.length>=2);
   a.pauseDuel();
   const history=a.snapshot().history;
   assert.equal(history[0].engine.name,'Fairy-Stockfish');
   assert.equal(history[1].engine.name,'Reckless');
   assert.equal(history[0].engine.level,15);
   assert.equal(history[1].engine.level,16);
   assert.equal(history[0].beforeFen,initial);
   assert.equal(history[0].afterFen,history[1].beforeFen);
   for(const m of history)assert.ok(m.uci&&m.note&&m.clock&&m.engine.analysis,'complete record');
   const after=history.length;
   await sleep(280);
   assert.equal(a.snapshot().history.length,after,'no move after pause');
   assert.equal(a.gameReport().engine,'duel');
   console.log('PASS duel',rows,rule,'Fairy red, Reckless green',history.length,'plies');
  }

  e.get('boardSize').value='8';e.get('variant').value='classic';
  e.get('duelRedEngine').value='reckless';e.get('duelRedLevel').value='18';
  e.get('duelGreenLevel').value='21';a.reset();a.startDuel();
  await until(()=>a.snapshot().history.length>=2);a.pauseDuel();
  const swapped=a.snapshot().history;
  assert.equal(swapped[0].engine.name,'Reckless');assert.equal(swapped[1].engine.name,'Fairy-Stockfish');
  assert.equal(swapped[0].engine.level,18);assert.equal(swapped[1].engine.level,21);
  console.log('PASS colors swapped, separate strength settings');

  // Restart from a paused position: exactly one side should move next.
  const before=swapped.length,who=a.snapshot().turn;
  a.startDuel();await until(()=>a.snapshot().history.length>before);a.pauseDuel();
  assert.equal(a.snapshot().history[before].color,who);
  console.log('PASS pause/resume preserves the board, turn and history');

  // In the emergency variant, an ordinary checkmate has precisely one rescue.
  e.get('duelRedEngine').value='stockfish';e.get('variant').value='escape';a.reset();
  a.setPosition('r8k/10/10/10/3n6/2b7/10/KN8 w - - 0 1','escape');a.startDuel();
  await until(()=>a.snapshot().history.length>=1);a.pauseDuel();
  assert.equal(a.snapshot().history[0].uci,'a1b1');
  assert.equal(a.snapshot().history[0].engine.name,'Fairy-Stockfish');
  console.log('PASS duel emergency escape remains an actual Fairy move');

  e.get('variant').value='classic';e.get('timeControl').value='0';a.reset();
  a.setPosition('rrr6k/10/10/10/10/10/10/K9 w - - 0 1','classic');
  a.startDuel();await until(()=>a.snapshot().gameOver);
  assert.equal(a.gameReport().endReason,'mate');
  assert.equal(a.duelState().running,false);
  assert.equal(a.snapshot().history.length,0);
  console.log('PASS terminal mate stops the match before either engine searches');

  e.get('variant').value='classic';e.get('timeControl').value='1';a.reset();a.startDuel();
  assert.equal(a.clockState().started,true);
  a.elapse(1450);a.pauseDuel();
  assert.equal(a.clockState().running,false);
  const frozen=a.clockState().r;await sleep(220);
  assert.equal(a.clockState().r,frozen,'match pause freezes the game clock');
  a.startDuel();assert.equal(a.clockState().running,true);
  a.elapse(61000);a.settleClock();
  assert.equal(a.snapshot().gameOver,true);
  const stopped=a.snapshot().history.length;
  await sleep(280);assert.equal(a.snapshot().history.length,stopped,'expired move rejected');
  assert.equal(a.gameReport().endReason,'timeout');
  console.log('PASS timed pause, resume, timeout and late-answer rejection');
 }finally{g.close()}
})().catch(error=>{console.error(error);process.exitCode=1});
