v5.12.0 browser match source, 2026-09-23

The modified application is index.html. duel-bridge.js is the plain
unembedded match controller; patch_ui.py and patch_code.py reproduce
the new HTML from the unmodified v5.11.0 index.html. No engine WASM,
worker or binary was changed. The corresponding Reckless AGPLv3 source
is reckless-source-v1.0.zip, shipped with v5.11.0; the same applies to
the existing Fairy-Stockfish source bundle. Both source links remain
accessible from the application's settings.

Manual update: upload index.html to the existing GitHub Pages folder.
Both engine bundles already installed with v5.11.0 stay in that folder.

Automated checks from the development workspace with Node and Playwright:
node tests_v5_12_0/duel.cjs
node tests_v5_12_0/browser.cjs
node tests_v5_12_0/clock.cjs
node tests_v5_12_0/history.cjs
node tests_v5_12_0/engines.cjs

The tests use the unchanged engine binaries from v5.11.0. See the
matching notes in README_MATCH_UA.txt for results and device limits.
