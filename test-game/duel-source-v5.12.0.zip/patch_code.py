from pathlib import Path

root=Path(__file__).resolve().parents[1]
dst=root/'capablanca_v5_12_0/index.html'
text=dst.read_text()
def sub(before,after,n=1):
 global text
 assert text.count(before)==n,(before[:90],text.count(before),n)
 text=text.replace(before,after)

sub(' return (!request.engine||request.engine===activeEngine) && request.generation===gameGeneration && request.variant===variant() &&\n  !gameOver && modeEl.value==="ai" && turn===request.side && turn===aiSide() &&\n  request.fen===stateToFen();',
''' return request.engine===engineForSide(request.side) && request.generation===gameGeneration && request.variant===variant() &&
  !gameOver && turn===request.side &&
  (modeEl.value==='ai'&&turn===aiSide() || modeEl.value==='engines'&&duelRunning&&request.duelEpoch===duelEpoch) &&
  request.fen===stateToFen();''')
sub('function isHumanTurn(){return modeEl.value!=="ai"||turn===humanSide()}',
    "function isHumanTurn(){return modeEl.value==='two'||modeEl.value==='ai'&&turn===humanSide()}")
sub(' const flipped=humanSide()==="g";', ' const flipped=modeEl.value!=="engines"&&humanSide()==="g";')
bridge=(root/'duel_work/duel-bridge.js').read_text()
sub('function variant(){return variantEl.value}',bridge+'\nfunction variant(){return variantEl.value}')
sub(' document.getElementById("clockStart").hidden=!clock.minutes||clock.started||gameOver;',
    ' document.getElementById("clockStart").hidden=!clock.minutes||clock.started||gameOver||modeEl.value==="engines";')
sub('appVersion:"5.11.0",engine:activeEngine,engineBuild:activeEngine==="reckless"?"Reckless Capablanca 1.0":"5.10.0",board:`10x${ROWS}`,',
'''appVersion:"5.12.0",engine:modeEl.value==='engines'?'duel':activeEngine,
  engineBuild:modeEl.value==='engines'?'Fairy-Stockfish 5.10.0 + Reckless Capablanca 1.0':activeEngine==='reckless'?'Reckless Capablanca 1.0':'5.10.0',board:`10x${ROWS}`,''')
sub('  variant:variant(),engineVariant:activeEngine==="reckless"?`capablanca-10x${ROWS}-${variant()}`:fairyVariant(),result:gameResult,endReason:endKind,clock:{...clock},',
'''  variant:variant(),engineVariant:modeEl.value==='engines'?{r:duelEngines.r==='stockfish'?fairyVariant():`capablanca-10x${ROWS}-${variant()}`,g:duelEngines.g==='stockfish'?fairyVariant():`capablanca-10x${ROWS}-${variant()}`}:
   activeEngine==='reckless'?`capablanca-10x${ROWS}-${variant()}`:fairyVariant(),result:gameResult,endReason:endKind,clock:{...clock},
  duel:modeEl.value==='engines'?{r:{engine:duelEngines.r,level:duelStrengthForSide('r').level},g:{engine:duelEngines.g,level:duelStrengthForSide('g').level},running:duelRunning,started:duelStarted,pausedReason:duelPauseReason}:null,''')
sub('  engineStatus:activeEngine==="reckless"?{ready:recklessReady,lastSearchOk:recklessLastSearchOk,reason:recklessFailureReason}:{ready:fairyReady,lastSearchOk:fairyLastSearchOk,reason:fairyFailureReason}};',
'''  engineStatus:modeEl.value==='engines'?{stockfish:{ready:fairyReady,lastSearchOk:fairyLastSearchOk,reason:fairyFailureReason},reckless:{ready:recklessReady,lastSearchOk:recklessLastSearchOk,reason:recklessFailureReason}}:
   activeEngine==='reckless'?{ready:recklessReady,lastSearchOk:recklessLastSearchOk,reason:recklessFailureReason}:{ready:fairyReady,lastSearchOk:fairyLastSearchOk,reason:fairyFailureReason}};''')
sub(' for(const select of [strengthEl,mobileStrength]){\n  select.innerHTML="";',
''' for(const select of [strengthEl,mobileStrength,duelRedLevel,mobileDuelRedLevel,duelGreenLevel,mobileDuelGreenLevel]){
  select.innerHTML="";''')
sub('  select.value=selected;\n }\n}\nfunction selectStrength(value){',
'''  select.value=[duelRedLevel,mobileDuelRedLevel,duelGreenLevel,mobileDuelGreenLevel].includes(select)?'30':selected;
 }
}
function selectStrength(value){''')
sub(' if(e)e.textContent=label;\n if(ind){ind.className=`engineIndicator ${cls}`;}\n if(txt)txt.textContent=label;\n}',
''' if(modeEl.value==='engines'){
  const r=duelStrengthForSide('r'),g=duelStrengthForSide('g');
  const trouble=!duelRunning&&(duelPauseReason||fairyLastSearchOk===false&&fairyFailureReason||recklessLastSearchOk===false&&recklessFailureReason);
  const ready=fairyReady&&recklessReady;
  label=`Матч: червоні ${engineLabel(duelEngines.r)} ${r.level}/48 · зелені ${engineLabel(duelEngines.g)} ${g.level}/48 · ${gameOver?'ЗАВЕРШЕНО':trouble?'ПАУЗА: '+trouble:duelRunning?'ГРАЮТЬ':duelStarted?'ПАУЗА':ready?'ГОТОВІ':'ЗАВАНТАЖЕННЯ'}`;
  cls=trouble?'fallback':ready?'active':'loading';
 }
 if(e)e.textContent=label;
 if(ind){ind.className=`engineIndicator ${cls}`;}
 if(txt)txt.textContent=label;
}''')
sub(' activeEngine=selectedEngine();\n if(recklessBusy)discardReckless();',
''' activeEngine=selectedEngine();
 duelEngines={r:duelRedEngineEl.value==='reckless'?'reckless':'stockfish',g:duelRedEngineEl.value==='reckless'?'stockfish':'reckless'};
 duelRunning=false;duelStarted=false;duelEpoch++;duelPauseReason='';
 if(recklessBusy)discardReckless();''')
sub(' applyBoardOrientation();\n applyViewMode();\n render(); renderMoves();\n updateStrengthStatus();\n if(modeEl.value==="ai"&&fairyVariant())void initSelectedEngine();',
''' applyBoardOrientation();
 applyViewMode();
 render(); renderMoves();
 updateDuelControls();updateStrengthStatus();
 if(modeEl.value==='engines'){void initFairy();void initReckless()}
 if(modeEl.value==="ai"&&fairyVariant())void initSelectedEngine();''')
sub(' subStatus.textContent=gameOver?`Партію завершено · ${gameResult}`:modeEl.value==="ai"?',
''' subStatus.textContent=gameOver?`Партію завершено · ${gameResult}`:modeEl.value==='engines'?
  duelRunning?`Хід ${engineLabel(engineForSide(turn))} (${who})`:'Матч на паузі':modeEl.value==="ai"?''')
sub(' if(modeEl.value==="ai"&&!isHumanTurn())return;', ' if(!isHumanTurn())return;')
sub('  if(modeEl.value==="ai"&&arrived.c===aiSide()){',
    '  if(modeEl.value==="engines"||modeEl.value==="ai"&&arrived.c===aiSide()){')
sub(' if(modeEl.value==="ai"&&turn===aiSide()&&!gameOver){\n  const generation=gameGeneration;\n  setTimeout(()=>{if(generation===gameGeneration)aiTurn()},120);\n }',
''' if(!gameOver&&(modeEl.value==='ai'&&turn===aiSide()||modeEl.value==='engines'&&duelRunning)){
  const generation=gameGeneration,epoch=duelEpoch;
  setTimeout(()=>{if(generation===gameGeneration&&(modeEl.value!=='engines'||duelRunning&&duelEpoch===epoch))void aiTurn()},200);
 }''')
sub('function showResult(kind){\n if(recklessBusy)discardReckless();',
'''function showResult(kind){
 if(modeEl.value==='engines'){duelRunning=false;duelEpoch++;aiTurnRequest=null;duelPauseReason=''}
 if(recklessBusy)discardReckless();''')
sub('   fiftyMoves:"50 ходів кожної сторони без взяття й ходу пішака."})[kind]+" ½-½";\n }\n}',
'''   fiftyMoves:"50 ходів кожної сторони без взяття й ходу пішака."})[kind]+" ½-½";
 }
 if(modeEl.value==='engines'){updateDuelControls();updateStrengthStatus()}
}''')
sub(' if(gameOver||modeEl.value!=="ai"||turn!==aiSide())return;\n if(aiTurnRequest&&currentAiRequest(aiTurnRequest))return;\n if(checkGameEnd())return;\n const request={engine:activeEngine,generation:gameGeneration,rows:ROWS,variant:variant(),side:turn,fen:stateToFen(),position:enginePositionCommand(),strength:strengthProfile()};',
''' if(gameOver||modeEl.value==='two'||modeEl.value==='ai'&&turn!==aiSide()||modeEl.value==='engines'&&!duelRunning)return;
 if(aiTurnRequest&&currentAiRequest(aiTurnRequest))return;
 if(checkGameEnd())return;
 const request={engine:engineForSide(turn),duelEpoch,generation:gameGeneration,rows:ROWS,variant:variant(),side:turn,
  fen:stateToFen(),position:enginePositionCommand(),strength:modeEl.value==='engines'?duelStrengthForSide(turn):strengthProfile()};''')
sub('  if(currentAiRequest(request))localAiTurn(request.strength);\n }finally{',
'''  if(currentAiRequest(request)){
   if(modeEl.value==='engines')pauseDuel(`${engineLabel(request.engine)} недоступний; перевірте файли рушія`);
   else localAiTurn(request.strength);
  }
 }finally{''')
sub('populateStrengthSelects();\nmobileEngineSelect.value=engineSelect.value;',
'''populateStrengthSelects();
mobileDuelRedEngine.value=duelRedEngineEl.value;
mobileEngineSelect.value=engineSelect.value;''')
dst.write_text(text)
print('Duel logic added:',len(text),'characters')
