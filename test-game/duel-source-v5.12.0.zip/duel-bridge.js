// v5.12.0: one board, two engines and a shared game record.
const duelRedEngineEl=document.getElementById('duelRedEngine');
const mobileDuelRedEngine=document.getElementById('mobileDuelRedEngine');
const duelRedLevel=document.getElementById('duelRedLevel');
const mobileDuelRedLevel=document.getElementById('mobileDuelRedLevel');
const duelGreenLevel=document.getElementById('duelGreenLevel');
const mobileDuelGreenLevel=document.getElementById('mobileDuelGreenLevel');
const duelStartButton=document.getElementById('duelStart');
const duelPauseButton=document.getElementById('duelPause');
const duelControls=document.getElementById('duelControls');
const duelSummary=document.getElementById('duelSummary');
let duelEngines={r:'stockfish',g:'reckless'},duelRunning=false,duelStarted=false,duelEpoch=0,duelPauseReason='';

function engineForSide(side){return modeEl.value==='engines'?duelEngines[side]:activeEngine}
function engineLabel(engine){return engine==='stockfish'?'Fairy-Stockfish':'Reckless'}
function duelStrengthForSide(side){
 const n=Number((side==='r'?duelRedLevel:duelGreenLevel).value);
 return STRENGTH_LEVELS[Number.isInteger(n)?Math.max(1,Math.min(48,n))-1:29];
}
function updateDuelControls(){
 const match=modeEl.value==='engines';
 document.body.classList.toggle('duel-mode',match);
 duelControls.hidden=!match;
 if(!match)return;
 duelStartButton.disabled=duelRunning||gameOver;
 duelStartButton.textContent=duelStarted?'Продовжити матч':'Почати матч';
 duelPauseButton.disabled=!duelRunning||gameOver;
 const red=engineLabel(duelEngines.r),green=engineLabel(duelEngines.g);
 duelSummary.textContent=gameOver?`Матч завершено · ${gameResult}`:
  duelPauseReason?`Матч призупинено · ${duelPauseReason}`:
  duelRunning?`Грають: червоні — ${red}, зелені — ${green}`:
  duelStarted?`Пауза · червоні — ${red}, зелені — ${green}`:
  `Червоні — ${red} · зелені — ${green} · очікування запуску`;
 paintClock();
}
function pauseDuel(reason=''){
 if(modeEl.value!=='engines'||!duelRunning)return;
 if(clock.running){
  if(settleClock())return;
  clock.running=false;
  if(clockTask!==null)clearTimeout(clockTask);
  clockTask=null;clock.stamp=clockNow();
 }
 duelRunning=false;duelEpoch++;duelPauseReason=reason;aiTurnRequest=null;
 if(fairyBusy)discardFairy();
 if(recklessBusy)discardReckless();
 updateDuelControls();updateStrengthStatus();render();
}
function startDuel(){
 if(modeEl.value!=='engines'||duelRunning||gameOver)return;
 if(clock.minutes){
  if(!clock.started)startClock();
  else if(!clock.running){clock.running=true;clock.stamp=clockNow();clockTick()}
 }
 duelRunning=true;duelStarted=true;duelPauseReason='';
 updateDuelControls();updateStrengthStatus();render();
 void aiTurn();
}
function syncDuelEngine(value){
 duelRedEngineEl.value=mobileDuelRedEngine.value=value;
 if(modeEl.value==='engines')reset();
}
function syncDuelLevel(side,value){
 const clamped=String(Math.max(1,Math.min(48,Number(value)||30)));
 for(const el of side==='r'?[duelRedLevel,mobileDuelRedLevel]:[duelGreenLevel,mobileDuelGreenLevel])el.value=clamped;
 updateDuelControls();updateStrengthStatus();
}
duelRedEngineEl.addEventListener('change',()=>syncDuelEngine(duelRedEngineEl.value));
mobileDuelRedEngine.addEventListener('change',()=>syncDuelEngine(mobileDuelRedEngine.value));
duelRedLevel.addEventListener('change',()=>syncDuelLevel('r',duelRedLevel.value));
mobileDuelRedLevel.addEventListener('change',()=>syncDuelLevel('r',mobileDuelRedLevel.value));
duelGreenLevel.addEventListener('change',()=>syncDuelLevel('g',duelGreenLevel.value));
mobileDuelGreenLevel.addEventListener('change',()=>syncDuelLevel('g',mobileDuelGreenLevel.value));
duelStartButton.addEventListener('click',startDuel);
duelPauseButton.addEventListener('click',()=>pauseDuel());
